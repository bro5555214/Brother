from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import os
import secrets
import tempfile
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from aiohttp import web

try:
    import guild_info as _guild_info
except Exception:
    _guild_info = None

BASE_DIR = Path(os.path.abspath(os.path.dirname(__file__)))
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

ACCOUNTS_FILE = Path(os.environ.get("ACCOUNTS_FILE", str(DATA_DIR / "accounts.json")))
STATS_FILE = DATA_DIR / "account_stats.json"
ACTIVITY_FILE = DATA_DIR / "activity.json"
ARCHIVE_FILE = DATA_DIR / "account_stats.archive.json"
SQUADS_FILE = DATA_DIR / "squads.json"
TEMPLATE_PATH = BASE_DIR / "index.html"
LEVEL_TABLE_FILE = BASE_DIR / "level_exp_table.json"

DASHBOARD_API_TOKEN = os.environ.get("DASHBOARD_API_TOKEN", "").strip()
SESSION_SECRET = os.environ.get("DASHBOARD_SESSION_SECRET", "").strip()

AUTO_RESTART_INTERVAL = float(os.environ.get("AUTO_RESTART_INTERVAL", "0") or "0")
PROCESS_STARTED_AT = time.time()

MAX_REQUEST_BYTES = 1024 * 1024
MAX_LOGS = 200
STATS_WRITE_INTERVAL = 3.0
STATS_WRITE_MAX_DELAY = 1.5
RATE_LIMIT_WINDOW = 60.0
RATE_LIMIT_MAX_FAILURES = 10
SCHEMA_VERSION = 5

SESSION_TTL_SECONDS = 12 * 3600
SESSION_COOKIE_NAME = "exonide_session"
SESSION_CLEANUP_INTERVAL = 600.0

STREAM_QUEUE_MAX = 512
STREAM_KEEPALIVE = 15.0

SLIDING_WINDOW_SHORT = 600.0
SLIDING_WINDOW_LONG = 3600.0

MATCH_HISTORY_MAX = 50
EXP_HISTORY_MAX = 200

STARTUP_LOGIN_CONCURRENCY = int(os.environ.get("STARTUP_LOGIN_CONCURRENCY", "3"))
BULK_STAGGER_SECONDS = float(os.environ.get("BULK_STAGGER_SECONDS", "0.5"))

VALID_BOT_TYPES = ("level", "guild")


def _is_loopback(host: str) -> bool:
    return host in ("127.0.0.1", "localhost", "::1")


def _strip_host_port(raw: str) -> str:
    if not raw:
        return ""
    raw = raw.strip().lower()
    if raw.startswith("["):
        close = raw.find("]")
        if close > 0:
            return raw[1:close]
        return raw.strip("[]")
    if raw.count(":") == 1:
        return raw.split(":", 1)[0]
    return raw


def _host_allowed(raw_host: str, configured_host: str) -> bool:
    host = _strip_host_port(raw_host)
    if not host:
        return True
    if host in ("127.0.0.1", "localhost", "::1"):
        return True
    configured_host = (configured_host or "").strip().lower()
    if not configured_host:
        return False
    if configured_host not in ("0.0.0.0", "::"):
        return host == configured_host
    try:
        import socket
        socket.inet_aton(host)
        return True
    except Exception:
        try:
            socket.inet_pton(socket.AF_INET6, host)
            return True
        except Exception:
            return False


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _now_epoch() -> float:
    return time.time()


def _today_iso() -> str:
    return time.strftime("%Y-%m-%d")


def _safe_loop() -> Optional[asyncio.AbstractEventLoop]:
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        return None


def _parse_prefixed_key(key: str) -> Tuple[str, str]:
    raw = str(key or "")
    if ":" in raw:
        head, _, tail = raw.partition(":")
        bt = head.strip().lower()
        if bt in VALID_BOT_TYPES:
            return bt, tail
    return "level", raw


def _compose_key(bot_type: str, identifier: str) -> str:
    bt = str(bot_type or "level").strip().lower()
    if bt not in VALID_BOT_TYPES:
        bt = "level"
    return f"{bt}:{str(identifier or '')}"


def _log_task_exception(task: asyncio.Task) -> None:
    if task.cancelled():
        return
    exc = task.exception()
    if exc is None:
        return
    tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    try:
        bot_state.log(f"Background task failed: {exc}\n{tb}", "error")
    except Exception:
        pass
    try:
        print(f"[-] Background task failed: {exc}", flush=True)
    except Exception:
        pass


def _publish_safe(state: "BotState", event_type: str, payload: Dict[str, Any]) -> None:
    loop = _safe_loop()
    if loop is None:
        return
    try:
        task = loop.create_task(state.publish(event_type, payload))
        task.add_done_callback(_log_task_exception)
    except Exception:
        pass


def _spawn(coro) -> Optional[asyncio.Task]:
    loop = _safe_loop()
    if loop is None:
        return None
    try:
        task = loop.create_task(coro)
        task.add_done_callback(_log_task_exception)
        return task
    except Exception as exc:
        try:
            bot_state.log(f"Could not spawn task: {exc}", "error")
        except Exception:
            pass
        return None


def _atomic_write_json(path: Path, payload: Any, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            fh.flush()
            os.fsync(fh.fileno())
        try:
            os.chmod(temp_name, mode)
        except Exception:
            pass
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


class SessionStore:

    def __init__(self, secret: str, ttl: int = SESSION_TTL_SECONDS):
        self._secret = (secret or secrets.token_urlsafe(32)).encode("utf-8")
        self._ttl = ttl
        self._sessions: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    def _sign(self, raw: str) -> str:
        return hmac.new(self._secret, raw.encode("utf-8"), hashlib.sha256).hexdigest()

    async def create(self, meta: Optional[Dict[str, Any]] = None) -> str:
        raw = secrets.token_urlsafe(32)
        sig = self._sign(raw)
        session_id = f"{raw}.{sig}"
        async with self._lock:
            self._sessions[session_id] = {
                "created_at": _now_epoch(),
                "expires_at": _now_epoch() + self._ttl,
                "meta": dict(meta or {}),
            }
        return session_id

    async def validate(self, session_id: str) -> bool:
        if not session_id or "." not in session_id:
            return False
        raw, _, sig = session_id.rpartition(".")
        if not raw or not sig:
            return False
        expected = self._sign(raw)
        try:
            if not hmac.compare_digest(sig.encode("utf-8"), expected.encode("utf-8")):
                return False
        except (TypeError, ValueError):
            return False
        async with self._lock:
            entry = self._sessions.get(session_id)
            if not entry:
                return False
            if _now_epoch() > entry.get("expires_at", 0):
                self._sessions.pop(session_id, None)
                return False
            entry["expires_at"] = _now_epoch() + self._ttl
            return True

    async def revoke(self, session_id: str) -> None:
        async with self._lock:
            self._sessions.pop(session_id, None)

    async def cleanup(self) -> int:
        now = _now_epoch()
        async with self._lock:
            expired = [k for k, v in self._sessions.items() if now > v.get("expires_at", 0)]
            for k in expired:
                self._sessions.pop(k, None)
            return len(expired)


class LevelTable:

    def __init__(self, path: Path):
        self._path = path
        self._table: Optional[Dict[int, int]] = None
        self._mtime: float = 0.0
        self._last_check: float = 0.0
        self._check_interval = 30.0
        self._lock = threading.Lock()
        self._load_initial()

    def _load_initial(self) -> None:
        with self._lock:
            self._table = self._read_from_disk()
            try:
                self._mtime = self._path.stat().st_mtime
            except Exception:
                self._mtime = 0.0
            self._last_check = time.time()

    def _read_from_disk(self) -> Optional[Dict[int, int]]:
        if not self._path.exists():
            return None
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except Exception:
            return None
        if not isinstance(raw, dict):
            return None
        table: Dict[int, int] = {}
        for key, value in raw.items():
            if not str(key).isdigit():
                continue
            if value is None:
                continue
            try:
                table[int(key)] = int(value)
            except (TypeError, ValueError):
                continue
        return table or None

    def _maybe_reload(self) -> None:
        now = time.time()
        if now - self._last_check < self._check_interval:
            return
        self._last_check = now
        try:
            current_mtime = self._path.stat().st_mtime
        except Exception:
            current_mtime = 0.0
        if current_mtime != self._mtime:
            with self._lock:
                self._table = self._read_from_disk()
                self._mtime = current_mtime

    def available(self) -> bool:
        self._maybe_reload()
        with self._lock:
            return self._table is not None

    def percent(self, level: Optional[int], exp: Optional[int]) -> Optional[float]:
        if level is None or exp is None:
            return None
        self._maybe_reload()
        with self._lock:
            if self._table is None:
                return None
            start = self._table.get(int(level))
            end = self._table.get(int(level) + 1)
            if start is None or end is None or end <= start:
                return None
            pct = (int(exp) - start) / (end - start) * 100.0
            if pct < 0.0:
                return 0.0
            if pct > 100.0:
                return 100.0
            return round(pct, 2)

    def percent_gained(self,
                       level_before: Optional[int],
                       pct_before: Optional[float],
                       level_after: Optional[int],
                       pct_after: Optional[float]) -> Optional[float]:
        if pct_before is None or pct_after is None:
            return None
        if level_before is None or level_after is None:
            return None
        try:
            lb = int(level_before)
            la = int(level_after)
        except (TypeError, ValueError):
            return None
        if la < lb:
            return None
        if la == lb:
            return round(max(0.0, pct_after - pct_before), 2)
        crossings = la - lb
        gained = (100.0 - pct_before) + ((crossings - 1) * 100.0) + pct_after
        return round(gained, 2)


level_table = LevelTable(LEVEL_TABLE_FILE)
sessions = SessionStore(SESSION_SECRET or DASHBOARD_API_TOKEN or secrets.token_urlsafe(32))


class _SlidingWindow:

    def __init__(self, span: float, max_points: int = 4096):
        self._span = span
        self._max = max_points
        self._points: List[Tuple[float, int]] = []

    def add(self, ts: float, value: int) -> None:
        self._points.append((ts, value))
        cutoff = ts - self._span
        while self._points and self._points[0][0] < cutoff:
            self._points.pop(0)
        if len(self._points) > self._max:
            del self._points[: len(self._points) - self._max]

    def rate_per_hour(self, now: float) -> Optional[float]:
        if len(self._points) < 2:
            return None
        cutoff = now - self._span
        points = [p for p in self._points if p[0] >= cutoff]
        if len(points) < 2:
            return None
        first_ts, first_val = points[0]
        last_ts, last_val = points[-1]
        elapsed = last_ts - first_ts
        if elapsed < 1.0:
            return None
        gained = last_val - first_val
        if gained < 0:
            return None
        return round(gained / (elapsed / 3600.0), 2)


_PLACEHOLDER_STATUSES = {"INITIALIZING", "LOGGING_IN", "CONNECTING"}
_LIVE_STATUSES = {"ONLINE", "SEARCHING", "IN_MATCH"}


def _is_live_status(status: str) -> bool:
    return str(status or "").upper() in _LIVE_STATUSES


def _is_placeholder_status(status: str) -> bool:
    return str(status or "").upper() in _PLACEHOLDER_STATUSES


class BotState:

    def __init__(self) -> None:
        self.accounts: Dict[str, Dict[str, Any]] = {}
        self.logs: List[Dict[str, Any]] = []
        self.max_logs: int = MAX_LOGS
        self.total_matches: int = 0
        self.total_matches_started: int = 0
        self.total_gained_exp: int = 0
        self.start_time: float = time.time()
        self.schema_version: int = SCHEMA_VERSION

        self.account_workers: Dict[str, asyncio.Task] = {}
        self.refresh_callbacks: Dict[str, Any] = {}
        self.account_credentials: Dict[str, Dict[str, Any]] = {}
        self.desired_state: Dict[str, str] = {}

        self.paused_accounts: Set[str] = set()
        self.active_writers: Dict[str, Set[Any]] = {}
        self.account_token_map: Dict[str, str] = {}
        self.auth_to_game_id: Dict[str, str] = {}
        self.game_to_auth_id: Dict[str, str] = {}

        self.level_match_counters: Dict[str, int] = {}
        self.level_match_seq_counters: Dict[str, int] = {}
        self.level_match_lock: asyncio.Lock = asyncio.Lock()
        self.guild_match_counters: Dict[str, int] = {}
        self.guild_match_lock: asyncio.Lock = asyncio.Lock()

        self.event_subscribers: List[asyncio.Queue] = []
        self.event_sequence: int = 0

        self._stats_dirty: bool = False
        self._activity_dirty: bool = False
        self._last_stats_write: float = 0.0
        self._last_activity_write: float = 0.0
        self._stats_dirty_since: float = 0.0
        self._activity_dirty_since: float = 0.0
        self._accounts_lock: asyncio.Lock = asyncio.Lock()
        self._action_locks: Dict[str, asyncio.Lock] = {}
        self._action_locks_guard: asyncio.Lock = asyncio.Lock()
        self._token_failures: Dict[str, List[float]] = {}
        # FIX: guard for the periodic flush thread-safety
        self._flush_lock: threading.Lock = threading.Lock()

    def _next_seq(self) -> int:
        self.event_sequence += 1
        return self.event_sequence

    async def action_lock(self, login_uid: str) -> asyncio.Lock:
        key = str(login_uid)
        async with self._action_locks_guard:
            lock = self._action_locks.get(key)
            if lock is None:
                lock = asyncio.Lock()
                self._action_locks[key] = lock
            return lock

    async def publish(self, event_type: str, payload: Dict[str, Any]) -> None:
        envelope = {
            "seq": self._next_seq(),
            "type": event_type,
            "ts": _now_iso(),
            "data": payload,
        }
        for q in list(self.event_subscribers):
            try:
                q.put_nowait(envelope)
            except asyncio.QueueFull:
                try:
                    while not q.empty():
                        q.get_nowait()
                except Exception:
                    pass
                try:
                    q.put_nowait({
                        "seq": self._next_seq(),
                        "type": "resync",
                        "ts": _now_iso(),
                        "data": {"reason": "queue_overflow"},
                    })
                except Exception:
                    pass

    def log(self, message: str, level: str = "info", uid: Optional[str] = None) -> None:
        safe_msg = str(message)[:4000]
        entry = {
            "time": time.strftime("%H:%M:%S"),
            "level": str(level)[:32],
            "message": safe_msg,
            "uid": str(uid)[:128] if uid is not None else None,
        }
        self.logs.append(entry)
        if len(self.logs) > self.max_logs:
            del self.logs[:-self.max_logs]
        self._mark_activity_dirty()
        _publish_safe(self, "log", entry)

    def _mark_stats_dirty(self) -> None:
        if not self._stats_dirty:
            self._stats_dirty_since = _now_epoch()
        self._stats_dirty = True
        now = _now_epoch()
        if now - self._last_stats_write >= STATS_WRITE_INTERVAL:
            self._flush_stats_now()
        elif now - self._stats_dirty_since >= STATS_WRITE_MAX_DELAY:
            self._flush_stats_now()

    def _mark_activity_dirty(self) -> None:
        if not self._activity_dirty:
            self._activity_dirty_since = _now_epoch()
        self._activity_dirty = True
        now = _now_epoch()
        if now - self._last_activity_write >= STATS_WRITE_INTERVAL:
            self._flush_activity_now()
        elif now - self._activity_dirty_since >= STATS_WRITE_MAX_DELAY:
            self._flush_activity_now()

    def register_writer(self, uid: str, writer: Any) -> None:
        key = str(uid)
        if key not in self.active_writers:
            self.active_writers[key] = set()
        self.active_writers[key].add(writer)

    def unregister_writer(self, uid: str, writer: Any) -> None:
        key = str(uid)
        if key in self.active_writers:
            self.active_writers[key].discard(writer)
            if not self.active_writers[key]:
                self.active_writers.pop(key, None)

    def close_writers_for_account(self, uid: str) -> None:
        key = str(uid)
        candidates = {key}
        bt, raw = _parse_prefixed_key(key)
        candidates.add(raw)
        candidates.add(_compose_key(bt, raw))
        for c in list(candidates):
            writers = list(self.active_writers.get(c, []))
            for w in writers:
                try:
                    if hasattr(w, "close"):
                        if hasattr(w, "is_closing"):
                            if not w.is_closing():
                                w.close()
                        else:
                            w.close()
                except Exception:
                    pass
            self.active_writers.pop(c, None)

    def _blank_account(self, login_uid: str, account_id: str,
                       nickname: str, region: str,
                       level: int, exp: int, likes: int,
                       status: str = "INITIALIZING",
                       status_reason: Optional[str] = None) -> Dict[str, Any]:
        now_str = _now_iso()
        bt, _ = _parse_prefixed_key(login_uid)
        return {
            "login_uid": login_uid,
            "bot_type": bt,
            "account_id": account_id or login_uid,
            "nickname": nickname or f"Player_{(account_id or login_uid)[:6]}",
            "region": region or ("ID" if bt == "guild" else "BD"),
            "level": int(level or 1),
            "level_pct": level_table.percent(level or 1, exp),
            "initial_exp": int(exp or 0),
            "current_exp": int(exp or 0),
            "session_start_exp": int(exp or 0),
            "gained_session": 0,
            "gained_today": 0,
            "gained_today_date": _today_iso(),
            "gained_lifetime": 0,
            "likes": int(likes or 0),
            "status": status,
            "status_reason": status_reason,
            "matches": {"total": 0, "natural": 0, "aborted": 0, "active": 0},
            "last_match": None,
            "recent_matches": [],
            "exp_history": [{"ts": _now_epoch(), "exp": int(exp or 0)}],
            "started_at": now_str,
            "started_at_epoch": _now_epoch(),
            "last_active_at": now_str,
            "last_match_time": None,
            "last_updated": now_str,
            "exp_per_hour_short": None,
            "exp_per_hour_long": None,
        }

    def ensure_placeholder(self, login_uid: str, account_id: str = "",
                           nickname: str = "", region: str = "",
                           status: str = "INITIALIZING",
                           status_reason: Optional[str] = None) -> Dict[str, Any]:
        uid_str = str(login_uid)
        existing = self.accounts.get(uid_str)
        if existing is not None:
            if account_id:
                existing["account_id"] = str(account_id)
            if nickname:
                existing["nickname"] = nickname
            if region:
                existing["region"] = region
            if _is_live_status(existing.get("status", "")):
                return existing
            existing["status"] = status
            existing["status_reason"] = status_reason
            self._mark_stats_dirty()
            _publish_safe(self, "status_change", self._public(existing))
            return existing

        acc = self._blank_account(uid_str, account_id, nickname, region, 1, 0, 0,
                                  status=status, status_reason=status_reason)
        self.accounts[uid_str] = acc
        self._mark_stats_dirty()
        _publish_safe(self, "account_upsert", self._public(acc))
        return acc

    def register_account(self, uid: str, account_id: str, nickname: str,
                         region: str, level: int, exp: int, likes: int = 0) -> None:
        uid_str = str(uid)
        acc_id_str = str(account_id or uid_str)
        now_str = _now_iso()
        now_epoch = _now_epoch()

        if uid_str not in self.accounts:
            acc = self._blank_account(uid_str, acc_id_str, nickname, region,
                                      level, exp, likes, status="ONLINE")
            acc["started_at"] = now_str
            acc["started_at_epoch"] = now_epoch
            acc["session_start_exp"] = int(exp or 0)
            self.accounts[uid_str] = acc
        else:
            acc = self.accounts[uid_str]
            if nickname:
                acc["nickname"] = nickname
            if region:
                acc["region"] = region
            if account_id:
                acc["account_id"] = acc_id_str
            if level:
                acc["level"] = int(level)
            old_exp = int(acc.get("current_exp", 0))
            new_exp = int(exp or 0)
            if "session_start_exp" not in acc:
                acc["session_start_exp"] = new_exp
            acc["current_exp"] = new_exp
            acc["gained_session"] = max(0, new_exp - int(acc.get("session_start_exp", new_exp)))
            acc["likes"] = int(likes or 0)
            acc["status"] = "ONLINE"
            acc["status_reason"] = None
            acc["last_updated"] = now_str
            acc["last_active_at"] = now_str
            acc["level_pct"] = level_table.percent(acc.get("level"), new_exp)
            history = acc.setdefault("exp_history", [])
            if not history or history[-1].get("exp") != new_exp:
                history.append({"ts": now_epoch, "exp": new_exp})
                del history[:-EXP_HISTORY_MAX]
            # FIX: consistently use _accumulate_today for both today + lifetime
            if old_exp != new_exp:
                self._accumulate_today(acc, max(0, new_exp - old_exp))

        self.recalc_totals()
        self._mark_stats_dirty()
        _publish_safe(self, "account_upsert", self._public(self.accounts[uid_str]))

    def _accumulate_today(self, acc: Dict[str, Any], delta: int) -> None:
        if delta <= 0:
            return
        today = _today_iso()
        if acc.get("gained_today_date") != today:
            acc["gained_today_date"] = today
            acc["gained_today"] = 0
        acc["gained_today"] = int(acc.get("gained_today", 0)) + int(delta)
        acc["gained_lifetime"] = int(acc.get("gained_lifetime", 0)) + int(delta)

    def update_exp(self, uid: str, current_exp: int, level: Optional[int] = None) -> None:
        uid_str = str(uid)
        if uid_str not in self.accounts:
            self.ensure_placeholder(uid_str, status="LOGGING_IN")
        acc = self.accounts[uid_str]
        old_exp = int(acc.get("current_exp", 0))
        new_exp = int(current_exp or 0)
        acc["current_exp"] = new_exp
        if level is not None and int(level) > 0:
            acc["level"] = int(level)
        acc["gained_session"] = max(0, new_exp - int(acc.get("session_start_exp", new_exp)))
        acc["last_updated"] = _now_iso()
        acc["last_active_at"] = acc["last_updated"]
        acc["level_pct"] = level_table.percent(acc.get("level"), new_exp)

        history = acc.setdefault("exp_history", [])
        if not history or history[-1].get("exp") != new_exp:
            history.append({"ts": _now_epoch(), "exp": new_exp})
            del history[:-EXP_HISTORY_MAX]

        diff = new_exp - old_exp
        if diff > 0:
            self._accumulate_today(acc, diff)
            self.log(
                f"Account {acc['nickname']} ({uid_str}) gained +{diff} EXP "
                f"session +{acc['gained_session']} today +{acc['gained_today']}",
                "success", uid_str,
            )
        self.recalc_totals()
        self._mark_stats_dirty()
        _publish_safe(self, "exp_update", self._public(acc))

    def update_status(self, uid: str, status: str,
                      active_matches: Optional[int] = None,
                      reason: Optional[str] = None) -> None:
        uid_str = str(uid)
        if uid_str not in self.accounts:
            self.ensure_placeholder(uid_str, status=status, status_reason=reason)
        acc = self.accounts[uid_str]
        acc["status"] = str(status)[:64]
        if reason is not None:
            acc["status_reason"] = str(reason)[:256] if reason else None
        elif status != "ERROR":
            acc["status_reason"] = None
        if active_matches is not None:
            acc["matches"]["active"] = int(active_matches)
        acc["last_updated"] = _now_iso()
        acc["last_active_at"] = acc["last_updated"]
        self._mark_stats_dirty()
        _publish_safe(self, "status_change", self._public(acc))

    def set_desired_state(self, uid: str, desired: str) -> None:
        self.desired_state[str(uid)] = str(desired)[:32]

    def get_desired_state(self, uid: str) -> str:
        return self.desired_state.get(str(uid), "running")

    def is_paused(self, uid: str) -> bool:
        key = str(uid)
        if key in self.paused_accounts:
            return True
        return self.desired_state.get(key) == "paused"

    def toggle_pause(self, uid: str) -> bool:
        key = str(uid)
        if self.is_paused(key):
            self.paused_accounts.discard(key)
            if self.desired_state.get(key) == "paused":
                self.desired_state[key] = "running"
            if key in self.accounts:
                self.accounts[key]["status"] = "ONLINE"
            self.log(f"Resumed {key}", "success", key)
            return False
        self.paused_accounts.add(key)
        self.desired_state[key] = "paused"
        if key in self.accounts:
            self.accounts[key]["status"] = "PAUSED"
        self.close_writers_for_account(key)
        self.log(f"Paused {key}", "warning", key)
        return True

    def toggle_pause_all(self) -> bool:
        keys = list(self.accounts.keys())
        any_active = any(not self.is_paused(k) for k in keys)
        for k in keys:
            cur = self.is_paused(k)
            if any_active and not cur:
                self.toggle_pause(k)
            elif not any_active and cur:
                self.toggle_pause(k)
        return any_active

    def get_account_uptime(self, uid: str) -> int:
        key = str(uid)
        acc = self.accounts.get(key)
        if not acc:
            return 0
        started = float(acc.get("started_at_epoch", 0) or 0)
        if started <= 0:
            return 0
        return max(0, int(_now_epoch() - started))

    def increment_match_started(self) -> None:
        self.total_matches_started += 1

    def increment_match(self, uid: str) -> None:
        uid_str = str(uid)
        self.total_matches += 1
        if uid_str in self.accounts:
            acc = self.accounts[uid_str]
            acc["matches"]["total"] = int(acc["matches"].get("total", 0)) + 1
            acc["matches"]["natural"] = int(acc["matches"].get("natural", 0)) + 1
            acc["last_match_time"] = time.strftime("%H:%M:%S")
            acc["last_updated"] = _now_iso()
            self.log(
                f"Match completed for {acc['nickname']} ({uid_str})",
                "info", uid_str,
            )
        self._mark_stats_dirty()

    def record_match_start(self, uid: str, meta: Dict[str, Any]) -> None:
        uid_str = str(uid)
        if uid_str not in self.accounts:
            self.ensure_placeholder(uid_str, status="IN_MATCH")
        acc = self.accounts[uid_str]
        acc["matches"]["active"] = int(acc["matches"].get("active", 0)) + 1
        acc["last_active_at"] = _now_iso()
        self._mark_stats_dirty()
        _publish_safe(self, "match_started", {
            "login_uid": uid_str,
            "match_id": meta.get("match_id"),
            "match_seq": meta.get("match_seq"),
            "started_at": meta.get("started_at"),
            "exp_before": meta.get("exp_before"),
            "level_before": meta.get("level_before"),
        })

    def record_match_result(self, uid: str, result: Dict[str, Any]) -> None:
        uid_str = str(uid)
        if uid_str not in self.accounts:
            return
        acc = self.accounts[uid_str]
        end_reason = result.get("end_reason", "error")
        completed = end_reason == "natural"

        acc["matches"]["active"] = max(0, int(acc["matches"].get("active", 0)) - 1)
        acc["matches"]["total"] = int(acc["matches"].get("total", 0)) + 1
        if completed:
            acc["matches"]["natural"] = int(acc["matches"].get("natural", 0)) + 1
        else:
            acc["matches"]["aborted"] = int(acc["matches"].get("aborted", 0)) + 1

        exp_before = result.get("exp_before")
        exp_after = result.get("exp_after")
        if exp_after is None:
            exp_after = acc.get("current_exp")
        level_before = result.get("level_before")
        level_after = result.get("level_after")
        if level_after is None:
            level_after = acc.get("level")
        pct_before = level_table.percent(level_before, exp_before)
        pct_after = level_table.percent(level_after, exp_after)

        exp_delta = None
        if exp_before is not None and exp_after is not None:
            try:
                exp_delta = int(exp_after) - int(exp_before)
                if exp_delta < 0:
                    exp_delta = None
            except (TypeError, ValueError):
                exp_delta = None

        leveled_up = False
        if level_before is not None and level_after is not None:
            try:
                leveled_up = int(level_after) > int(level_before)
            except (TypeError, ValueError):
                leveled_up = False

        pct_gained = level_table.percent_gained(level_before, pct_before, level_after, pct_after)

        record = {
            "match_id": result.get("match_id"),
            "match_seq": result.get("match_seq"),
            "started_at": result.get("started_at"),
            "ended_at": result.get("ended_at"),
            "duration_s": result.get("duration_s"),
            "exp_before": exp_before,
            "exp_after": exp_after,
            "exp_delta": exp_delta,
            "level_before": level_before,
            "level_after": level_after,
            "leveled_up": leveled_up,
            "level_pct_before": pct_before,
            "level_pct_after": pct_after,
            "level_pct_gained": pct_gained,
            "end_reason": end_reason,
        }

        recent = acc.setdefault("recent_matches", [])
        recent.append(record)
        del recent[:-MATCH_HISTORY_MAX]
        acc["last_match"] = record
        acc["last_match_time"] = time.strftime("%H:%M:%S")
        acc["last_active_at"] = _now_iso()
        acc["last_updated"] = acc["last_active_at"]

        if completed:
            self.total_matches += 1
            self.log(
                f"{acc['nickname']} finished match #{acc['matches']['natural']} "
                f"+{exp_delta if exp_delta is not None else 0} EXP "
                f"{result.get('duration_s', '?')}s",
                "info", uid_str,
            )
        else:
            self.log(
                f"{acc['nickname']} match aborted ({end_reason})",
                "warning", uid_str,
            )

        self.recalc_totals()
        self._mark_stats_dirty()
        _publish_safe(self, "match_finished", {
            "login_uid": uid_str,
            "record": record,
            "account": self._public(acc),
        })

    def recalc_totals(self) -> None:
        self.total_gained_exp = sum(
            int(acc.get("gained_session", 0) or 0) for acc in self.accounts.values()
        )
        now = _now_epoch()
        for acc in self.accounts.values():
            history = acc.get("exp_history", [])
            if len(history) < 2:
                acc["exp_per_hour_short"] = None
                acc["exp_per_hour_long"] = None
                continue
            short = _SlidingWindow(SLIDING_WINDOW_SHORT)
            long = _SlidingWindow(SLIDING_WINDOW_LONG)
            for point in history:
                try:
                    ts = float(point.get("ts", 0))
                    val = int(point.get("exp", 0))
                except (TypeError, ValueError):
                    continue
                short.add(ts, val)
                long.add(ts, val)
            acc["exp_per_hour_short"] = short.rate_per_hour(now)
            acc["exp_per_hour_long"] = long.rate_per_hour(now)

    def flush_all(self) -> None:
        with self._flush_lock:
            self._stats_dirty = True
            self._activity_dirty = True
            self._flush_stats_now_locked()
            self._flush_activity_now_locked()

    def _flush_stats_now(self) -> None:
        with self._flush_lock:
            self._flush_stats_now_locked()

    def _flush_activity_now(self) -> None:
        with self._flush_lock:
            self._flush_activity_now_locked()

    def _flush_stats_now_locked(self) -> None:
        if not self._stats_dirty:
            return
        payload = {
            "schema_version": self.schema_version,
            "updated_at": _now_iso(),
            "totals": {
                "matches": self.total_matches,
                "gained_session": self.total_gained_exp,
                "natural": sum(int(a.get("matches", {}).get("natural", 0)) for a in self.accounts.values()),
                "aborted": sum(int(a.get("matches", {}).get("aborted", 0)) for a in self.accounts.values()),
                "accounts": len(self.accounts),
                "level_bots": sum(1 for a in self.accounts.values() if a.get("bot_type") == "level"),
                "guild_bots": sum(1 for a in self.accounts.values() if a.get("bot_type") == "guild"),
            },
            "accounts": self.accounts,
        }
        try:
            _atomic_write_json(STATS_FILE, payload)
            self._stats_dirty = False
            self._last_stats_write = _now_epoch()
        except OSError as e:
            try:
                print(f"[-] stats persist failed: {e}", flush=True)
            except Exception:
                pass

    def _flush_activity_now_locked(self) -> None:
        if not self._activity_dirty:
            return
        try:
            _atomic_write_json(ACTIVITY_FILE, self.logs[-self.max_logs:], mode=0o600)
            self._activity_dirty = False
            self._last_activity_write = _now_epoch()
        except OSError as e:
            try:
                print(f"[-] activity persist failed: {e}", flush=True)
            except Exception:
                pass

    def _public(self, acc: Dict[str, Any]) -> Dict[str, Any]:
        out = dict(acc)
        out.pop("token", None)
        out.pop("access_token", None)
        out.pop("open_id", None)
        out.pop("aes_ak", None)
        out.pop("iv_i", None)
        out.pop("auth_password", None)
        return out


bot_state = BotState()
def _migrate_v4_to_v5(raw: Dict[str, Any]) -> Dict[str, Any]:
    accounts = raw.get("accounts", {})
    if not isinstance(accounts, dict):
        accounts = {}
    migrated: Dict[str, Any] = {}
    for key, acc in accounts.items():
        if not isinstance(acc, dict):
            continue
        login_uid = str(acc.get("login_uid") or key)
        bt, _ = _parse_prefixed_key(login_uid)
        account_id = str(acc.get("account_id") or login_uid)
        current_exp = int(acc.get("current_exp", 0) or 0)
        matches = acc.get("matches", {}) if isinstance(acc.get("matches"), dict) else {}
        session_start_exp = int(acc.get("session_start_exp", current_exp) or 0)
        migrated[login_uid] = {
            "login_uid": login_uid,
            "bot_type": bt,
            "account_id": account_id,
            "nickname": acc.get("nickname") or f"Player_{account_id[:6]}",
            "region": acc.get("region", "ID" if bt == "guild" else "BD"),
            "level": int(acc.get("level", 1) or 1),
            "level_pct": level_table.percent(acc.get("level"), current_exp),
            "initial_exp": int(acc.get("initial_exp", current_exp) or 0),
            "current_exp": current_exp,
            "session_start_exp": session_start_exp,
            "gained_session": max(0, current_exp - session_start_exp),
            "gained_today": int(acc.get("gained_today", 0) or 0),
            "gained_today_date": acc.get("gained_today_date") or _today_iso(),
            "gained_lifetime": int(acc.get("gained_lifetime", acc.get("gained_exp", 0)) or 0),
            "likes": int(acc.get("likes", 0) or 0),
            "status": "OFFLINE",
            "status_reason": None,
            "matches": {
                "total": int(matches.get("total", 0) or 0),
                "natural": int(matches.get("natural", 0) or 0),
                "aborted": int(matches.get("aborted", 0) or 0),
                "active": 0,
            },
            "last_match": acc.get("last_match"),
            "recent_matches": list(acc.get("recent_matches", []) or [])[-MATCH_HISTORY_MAX:],
            "exp_history": list(acc.get("exp_history", []) or [])[-EXP_HISTORY_MAX:] or [
                {"ts": _now_epoch(), "exp": current_exp}
            ],
            "started_at": acc.get("started_at") or _now_iso(),
            "started_at_epoch": float(acc.get("started_at_epoch", _now_epoch()) or _now_epoch()),
            "last_active_at": acc.get("last_active_at") or _now_iso(),
            "last_match_time": acc.get("last_match_time"),
            "last_updated": acc.get("last_updated") or _now_iso(),
            "exp_per_hour_short": None,
            "exp_per_hour_long": None,
        }
    return {
        "schema_version": SCHEMA_VERSION,
        "updated_at": _now_iso(),
        "totals": raw.get("totals", {}),
        "accounts": migrated,
    }


def _read_accounts() -> List[Dict[str, Any]]:
    if not ACCOUNTS_FILE.exists():
        return []
    try:
        data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("Account store is unreadable or invalid JSON") from exc
    if not isinstance(data, list):
        raise ValueError("Account store must contain a JSON list")
    return [item for item in data if isinstance(item, dict)]


def _write_accounts_atomic(accounts: List[Dict[str, Any]]) -> None:
    _atomic_write_json(ACCOUNTS_FILE, accounts, mode=0o600)


def _restore_state(state: BotState) -> None:
    if STATS_FILE.exists():
        try:
            raw = json.loads(STATS_FILE.read_text(encoding="utf-8"))
        except Exception:
            raw = None

        if isinstance(raw, dict):
            version = int(raw.get("schema_version", 4) or 4)
            if version < SCHEMA_VERSION:
                try:
                    existing: List[Any] = []
                    if ARCHIVE_FILE.exists():
                        try:
                            loaded = json.loads(ARCHIVE_FILE.read_text(encoding="utf-8"))
                            existing = loaded if isinstance(loaded, list) else []
                        except Exception:
                            existing = []
                    existing.append({
                        "archived_at": _now_iso(),
                        "reason": f"migration_v{version}_to_v{SCHEMA_VERSION}",
                        "accounts": raw.get("accounts", {}),
                    })
                    _atomic_write_json(ARCHIVE_FILE, existing)
                except Exception:
                    pass
                raw = _migrate_v4_to_v5(raw)

            accounts = raw.get("accounts", {})
            if isinstance(accounts, dict):
                for k, v in accounts.items():
                    if not isinstance(v, dict):
                        continue
                    bt, _ = _parse_prefixed_key(str(k))
                    v.setdefault("login_uid", str(k))
                    v.setdefault("bot_type", bt)
                    v.setdefault("account_id", v["login_uid"])
                    v.setdefault("nickname", f"Player_{v['account_id'][:6]}")
                    v.setdefault("region", "ID" if bt == "guild" else "BD")
                    v.setdefault("level", 1)
                    v.setdefault("level_pct", None)
                    v.setdefault("initial_exp", v.get("current_exp", 0))
                    v.setdefault("current_exp", v.get("initial_exp", 0))
                    v.setdefault("session_start_exp", v.get("current_exp", 0))
                    v.setdefault("gained_session", 0)
                    v.setdefault("gained_today", 0)
                    v.setdefault("gained_today_date", _today_iso())
                    v.setdefault("gained_lifetime", 0)
                    v.setdefault("likes", 0)
                    v.setdefault("status", "OFFLINE")
                    v.setdefault("status_reason", None)
                    matches = v.get("matches")
                    if not isinstance(matches, dict):
                        matches = {}
                        v["matches"] = matches
                    matches.setdefault("total", 0)
                    matches.setdefault("natural", 0)
                    matches.setdefault("aborted", 0)
                    matches["active"] = 0
                    v.setdefault("last_match", None)
                    v.setdefault("recent_matches", [])
                    v.setdefault("exp_history", [])
                    v.setdefault("started_at", _now_iso())
                    v.setdefault("started_at_epoch", _now_epoch())
                    v.setdefault("last_active_at", v.get("last_updated") or _now_iso())
                    v.setdefault("last_match_time", None)
                    v.setdefault("last_updated", v.get("last_active_at"))
                    v.setdefault("exp_per_hour_short", None)
                    v.setdefault("exp_per_hour_long", None)
                    state.accounts[str(k)] = v

            totals = raw.get("totals", {})
            if isinstance(totals, dict):
                state.total_matches = int(totals.get("matches", 0) or 0)
                state.total_gained_exp = int(
                    totals.get("gained_session", totals.get("gained_exp", 0)) or 0
                )

    if ACTIVITY_FILE.exists():
        try:
            raw = json.loads(ACTIVITY_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                state.logs = [x for x in raw[-state.max_logs:] if isinstance(x, dict)]
        except Exception:
            pass

    try:
        existing = _read_accounts()
        valid_keys: Set[str] = set()
        for item in existing:
            bt = str(item.get("bot_type", "level")).strip().lower()
            if bt not in VALID_BOT_TYPES:
                bt = "level"
            if isinstance(item.get("uid"), (str, int)) and str(item.get("uid")).strip():
                valid_keys.add(_compose_key(bt, str(item["uid"]).strip()))
            if isinstance(item.get("token"), str) and item["token"].strip():
                valid_keys.add(_compose_key(bt, f"tok_{item['token'].strip()[:20]}"))
        orphan_keys = [k for k in state.accounts.keys() if k not in valid_keys]
        if orphan_keys:
            archived = {k: state.accounts[k] for k in orphan_keys}
            for k in orphan_keys:
                state.accounts.pop(k, None)
            try:
                existing_archive: List[Any] = []
                if ARCHIVE_FILE.exists():
                    try:
                        loaded = json.loads(ARCHIVE_FILE.read_text(encoding="utf-8"))
                        existing_archive = loaded if isinstance(loaded, list) else []
                    except Exception:
                        existing_archive = []
                existing_archive.append({
                    "archived_at": _now_iso(),
                    "reason": "orphan_not_in_accounts_json",
                    "accounts": archived,
                })
                _atomic_write_json(ARCHIVE_FILE, existing_archive)
            except Exception:
                pass
    except Exception:
        pass


_restore_state(bot_state)


def _find_credential_entry(login_uid: str) -> Optional[Dict[str, Any]]:
    bt, raw_key = _parse_prefixed_key(login_uid)
    try:
        existing = _read_accounts()
    except Exception:
        return None
    for item in existing:
        item_bt = str(item.get("bot_type", "level")).strip().lower()
        if item_bt not in VALID_BOT_TYPES:
            item_bt = "level"
        if item_bt != bt:
            continue
        if raw_key.startswith("tok_"):
            token = str(item.get("token", "")).strip()
            if token and f"tok_{token[:20]}" == raw_key:
                return item
        else:
            if str(item.get("uid", "")).strip() == raw_key:
                return item
    return None


async def _find_credential_entry_async(login_uid: str) -> Optional[Dict[str, Any]]:
    return await asyncio.to_thread(_find_credential_entry, login_uid)


async def _accounts_read_locked() -> List[Dict[str, Any]]:
    return await asyncio.to_thread(_read_accounts)


async def _accounts_write_locked(accounts: List[Dict[str, Any]]) -> None:
    await asyncio.to_thread(_write_accounts_atomic, accounts)


@web.middleware
async def security_middleware(request: web.Request, handler):
    configured_host = os.environ.get("WEB_HOST", "127.0.0.1")
    if not _host_allowed(request.headers.get("Host", ""), configured_host):
        return web.json_response(
            {"status": "error", "error": "Host not allowed"}, status=403
        )

    if request.content_length is not None and request.content_length > MAX_REQUEST_BYTES:
        size_mb = MAX_REQUEST_BYTES / (1024 * 1024)
        return web.json_response(
            {
                "status": "error",
                "error": f"Request body too large. Limit is {size_mb:.0f} MB.",
                "limit_bytes": MAX_REQUEST_BYTES,
            },
            status=413,
        )

    path = request.path
    if path.startswith("/api/") and path not in (
        "/api/session", "/api/session/status", "/api/session/logout"
    ) and DASHBOARD_API_TOKEN:
        authorized = False
        supplied = request.headers.get("X-Dashboard-Token", "")
        if supplied:
            try:
                if hmac.compare_digest(
                    supplied.encode("utf-8"),
                    DASHBOARD_API_TOKEN.encode("utf-8"),
                ):
                    authorized = True
            except (TypeError, ValueError):
                pass
        if not authorized:
            cookie = request.cookies.get(SESSION_COOKIE_NAME, "")
            if cookie:
                try:
                    if await sessions.validate(cookie):
                        authorized = True
                except Exception:
                    pass
        if not authorized:
            client_ip = request.remote or "unknown"
            now = _now_epoch()
            attempts = bot_state._token_failures.setdefault(client_ip, [])
            attempts[:] = [t for t in attempts if now - t < RATE_LIMIT_WINDOW]
            attempts.append(now)
            if len(attempts) > RATE_LIMIT_MAX_FAILURES:
                return web.json_response(
                    {"status": "error", "error": "Rate limited"}, status=429
                )
            return web.json_response(
                {"status": "error", "error": "Unauthorized"}, status=401
            )

    try:
        response = await handler(request)
    except web.HTTPException:
        raise
    except Exception as exc:
        try:
            bot_state.log(f"Unhandled dashboard request error: {exc}", "error")
        except Exception:
            pass
        return web.json_response(
            {"status": "error", "error": "Internal server error"}, status=500
        )

    if isinstance(response, web.Response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data: https://avatar.freefire.com; "
            "connect-src 'self'; font-src 'self'; base-uri 'self'; "
            "form-action 'self'; frame-ancestors 'none'",
        )
        response.headers.setdefault("Referrer-Policy", "no-referrer")
    return response


async def _read_json(request: web.Request) -> dict:
    ct = (request.content_type or "").lower()
    if "application/json" not in ct:
        raise web.HTTPUnsupportedMediaType(text="Content-Type must be application/json")
    try:
        data = await request.json()
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
        raise web.HTTPBadRequest(text="Invalid JSON body")
    if not isinstance(data, dict):
        raise web.HTTPBadRequest(text="JSON body must be an object")
    return data


async def handle_index(request: web.Request) -> web.Response:
    if TEMPLATE_PATH.is_file():
        try:
            html = TEMPLATE_PATH.read_text(encoding="utf-8")
        except OSError as exc:
            return web.Response(
                text=f"index.html unreadable: {exc}",
                content_type="text/plain", status=500,
            )
        return web.Response(text=html, content_type="text/html", charset="utf-8")
    return web.Response(
        text="EXONIDE PRO dashboard API is running. Add index.html next to this file.",
        content_type="text/plain", charset="utf-8",
    )


async def handle_session_status(request: web.Request) -> web.Response:
    requires_token = bool(DASHBOARD_API_TOKEN)
    cookie = request.cookies.get(SESSION_COOKIE_NAME, "")
    authenticated = False
    if cookie:
        try:
            authenticated = await sessions.validate(cookie)
        except Exception:
            authenticated = False
    return web.json_response({
        "requires_token": requires_token,
        "authenticated": authenticated,
    })


async def handle_session_create(request: web.Request) -> web.Response:
    if not DASHBOARD_API_TOKEN:
        return web.json_response({"status": "ok", "session": None})
    data = await _read_json(request)
    supplied = str(data.get("token", ""))
    if not supplied:
        return web.json_response({"status": "error", "error": "Token required"}, status=400)
    try:
        ok = hmac.compare_digest(
            supplied.encode("utf-8"),
            DASHBOARD_API_TOKEN.encode("utf-8"),
        )
    except (TypeError, ValueError):
        ok = False
    if not ok:
        client_ip = request.remote or "unknown"
        now = _now_epoch()
        attempts = bot_state._token_failures.setdefault(client_ip, [])
        attempts[:] = [t for t in attempts if now - t < RATE_LIMIT_WINDOW]
        attempts.append(now)
        if len(attempts) > RATE_LIMIT_MAX_FAILURES:
            return web.json_response({"status": "error", "error": "Rate limited"}, status=429)
        return web.json_response({"status": "error", "error": "Unauthorized"}, status=401)
    session_id = await sessions.create({"ip": request.remote})
    response = web.json_response({"status": "ok"})
    response.set_cookie(
        SESSION_COOKIE_NAME,
        session_id,
        max_age=SESSION_TTL_SECONDS,
        httponly=True,
        samesite="Strict",
        secure=False,
        path="/",
    )
    return response


async def handle_session_logout(request: web.Request) -> web.Response:
    cookie = request.cookies.get(SESSION_COOKIE_NAME, "")
    if cookie:
        try:
            await sessions.revoke(cookie)
        except Exception:
            pass
    response = web.json_response({"status": "ok"})
    response.del_cookie(SESSION_COOKIE_NAME, path="/")
    return response


async def handle_health(request: web.Request) -> web.Response:
    return web.json_response({
        "status": "ok",
        "uptime": max(0, int(_now_epoch() - bot_state.start_time)),
        "accounts_loaded": len(bot_state.accounts),
        "schema_version": bot_state.schema_version,
        "level_pct_available": level_table.available(),
        "total_matches": bot_state.total_matches,
        "total_matches_started": bot_state.total_matches_started,
        "guild_info_available": _guild_info is not None,
    })


async def handle_metrics(request: web.Request) -> web.Response:
    lines = []
    lines.append("# HELP exonide_uptime_seconds Process uptime")
    lines.append("# TYPE exonide_uptime_seconds gauge")
    lines.append(f"exonide_uptime_seconds {max(0, int(_now_epoch() - bot_state.start_time))}")
    lines.append("# HELP exonide_accounts_total Number of tracked accounts")
    lines.append("# TYPE exonide_accounts_total gauge")
    lines.append(f"exonide_accounts_total {len(bot_state.accounts)}")
    lines.append("# HELP exonide_matches_total Total natural matches")
    lines.append("# TYPE exonide_matches_total counter")
    lines.append(f"exonide_matches_total {bot_state.total_matches}")
    lines.append("# HELP exonide_gained_exp_total Total session EXP gained")
    lines.append("# TYPE exonide_gained_exp_total counter")
    lines.append(f"exonide_gained_exp_total {bot_state.total_gained_exp}")
    for uid, acc in bot_state.accounts.items():
        label = uid.replace("\\", "\\\\").replace('"', '\\"')
        lines.append(
            f'exonide_account_active_matches{{uid="{label}"}} '
            f'{int(acc.get("matches", {}).get("active", 0))}'
        )
        rate_short = acc.get("exp_per_hour_short")
        if rate_short is not None:
            lines.append(
                f'exonide_account_exp_per_hour_short{{uid="{label}"}} {rate_short}'
            )
    body = "\n".join(lines) + "\n"
    return web.Response(text=body, content_type="text/plain", charset="utf-8")


async def handle_get_stats(request: web.Request) -> web.Response:
    accounts_data = sorted(
        bot_state.accounts.values(),
        key=lambda item: int(item.get("gained_session", 0) or 0),
        reverse=True,
    )
    sanitized = [bot_state._public(a) for a in accounts_data]

    for acc in sanitized:
        uid_k = str(acc.get("login_uid", ""))
        acc["uptime_seconds"] = bot_state.get_account_uptime(uid_k)
        acc["is_paused"] = bot_state.is_paused(uid_k)

    level_accounts = [a for a in sanitized if a.get("bot_type") == "level"]
    guild_accounts = [a for a in sanitized if a.get("bot_type") == "guild"]

    return web.json_response({
        "schema_version": bot_state.schema_version,
        "total_accounts": len(bot_state.accounts),
        "total_matches": bot_state.total_matches,
        "total_matches_started": bot_state.total_matches_started,
        "total_gained_exp": bot_state.total_gained_exp,
        "total_active_matches": sum(int(a.get("matches", {}).get("active", 0)) for a in sanitized),
        "level_accounts": level_accounts,
        "guild_accounts": guild_accounts,
        "accounts": sanitized,
        "logs": bot_state.logs[-80:],
        "uptime": max(0, int(_now_epoch() - bot_state.start_time)),
        "level_pct_available": level_table.available(),
    })


async def handle_get_accounts(request: web.Request) -> web.Response:
    sanitized = [bot_state._public(a) for a in bot_state.accounts.values()]
    return web.json_response({"accounts": sanitized})


async def handle_get_account(request: web.Request) -> web.Response:
    login_uid = request.match_info.get("login_uid", "").strip()
    if not login_uid:
        return web.json_response({"status": "error", "error": "Missing login_uid"}, status=400)
    acc = bot_state.accounts.get(login_uid)
    if not acc:
        return web.json_response({"status": "error", "error": "Account not found"}, status=404)
    return web.json_response(bot_state._public(acc))


async def handle_get_matches(request: web.Request) -> web.Response:
    login_uid = request.match_info.get("login_uid", "").strip()
    if not login_uid:
        return web.json_response({"status": "error", "error": "Missing login_uid"}, status=400)
    acc = bot_state.accounts.get(login_uid)
    if not acc:
        return web.json_response({"status": "error", "error": "Account not found"}, status=404)
    try:
        limit = int(request.query.get("limit", "50"))
    except ValueError:
        limit = 50
    limit = max(1, min(limit, 500))
    recent = acc.get("recent_matches", [])[-limit:]
    return web.json_response({"login_uid": login_uid, "matches": recent})


async def handle_player_info(request: web.Request) -> web.Response:
    
    if _guild_info is None:
        return web.json_response(
            {"status": "error", "error": "guild_info module not available"},
            status=503,
        )
    uid = request.match_info.get("uid", "").strip()
    region = (request.query.get("region", "BD") or "BD").upper()
    force = (request.query.get("force", "0") in ("1", "true", "yes"))
    if not uid or not uid.isdigit():
        return web.json_response({"status": "error", "error": "UID must be numeric"}, status=400)
    try:
        result = await _guild_info.lookup(uid, region, include_ban=True, force=force)
    except Exception as exc:
        return web.json_response(
            {"status": "error", "error": f"Lookup failed: {exc}"}, status=500
        )
    if not result or not result.get("ok"):
        return web.json_response(
            {"status": "error", "error": "Not found",
             "uid": uid, "region": region},
            status=404,
        )
    return web.json_response({
        "status": "ok",
        "uid": uid,
        "region": region,
        "dashboard": result.get("dashboard"),
        "terminal": result.get("terminal"),
    })


async def handle_ban_check(request: web.Request) -> web.Response:
    if _guild_info is None:
        return web.json_response(
            {"status": "error", "error": "guild_info module not available"},
            status=503,
        )
    uid = request.match_info.get("uid", "").strip()
    if not uid or not uid.isdigit():
        return web.json_response({"status": "error", "error": "UID must be numeric"}, status=400)
    try:
        ban_raw = await _guild_info.check_ban(uid)
        summary = _guild_info.ban_summary(ban_raw)
    except Exception as exc:
        return web.json_response(
            {"status": "error", "error": f"Ban check failed: {exc}"}, status=500
        )
    return web.json_response({
        "status": "ok",
        "uid": uid,
        "summary": summary,
        "raw": ban_raw,
    })


async def handle_guild_info(request: web.Request) -> web.Response:
    
    if _guild_info is None:
        return web.json_response(
            {"status": "error", "error": "guild_info module not available"},
            status=503,
        )
    guild_id = request.match_info.get("guild_id", "").strip()
    region = (request.query.get("region", "ID") or "ID").upper()
    if not guild_id:
        return web.json_response({"status": "error", "error": "Missing guild_id"}, status=400)
    try:
        result = await _guild_info.fetch_guild_info(guild_id, region)
    except Exception as exc:
        return web.json_response(
            {"status": "error", "error": f"Guild fetch failed: {exc}"}, status=500
        )
    return web.json_response({"status": "ok", "data": result})


async def handle_restart_status(request: web.Request) -> web.Response:
    
    enabled = AUTO_RESTART_INTERVAL > 0
    uptime = max(0.0, _now_epoch() - PROCESS_STARTED_AT)
    if not enabled:
        return web.json_response({
            "enabled": False,
            "uptime_seconds": int(uptime),
        })
    remaining = max(0.0, AUTO_RESTART_INTERVAL - uptime)
    return web.json_response({
        "enabled": True,
        "interval_seconds": int(AUTO_RESTART_INTERVAL),
        "uptime_seconds": int(uptime),
        "remaining_seconds": int(remaining),
    })


async def handle_squads_list(request: web.Request) -> web.Response:
    if not SQUADS_FILE.exists():
        return web.json_response({"squads": []})
    try:
        raw = json.loads(SQUADS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return web.json_response({"squads": []})
    return web.json_response({"squads": raw if isinstance(raw, list) else []})


async def _add_account_internal(new_item: Dict[str, Any], restart: bool) -> Dict[str, Any]:
    has_uid = "uid" in new_item and "password" in new_item
    has_token = "token" in new_item

    bot_type = str(new_item.get("bot_type", "level")).strip().lower()
    if bot_type not in VALID_BOT_TYPES:
        bot_type = "level"
    new_item["bot_type"] = bot_type

    if has_uid:
        uid = str(new_item.get("uid", "")).strip()
        password = str(new_item.get("password", "")).strip()
        if not uid or not password or len(uid) > 256 or len(password) > 4096:
            return {"status": "error", "error": "Invalid UID or password", "http_status": 400}
        key_uid, key_tok = uid, None
        placeholder_key = _compose_key(bot_type, uid)
    elif has_token:
        token = str(new_item.get("token", "")).strip()
        if not token or len(token) > 8192:
            return {"status": "error", "error": "Invalid token", "http_status": 400}
        key_uid, key_tok = None, token
        placeholder_key = _compose_key(bot_type, f"tok_{token[:20]}")
    else:
        return {"status": "error", "error": "Provide either uid/password or token",
                "http_status": 400}

    async with bot_state._accounts_lock:
        try:
            existing = await _accounts_read_locked()
            filtered: List[Dict[str, Any]] = []
            for item in existing:
                item_bt = str(item.get("bot_type", "level")).strip().lower()
                if item_bt not in VALID_BOT_TYPES:
                    item_bt = "level"
                if item_bt != bot_type:
                    filtered.append(item)
                    continue
                item_uid = str(item.get("uid", "")).strip()
                item_tok = str(item.get("token", "")).strip()
                if key_uid and item_uid == key_uid:
                    continue
                if key_tok and item_tok == key_tok:
                    continue
                filtered.append(item)
            filtered.append(new_item)
            await _accounts_write_locked(filtered)
        except (OSError, ValueError) as exc:
            return {
                "status": "error",
                "error": f"Could not safely update account store: {exc}",
                "http_status": 500,
            }

    lock = await bot_state.action_lock(placeholder_key)
    async with lock:
        running = bot_state.account_workers.get(placeholder_key)
        already_running = running is not None and not running.done()

        if already_running and not restart:
            bot_state.ensure_placeholder(
                placeholder_key,
                status_reason="already running",
            )
            return {
                "status": "ok",
                "state": "already_running",
                "reason": ("A worker for this account is already running. "
                           "Credentials were updated in accounts.json but the current "
                           "session continues."),
            }

        if already_running and restart:
            bot_state.set_desired_state(placeholder_key, "stopped")
            running.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(running), timeout=2.0)
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                pass
            bot_state.account_workers.pop(placeholder_key, None)

        bot_state.ensure_placeholder(
            placeholder_key,
            status="INITIALIZING",
            status_reason="queued for login",
        )
        bot_state.set_desired_state(placeholder_key, "running")

        callback = bot_state.refresh_callbacks.get("on_account_added")
        if callback:
            task = _spawn(callback(new_item))
            if task is None:
                return {
                    "status": "error",
                    "error": "Could not start worker",
                    "http_status": 500,
                }
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=0.1)
            except asyncio.TimeoutError:
                pass
            except Exception as exc:
                return {
                    "status": "error",
                    "error": f"Worker startup failed: {exc}",
                    "http_status": 500,
                }

    bot_state.log(f"New {bot_type} account added", "success", placeholder_key)
    return {"status": "ok", "state": "INITIALIZING"}


async def handle_add_account(request: web.Request) -> web.Response:
    data = await _read_json(request)
    result = await _add_account_internal(data, restart=False)
    if result.get("status") == "error":
        return web.json_response(
            {"status": "error", "error": result.get("error")},
            status=int(result.get("http_status", 400)),
        )
    return web.json_response(result)


async def handle_bulk_add(request: web.Request) -> web.Response:
    data = await _read_json(request)
    raw = data.get("entries")
    if not isinstance(raw, str):
        return web.json_response(
            {"status": "error", "error": "entries must be a multiline string"},
            status=400,
        )

    bot_type = str(data.get("bot_type", "level")).strip().lower()
    if bot_type not in VALID_BOT_TYPES:
        bot_type = "level"

    parsed: List[Dict[str, Any]] = []
    skipped = 0
    seen_uids: Set[str] = set()
    seen_tokens: Set[str] = set()

    try:
        existing = await _accounts_read_locked()
        for item in existing:
            item_bt = str(item.get("bot_type", "level")).strip().lower()
            if item_bt != bot_type:
                continue
            if item.get("uid"):
                seen_uids.add(str(item["uid"]))
            if item.get("token"):
                seen_tokens.add(str(item["token"]))
    except (OSError, ValueError):
        return web.json_response(
            {"status": "error", "error": "Could not read account store"},
            status=500,
        )

    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line and not line.startswith("eyJ"):
            uid, _, pw = line.partition(":")
            uid = uid.strip()
            pw = pw.strip()
            if not uid or not pw or uid in seen_uids:
                skipped += 1
                continue
            seen_uids.add(uid)
            parsed.append({"uid": uid, "password": pw, "bot_type": bot_type})
        else:
            token = line
            if not token or len(token) > 8192 or token in seen_tokens:
                skipped += 1
                continue
            seen_tokens.add(token)
            parsed.append({"token": token, "bot_type": bot_type})

    if not parsed:
        return web.json_response(
            {"status": "ok", "added": 0, "skipped": skipped, "results": []}
        )

    async with bot_state._accounts_lock:
        try:
            existing = await _accounts_read_locked()
            existing.extend(parsed)
            await _accounts_write_locked(existing)
        except (OSError, ValueError) as exc:
            return web.json_response(
                {"status": "error",
                 "error": f"Could not safely update account store: {exc}"},
                status=500,
            )

    callback = bot_state.refresh_callbacks.get("on_account_added")
    results: List[Dict[str, Any]] = []
    added = 0

    semaphore = asyncio.Semaphore(max(1, STARTUP_LOGIN_CONCURRENCY))

    async def _start_one(item: Dict[str, Any], delay: float) -> None:
        await asyncio.sleep(delay)
        async with semaphore:
            bt = item.get("bot_type", "level")
            if item.get("uid"):
                key = _compose_key(bt, item["uid"])
            else:
                key = _compose_key(bt, f"tok_{item['token'][:20]}")
            lock = await bot_state.action_lock(key)
            async with lock:
                running = bot_state.account_workers.get(key)
                if running is not None and not running.done():
                    results.append({"key": key, "state": "already_running"})
                    return
                bot_state.ensure_placeholder(
                    key, status="INITIALIZING", status_reason="queued for login"
                )
                bot_state.set_desired_state(key, "running")
                if callback is None:
                    results.append({"key": key, "state": "no_callback"})
                    return
                task = _spawn(callback(item))
                if task is None:
                    results.append({"key": key, "state": "spawn_failed"})
                    return
                results.append({"key": key, "state": "INITIALIZING"})

    tasks: List[asyncio.Task] = []
    for index, item in enumerate(parsed):
        delay = index * BULK_STAGGER_SECONDS
        task = _spawn(_start_one(item, delay))
        if task is not None:
            tasks.append(task)
            added += 1

    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)

    return web.json_response({
        "status": "ok",
        "added": added,
        "skipped": skipped,
        "results": results,
    })


async def handle_delete_account(request: web.Request) -> web.Response:
    data = await _read_json(request)
    uid = str(data.get("uid", "")).strip()
    token = str(data.get("token", "")).strip()

    if not uid and not token:
        return web.json_response(
            {"status": "error", "error": "UID or token is required"}, status=400
        )

    if uid:
        bot_type, raw_uid = _parse_prefixed_key(uid)
        target_uid = uid
    else:
        bot_type = str(data.get("bot_type", "level")).strip().lower()
        if bot_type not in VALID_BOT_TYPES:
            bot_type = "level"
        raw_uid = f"tok_{token[:20]}"
        target_uid = _compose_key(bot_type, raw_uid)

    async with bot_state._accounts_lock:
        try:
            existing = await _accounts_read_locked()
            kept: List[Dict[str, Any]] = []
            for item in existing:
                item_bt = str(item.get("bot_type", "level")).strip().lower()
                if item_bt not in VALID_BOT_TYPES:
                    item_bt = "level"
                if item_bt != bot_type:
                    kept.append(item)
                    continue
                item_uid = str(item.get("uid", "")).strip()
                item_tok = str(item.get("token", "")).strip()
                if raw_uid and item_uid == raw_uid:
                    continue
                if token and item_tok == token:
                    continue
                if raw_uid and raw_uid.startswith("tok_"):
                    if item_tok and f"tok_{item_tok[:20]}" == raw_uid:
                        continue
                kept.append(item)
            await _accounts_write_locked(kept)
        except (OSError, ValueError) as exc:
            return web.json_response(
                {"status": "error",
                 "error": f"Could not safely update account store: {exc}"},
                status=500,
            )

    lock = await bot_state.action_lock(target_uid)
    async with lock:
        acc_snapshot = bot_state.accounts.pop(target_uid, None)
        bot_state.account_credentials.pop(target_uid, None)
        bot_state.desired_state.pop(target_uid, None)
        bot_state.paused_accounts.discard(target_uid)

        task = bot_state.account_workers.pop(target_uid, None)
        if task and not task.done():
            task.cancel()

    if acc_snapshot:
        try:
            existing_archive: List[Any] = []
            if ARCHIVE_FILE.exists():
                try:
                    loaded = json.loads(ARCHIVE_FILE.read_text(encoding="utf-8"))
                    existing_archive = loaded if isinstance(loaded, list) else []
                except Exception:
                    existing_archive = []
            existing_archive.append({
                "archived_at": _now_iso(),
                "reason": "user_deleted",
                "accounts": {target_uid: acc_snapshot},
            })
            _atomic_write_json(ARCHIVE_FILE, existing_archive)
        except Exception:
            pass

    bot_state.log("Account removed", "warning", target_uid)
    _publish_safe(bot_state, "account_removed", {"login_uid": target_uid})

    callback = bot_state.refresh_callbacks.get("on_account_removed")
    if callback:
        payload = {"uid": raw_uid, "bot_type": bot_type}
        _spawn(callback(payload))

    return web.json_response({"status": "ok"})


async def handle_refresh_account(request: web.Request) -> web.Response:
    data = await _read_json(request)
    uid = str(data.get("uid", "")).strip()
    if not uid or len(uid) > 256:
        return web.json_response(
            {"status": "error", "error": "Valid UID is required"}, status=400
        )
    callback = bot_state.refresh_callbacks.get("on_refresh_account")
    if callback:
        _spawn(callback(uid))
    return web.json_response({"status": "ok"})


async def handle_account_start(request: web.Request) -> web.Response:
    data = await _read_json(request)
    login_uid = str(data.get("login_uid", "")).strip()
    if not login_uid:
        return web.json_response({"status": "error", "error": "login_uid required"}, status=400)

    callback = bot_state.refresh_callbacks.get("on_account_added")
    creds = bot_state.account_credentials.get(login_uid)

    if creds:
        bt = creds.get("bot_type", "level")
        if creds.get("auth_uid"):
            payload = {"uid": creds["auth_uid"],
                       "password": creds.get("auth_password", ""),
                       "bot_type": bt}
        elif creds.get("auth_token"):
            payload = {"token": creds["auth_token"], "bot_type": bt}
        else:
            payload = None
    else:
        
        payload = await _find_credential_entry_async(login_uid)

    if not payload or not callback:
        return web.json_response(
            {"status": "error", "error": "Cannot start this account"}, status=400
        )

    lock = await bot_state.action_lock(login_uid)
    async with lock:
        running = bot_state.account_workers.get(login_uid)
        if running is not None and not running.done():
            return web.json_response({"status": "ok", "state": "already_running"})
        bot_state.set_desired_state(login_uid, "running")
        bot_state.paused_accounts.discard(login_uid)
        task = _spawn(callback(payload))
        if task is None:
            return web.json_response(
                {"status": "error", "error": "Could not start worker"}, status=500
            )

    return web.json_response({"status": "ok", "state": "INITIALIZING"})


async def handle_account_stop(request: web.Request) -> web.Response:
    data = await _read_json(request)
    login_uid = str(data.get("login_uid", "")).strip()
    if not login_uid:
        return web.json_response({"status": "error", "error": "login_uid required"}, status=400)
    bot_state.set_desired_state(login_uid, "stopped")
    bot_state.paused_accounts.discard(login_uid)
    lock = await bot_state.action_lock(login_uid)
    async with lock:
        task = bot_state.account_workers.pop(login_uid, None)
        if task and not task.done():
            task.cancel()
    bot_state.update_status(login_uid, "OFFLINE", reason="stopped by user")
    return web.json_response({"status": "ok"})


async def handle_account_pause(request: web.Request) -> web.Response:
    data = await _read_json(request)
    login_uid = str(data.get("login_uid", "")).strip()
    if not login_uid:
        return web.json_response({"status": "error", "error": "login_uid required"}, status=400)
    bot_state.set_desired_state(login_uid, "paused")
    bot_state.paused_accounts.add(login_uid)
    lock = await bot_state.action_lock(login_uid)
    async with lock:
        task = bot_state.account_workers.get(login_uid)
        if task and not task.done():
            task.cancel()
    bot_state.close_writers_for_account(login_uid)
    bot_state.update_status(login_uid, "PAUSED", reason="paused by user")
    return web.json_response({"status": "ok"})


async def handle_account_resume(request: web.Request) -> web.Response:
    return await handle_account_start(request)


async def handle_toggle_pause(request: web.Request) -> web.Response:
    data = await _read_json(request)
    uid = str(data.get("uid", "")).strip()
    if not uid:
        return web.json_response({"status": "error", "error": "UID required"}, status=400)
    is_paused = bot_state.toggle_pause(uid)
    return web.json_response({"status": "ok", "is_paused": is_paused})


async def handle_toggle_pause_all(request: web.Request) -> web.Response:
    all_paused = bot_state.toggle_pause_all()
    return web.json_response({"status": "ok", "all_paused": all_paused})


async def handle_clear_logs(request: web.Request) -> web.Response:
    bot_state.logs.clear()
    bot_state._mark_activity_dirty()
    return web.json_response({"status": "ok"})


async def handle_export(request: web.Request) -> web.Response:
    fmt = (request.query.get("format", "json") or "json").lower()
    accounts = [bot_state._public(a) for a in bot_state.accounts.values()]
    if fmt == "csv":
        header = (
            "login_uid,bot_type,account_id,nickname,region,level,current_exp,"
            "gained_session,gained_today,gained_lifetime,matches_total,"
            "matches_natural,matches_aborted,status"
        )
        lines = [header]
        for a in accounts:
            m = a.get("matches", {})
            lines.append(",".join([
                str(a.get("login_uid", "")),
                str(a.get("bot_type", "")),
                str(a.get("account_id", "")),
                '"' + str(a.get("nickname", "")).replace('"', '""') + '"',
                str(a.get("region", "")),
                str(a.get("level", "")),
                str(a.get("current_exp", "")),
                str(a.get("gained_session", "")),
                str(a.get("gained_today", "")),
                str(a.get("gained_lifetime", "")),
                str(m.get("total", 0)),
                str(m.get("natural", 0)),
                str(m.get("aborted", 0)),
                str(a.get("status", "")),
            ]))
        body = "\n".join(lines) + "\n"
        return web.Response(text=body, content_type="text/csv", charset="utf-8")
    return web.json_response({
        "schema_version": bot_state.schema_version,
        "exported_at": _now_iso(),
        "totals": {
            "accounts": len(bot_state.accounts),
            "matches": bot_state.total_matches,
            "gained_session": bot_state.total_gained_exp,
        },
        "accounts": accounts,
    })


def _build_snapshot() -> Dict[str, Any]:
    return {
        "seq": bot_state.event_sequence,
        "type": "snapshot",
        "ts": _now_iso(),
        "data": {
            "schema_version": bot_state.schema_version,
            "totals": {
                "accounts": len(bot_state.accounts),
                "matches": bot_state.total_matches,
                "gained_session": bot_state.total_gained_exp,
            },
            "accounts": [bot_state._public(a) for a in bot_state.accounts.values()],
            "logs": bot_state.logs[-60:],
            "uptime": max(0, int(_now_epoch() - bot_state.start_time)),
            "level_pct_available": level_table.available(),
        },
    }


async def handle_stream(request: web.Request) -> web.StreamResponse:
    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
    await response.prepare(request)

    queue: asyncio.Queue = asyncio.Queue(maxsize=STREAM_QUEUE_MAX)
    bot_state.event_subscribers.append(queue)

    try:
        snapshot = _build_snapshot()
        payload = f"id: {snapshot['seq']}\ndata: {json.dumps(snapshot, ensure_ascii=False)}\n\n"
        await response.write(payload.encode("utf-8"))

        while True:
            
            transport = request.transport
            if transport is None:
                break
            try:
                is_closing = getattr(transport, "is_closing", None)
                if callable(is_closing) and is_closing():
                    break
            except Exception:
                pass

            try:
                envelope = await asyncio.wait_for(queue.get(), timeout=STREAM_KEEPALIVE)
                if envelope.get("type") == "resync":
                    resync = _build_snapshot()
                    line = (f"id: {resync['seq']}\ndata: "
                            f"{json.dumps(resync, ensure_ascii=False)}\n\n")
                    await response.write(line.encode("utf-8"))
                    continue
                line = (f"id: {envelope['seq']}\ndata: "
                        f"{json.dumps(envelope, ensure_ascii=False)}\n\n")
                await response.write(line.encode("utf-8"))
            except asyncio.TimeoutError:
                await response.write(b": keepalive\n\n")
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                break
    except asyncio.CancelledError:
        raise
    except Exception:
        pass
    finally:
        try:
            bot_state.event_subscribers.remove(queue)
        except ValueError:
            pass
        try:
            await response.write_eof()
        except Exception:
            pass

    return response


async def _periodic_flush(app: web.Application) -> None:
    try:
        while True:
            await asyncio.sleep(STATS_WRITE_INTERVAL)
            try:
                await asyncio.to_thread(bot_state._flush_stats_now)
            except Exception:
                pass
            try:
                await asyncio.to_thread(bot_state._flush_activity_now)
            except Exception:
                pass
    except asyncio.CancelledError:
        try:
            await asyncio.to_thread(bot_state.flush_all)
        except Exception:
            pass
        raise


async def _periodic_session_cleanup(app: web.Application) -> None:
    try:
        while True:
            await asyncio.sleep(SESSION_CLEANUP_INTERVAL)
            try:
                await sessions.cleanup()
            except Exception:
                pass
    except asyncio.CancelledError:
        raise


async def _on_cleanup(app: web.Application) -> None:
    try:
        await asyncio.to_thread(bot_state.flush_all)
    except Exception:
        pass


async def start_web_dashboard(host: str = "127.0.0.1", port: int = 5000):
    host = str(host or "127.0.0.1").strip()
    try:
        port = int(port)
    except (TypeError, ValueError):
        raise ValueError("Dashboard port must be an integer")
    if not 1 <= port <= 65535:
        raise ValueError("Dashboard port must be between 1 and 65535")
    if not _is_loopback(host) and not DASHBOARD_API_TOKEN:
        raise RuntimeError(
            "Refusing remote dashboard bind without DASHBOARD_API_TOKEN; "
            "set a strong token or use WEB_HOST=127.0.0.1"
        )

    app = web.Application(
        middlewares=[security_middleware],
        client_max_size=MAX_REQUEST_BYTES,
    )

    app.router.add_get("/", handle_index)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/api/health", handle_health)
    app.router.add_get("/metrics", handle_metrics)
    app.router.add_get("/api/session/status", handle_session_status)
    app.router.add_post("/api/session", handle_session_create)
    app.router.add_post("/api/session/logout", handle_session_logout)
    app.router.add_get("/api/stats", handle_get_stats)
    app.router.add_get("/api/accounts", handle_get_accounts)
    app.router.add_get("/api/account/{login_uid}", handle_get_account)
    app.router.add_get("/api/account/{login_uid}/matches", handle_get_matches)
    app.router.add_get("/api/export", handle_export)
    app.router.add_get("/api/stream", handle_stream)

    app.router.add_get("/api/player/{uid}", handle_player_info)
    app.router.add_get("/api/ban/{uid}", handle_ban_check)
    app.router.add_get("/api/guild/{guild_id}", handle_guild_info)
    app.router.add_get("/api/restart-status", handle_restart_status)
    app.router.add_get("/api/squads", handle_squads_list)

    app.router.add_post("/api/account/add", handle_add_account)
    app.router.add_post("/api/account/bulk-add", handle_bulk_add)
    app.router.add_post("/api/account/delete", handle_delete_account)
    app.router.add_post("/api/account/refresh", handle_refresh_account)
    app.router.add_post("/api/account/start", handle_account_start)
    app.router.add_post("/api/account/stop", handle_account_stop)
    app.router.add_post("/api/account/pause", handle_account_pause)
    app.router.add_post("/api/account/resume", handle_account_resume)
    app.router.add_post("/api/account/pause-all", handle_toggle_pause_all)
    app.router.add_post("/api/logs/clear", handle_clear_logs)

    app.on_cleanup.append(_on_cleanup)

    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    try:
        await site.start()
    except Exception:
        await runner.cleanup()
        raise

    app["_flush_task"] = asyncio.create_task(_periodic_flush(app))
    app["_session_cleanup_task"] = asyncio.create_task(_periodic_session_cleanup(app))

    print(f"[+] EXONIDE PRO dashboard listening on http://{host}:{port}")
    return runner


if __name__ == "__main__":
    async def _self_test() -> None:
        print("EXONIDE PRO dashboard_server.py v5.1 self-test")
        print(f"  schema_version              : {SCHEMA_VERSION}")
        print(f"  level_table loaded          : {level_table.available()}")
        print(f"  accounts restored           : {len(bot_state.accounts)}")
        print(f"  logs restored               : {len(bot_state.logs)}")
        print(f"  max request size            : {MAX_REQUEST_BYTES} bytes")
        print(f"  startup login concurrency   : {STARTUP_LOGIN_CONCURRENCY}")
        print(f"  bulk stagger seconds        : {BULK_STAGGER_SECONDS}")
        print(f"  guild_info available        : {_guild_info is not None}")
        print(f"  auto-restart interval       : {AUTO_RESTART_INTERVAL}s")
        print()

        uid = "level:_selftest_uid"
        bot_state.ensure_placeholder(uid, account_id="9999999", nickname="SelfTest",
                                     region="BD", status="INITIALIZING")
        assert uid in bot_state.accounts
        assert bot_state.accounts[uid]["status"] == "INITIALIZING"
        print("  ensure_placeholder          : OK")

        bot_state.register_account(uid, "9999999", "SelfTest", "BD", 25, 1000, 3)
        acc = bot_state.accounts[uid]
        assert acc["status"] == "ONLINE"
        assert acc["current_exp"] == 1000
        print("  register_account            : OK")

        bot_state.ensure_placeholder(uid, status="INITIALIZING",
                                     status_reason="should not stick")
        acc = bot_state.accounts[uid]
        assert acc["status"] == "ONLINE"
        print("  ensure_placeholder preserves live status : OK")

        bot_state.update_exp(uid, 1250, 25)
        acc = bot_state.accounts[uid]
        assert acc["current_exp"] == 1250
        assert acc["gained_session"] == 250
        assert acc["gained_today"] == 250
        print("  update_exp (+today)         : OK")

        bot_state.record_match_start(uid, {
            "match_id": "abc123", "match_seq": 1,
            "started_at": _now_epoch(), "exp_before": 1250, "level_before": 25,
        })
        assert bot_state.accounts[uid]["matches"]["active"] == 1
        print("  record_match_start          : OK")

        bot_state.update_exp(uid, 1300, 25)
        bot_state.record_match_result(uid, {
            "match_id": "abc123", "match_seq": 1,
            "started_at": _now_epoch() - 60, "ended_at": _now_epoch(),
            "duration_s": 60.0,
            "exp_before": 1250, "exp_after": 1300,
            "level_before": 25, "level_after": 25,
            "end_reason": "natural",
        })
        acc = bot_state.accounts[uid]
        assert acc["matches"]["natural"] == 1
        assert acc["matches"]["active"] == 0
        assert acc["last_match"]["exp_delta"] == 50
        print("  record_match_result         : OK")

        bot_state.update_status(uid, "PAUSED", reason="selftest")
        assert bot_state.accounts[uid]["status"] == "PAUSED"
        assert bot_state.accounts[uid]["status_reason"] == "selftest"
        print("  update_status               : OK")

        bot_state.set_desired_state(uid, "paused")
        assert bot_state.get_desired_state(uid) == "paused"
        assert bot_state.is_paused(uid) is True
        print("  desired_state + is_paused   : OK")

        bot_state.toggle_pause(uid)
        assert bot_state.is_paused(uid) is False
        print("  toggle_pause                : OK")

        sid = await sessions.create({"ip": "127.0.0.1"})
        assert await sessions.validate(sid)
        await sessions.revoke(sid)
        assert not await sessions.validate(sid)
        print("  SessionStore                : OK")

        lock_a = await bot_state.action_lock("lock_key")
        lock_b = await bot_state.action_lock("lock_key")
        assert lock_a is lock_b
        print("  action_lock reuses same lock : OK")

        tmp = Path(tempfile.gettempdir()) / "_exonide_selftest.json"
        _atomic_write_json(tmp, {"hello": "world"})
        assert json.loads(tmp.read_text(encoding="utf-8")) == {"hello": "world"}
        tmp.unlink()
        print("  atomic write                : OK")

        guild_key = "guild:_selftest_guild"
        bot_state.register_account(guild_key, "8888888", "GuildSelfTest", "ID", 10, 500, 0)
        assert bot_state.accounts[guild_key]["bot_type"] == "guild"
        print("  guild prefixed key          : OK")

        uptime = bot_state.get_account_uptime(uid)
        assert uptime >= 0
        print("  get_account_uptime          : OK")

        assert _host_allowed("127.0.0.1", "")
        assert not _host_allowed("evil.example", "")
        print("  _host_allowed hardened      : OK")

        bot_state.accounts.pop(uid, None)
        bot_state.accounts.pop(guild_key, None)
        bot_state.desired_state.pop(uid, None)
        bot_state.desired_state.pop(guild_key, None)
        bot_state.paused_accounts.discard(uid)
        async with bot_state._action_locks_guard:
            bot_state._action_locks.pop("lock_key", None)

        print()
        print("  All self-tests passed.")

    asyncio.run(_self_test())