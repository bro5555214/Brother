from __future__ import annotations

from typing import Dict, List

AUTH_URLS: Dict[str, str] = {
    "garena_connect":        "https://100067.connect.garena.com",
    "guest_token_grant":     "https://100067.connect.garena.com/oauth/guest/token/grant",
    "guest_token_grant_alt": "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    "guest_register":        "https://100067.connect.garena.com/api/v2/oauth/guest:register",
    "ff_connect":            "https://ffmconnect.ppmainecoonghj.com",
    "ff_sdk":                "https://ffmmsdk.ppmainecoonghj.com",
    "major_login_polar":     "https://loginbp.ggpolarbear.com/MajorLogin",
    "major_login_bluefox":   "https://loginbp.common.ggbluefox.com/MajorLogin",
    "major_login_shark":     "https://loginbp.ggblueshark.com/MajorLogin",
    "major_register_polar":  "https://loginbp.ggpolarbear.com/MajorRegister",
}

CLIENT_IND     = "https://client.ind.freefiremobile.com"
CLIENT_POLAR   = "https://clientbp.ggpolarbear.com"
CLIENT_BLUEFOX = "https://clientbp.common.ggbluefox.com"
CLIENT_US      = "https://client.us.freefiremobile.com"

VERSION_URL = "https://version.ggwhitehawk.com/live/ver.php"
BAN_API_URL = "https://ff-banchecker.vercel.app/check?uid={}"


REGIONS: Dict[str, Dict[str, str]] = {
    "IND": {
        "name":              "India",
        "client_url":        CLIENT_IND,
        "login_url":         "https://loginbp.common.ggbluefox.com",
        "login_data_url":    f"{CLIENT_IND}/GetLoginData",
        "personal_show_url": f"{CLIENT_IND}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_IND}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "BD": {
        "name":              "Bangladesh",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "PK": {
        "name":              "Pakistan",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "ID": {
        "name":              "Indonesia",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "VN": {
        "name":              "Vietnam",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "TH": {
        "name":              "Thailand",
        "client_url":        CLIENT_BLUEFOX,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_BLUEFOX}/GetLoginData",
        "personal_show_url": f"{CLIENT_BLUEFOX}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_BLUEFOX}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "ME": {
        "name":              "Middle East",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "SG": {
        "name":              "Singapore",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "PH": {
        "name":              "Philippines",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "MY": {
        "name":              "Malaysia",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "EU": {
        "name":              "Europe",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "RU": {
        "name":              "Russia",
        "client_url":        CLIENT_POLAR,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_POLAR}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_POLAR}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "BR": {
        "name":              "Brazil",
        "client_url":        CLIENT_US,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_US}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_US}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "US": {
        "name":              "United States",
        "client_url":        CLIENT_US,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_US}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_US}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
    "NA": {
        "name":              "North America",
        "client_url":        CLIENT_US,
        "login_url":         "https://loginbp.ggpolarbear.com",
        "login_data_url":    f"{CLIENT_POLAR}/GetLoginData",
        "personal_show_url": f"{CLIENT_US}/GetPlayerPersonalShow",
        "wishlist_url":      f"{CLIENT_US}/GetWishListItems",
        "release_version":   "OB54",
        "client_version":    "1.124.0",
        "connect_url":       "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant",
    },
}

REGION_GROUPS: Dict[str, List[str]] = {
    "client_ind":              ["IND"],
    "clientbp_ggpolarbear":    ["BD", "PK", "ID", "VN", "EU", "RU", "SG", "ME", "PH", "MY"],
    "clientbp_common_bluefox": ["TH"],
    "client_us":               ["BR", "US", "NA"],
}

PRIORITY_REGIONS_LEVEL: List[str] = [
    "BD", "IND", "SG", "TH", "PH", "VN", "MY", "ID", "HK", "TW",
]

PRIORITY_REGIONS_GUILD: List[str] = [
    "ID", "SG", "TH", "MY", "VN", "PH",
]

PRIORITY_REGIONS_PLAYER: List[str] = [
    "BD", "IND", "ME", "SG", "ID", "TH", "VN", "PK", "BR", "US", "EU",
]

def normalise_region(code: str) -> str:
    if not code:
        return "BD"
    return str(code).strip().upper()


def get_region(code: str) -> Dict[str, str]:
    return REGIONS.get(normalise_region(code), REGIONS["BD"])


def get_client_url(code: str) -> str:
    return get_region(code)["client_url"]


def get_login_url(code: str) -> str:
    return get_region(code)["login_url"]


def get_login_data_url(code: str) -> str:
    return get_region(code)["login_data_url"]


def get_personal_show_url(code: str) -> str:
    return get_region(code)["personal_show_url"]


def get_wishlist_url(code: str) -> str:
    return get_region(code)["wishlist_url"]


def get_release_version(code: str) -> str:
    return get_region(code)["release_version"]


def get_client_version(code: str) -> str:
    return get_region(code)["client_version"]


def get_connect_url(code: str) -> str:
    return get_region(code)["connect_url"]


def list_regions() -> List[str]:
    return list(REGIONS.keys())


def region_name(code: str) -> str:
    return get_region(code)["name"]


__all__ = [
    "AUTH_URLS",
    "VERSION_URL",
    "BAN_API_URL",
    "REGIONS",
    "REGION_GROUPS",
    "PRIORITY_REGIONS_LEVEL",
    "PRIORITY_REGIONS_GUILD",
    "PRIORITY_REGIONS_PLAYER",
    "get_region",
    "get_client_url",
    "get_login_url",
    "get_login_data_url",
    "get_personal_show_url",
    "get_wishlist_url",
    "get_release_version",
    "get_client_version",
    "get_connect_url",
    "normalise_region",
    "list_regions",
    "region_name",
]