from __future__ import annotations

import asyncio
import base64
import binascii
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import httpx
import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from google.protobuf import descriptor_pool, json_format
from google.protobuf.internal import builder

import regions as _regions

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PB2_DIR = os.path.join(BASE_DIR, "pb2")
for _p in (PB2_DIR, BASE_DIR):
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

PLAYER_CACHE_FILE = os.path.join(DATA_DIR, "player_cache.json")
PLAYER_STATS_FILE = os.path.join(DATA_DIR, "player_stats.json")
IMAGE_CACHE_FILE  = os.path.join(DATA_DIR, "player_image_cache.json")
TOKEN_CACHE_FILE  = os.path.join(DATA_DIR, "token_cache.json")
TOKEN_DIR         = DATA_DIR

MAIN_KEY  = "Yg&tc%DEuh6%Zc^8"
MAIN_IV   = "6oyZDr22E3ychjM%"
USERAGENT = "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)"

CACHE_TTL       = 300
IMAGE_CACHE_TTL = 3600
TOKEN_FILE_TTL  = 5.0


_pool = descriptor_pool.Default()


def _register(name: str, desc: bytes, classes: List[str]) -> Dict[str, Any]:
    try:
        fdp = _pool.AddSerializedFile(desc)
    except Exception:
        fdp = _pool.FindFileByName(name)
    try:
        builder.BuildMessageAndEnumDescriptors(fdp, globals())
    except Exception:
        pass
    try:
        builder.BuildTopDescriptorsAndMessages(
            fdp, name.replace(".proto", "_pb2"), globals())
    except Exception:
        pass
    return {c: globals().get(c) for c in classes}


uid_generator = None
try:
    import uid_generator_pb2 as _uid_ext
    uid_generator = _uid_ext.uid_generator
    logger.info("[PROTO] uid_generator from external .pb2")
except ImportError:
    pass

if uid_generator is None:
    _UID_DESC = (
        b'\n\x13uid_generator.proto\"0\n\ruid_generator\x12\x0f\n\x07saturn_'
        b'\x18\x01 \x01(\x03\x12\x0e\n\x06garena\x18\x02 \x01(\x03\x62\x06proto3'
    )
    uid_generator = _register(
        "uid_generator.proto", _UID_DESC, ["uid_generator"])["uid_generator"]
    logger.info("[PROTO] uid_generator from embedded")


AccountPersonalShowInfo = None
try:
    import data_pb2 as _data_ext
    AccountPersonalShowInfo = _data_ext.AccountPersonalShowInfo
    logger.info("[PROTO] data from external .pb2")
except ImportError:
    pass

if AccountPersonalShowInfo is None:
    _DATA_DESC = (
        b'\n\ndata.proto\x12\x05proto\"\xfd\x04\n\x17\x41\x63\x63ountPersonalShowInfo'
        b'\x12+\n\nbasic_info\x18\x01 \x01(\x0b\x32\x17.proto.AccountInfoBasic\x12*'
        b'\n\x0cprofile_info\x18\x02 \x01(\x0b\x32\x14.proto.AvatarProfile\x12\x1f\n'
        b'\x17ranking_leaderboard_pos\x18\x03 \x01(\x05\x12\x1d\n\x04news\x18\x04 '
        b'\x03(\x0b\x32\x0f.proto.NewsItem\x12-\n\x0fhistory_ep_info\x18\x05 \x03('
        b'\x0b\x32\x14.proto.HistoryEpInfo\x12-\n\x0f\x63lan_basic_info\x18\x06 \x01'
        b'(\x0b\x32\x14.proto.ClanInfoBasic\x12\x33\n\x12\x63\x61ptain_basic_info\x18'
        b'\x07 \x01(\x0b\x32\x17.proto.AccountInfoBasic\x12 \n\x08pet_info\x18\x08 '
        b'\x01(\x0b\x32\x0e.proto.PetInfo\x12+\n\x0bsocial_info\x18\t \x01(\x0b\x32'
        b'\x16.proto.SocialBasicInfo\x12/\n\x10\x64iamond_cost_res\x18\n \x01(\x0b'
        b'\x32\x15.proto.DiamondCostRes\x12\x31\n\x11\x63redit_score_info\x18\x0b '
        b'\x01(\x0b\x32\x16.proto.CreditScoreInfo\x12\x33\n\x12pre_veteran_action\x18'
        b'\x0c \x01(\x0b\x32\x17.proto.PreVeteranAction\x12\x39\n\x15\x65quipped_'
        b'achievements\x18\r \x03(\x0b\x32\x1a.proto.EquippedAchievement\x12\x13\n'
        b'\x0bmmr_ratings\x18\x0e \x03(\x05\"\xf5\x06\n\x10\x41\x63\x63ountInfoBasic'
        b'\x12\x12\n\naccount_id\x18\x01 \x01(\x04\x12\x14\n\x0c\x61\x63\x63ount_type'
        b'\x18\x02 \x01(\r\x12\x10\n\x08nickname\x18\x03 \x01(\t\x12\x0e\n\x06region'
        b'\x18\x05 \x01(\t\x12\r\n\x05level\x18\x06 \x01(\r\x12\x0b\n\x03\x65xp\x18'
        b'\x07 \x01(\r\x12\x11\n\tbanner_id\x18\x0b \x01(\r\x12\x10\n\x08head_pic\x18'
        b'\x0c \x01(\r\x12\x0c\n\x04rank\x18\x0e \x01(\r\x12\x16\n\x0eranking_points'
        b'\x18\x0f \x01(\r\x12\x16\n\x0ehas_elite_pass\x18\x11 \x01(\x08\x12\x11\n\t'
        b'badge_cnt\x18\x12 \x01(\r\x12\x10\n\x08\x62\x61\x64ge_id\x18\x13 \x01(\r'
        b'\x12\x11\n\tseason_id\x18\x14 \x01(\r\x12\r\n\x05liked\x18\x15 \x01(\r\x12'
        b'\x11\n\tshow_rank\x18\x17 \x01(\x08\x12\x15\n\rlast_login_at\x18\x18 \x01'
        b'(\x03\x12\x0f\n\x07\x63s_rank\x18\x1e \x01(\r\x12\x19\n\x11\x63s_ranking_'
        b'points\x18\x1f \x01(\r\x12\x19\n\x11weapon_skin_shows\x18  \x03(\r\x12\x10'
        b'\n\x08max_rank\x18# \x01(\r\x12\x13\n\x0b\x63s_max_rank\x18$ \x01(\r\x12'
        b'\x15\n\rpeak_rank_pos\x18\' \x01(\r\x12.\n\x0f\x61\x63\x63ount_prefers\x18'
        b') \x01(\x0b\x32\x15.proto.AccountPrefers\x12\x11\n\tcreate_at\x18, \x01('
        b'\x03\x12\r\n\x05title\x18\x30 \x01(\r\x12\x33\n\x12\x65xternal_icon_info'
        b'\x18\x31 \x01(\x0b\x32\x17.proto.ExternalIconInfo\x12\x17\n\x0frelease_'
        b'version\x18\x32 \x01(\t\x12\x14\n\x0cshow_br_rank\x18\x34 \x01(\x08\x12'
        b'\x14\n\x0cshow_cs_rank\x18\x35 \x01(\x08\x12\x32\n\x11social_highlights'
        b'\x18= \x01(\x0b\x32\x17.proto.SocialHighlights\x12\x15\n\ritem_tag_info'
        b'\x18? \x01(\x0c\x12\x12\n\nhippo_rank\x18\x42 \x01(\r\x12\x1c\n\x14hippo_'
        b'ranking_points\x18\x43 \x01(\r\x12+\n\x0f\x63s_rank_entries\x18\x41 \x03('
        b'\x0b\x32\x12.proto.CsRankEntry\x12\x19\n\x0craw_field_60\x18< \x01(\rH'
        b'\x00\x88\x01\x01\x42\x0f\n\r_raw_field_60\":\n\x10SocialHighlights\x12&\n'
        b'\x07\x65ntries\x18\x01 \x03(\x0b\x32\x15.proto.HighlightEntry\"a\n\x0e'
        b'HighlightEntry\x12\x11\n\tseason_id\x18\x01 \x01(\r\x12\x16\n\x0ehighlight_'
        b'type\x18\x02 \x01(\r\x12$\n\x05stats\x18\x03 \x01(\x0b\x32\x15.proto.'
        b'HighlightStats\"x\n\x0eHighlightStats\x12\x0c\n\x04mode\x18\x01 \x01(\r'
        b'\x12\x16\n\x0ematches_played\x18\x02 \x01(\r\x12\x13\n\x0bmatches_won\x18'
        b'\x03 \x01(\r\x12\x16\n\x0etop_percentage\x18\x04 \x01(\r\x12\x13\n\x0b'
        b'season_rank\x18\x05 \x01(\r\"E\n\x0b\x43sRankEntry\x12\x0f\n\x07mode_id'
        b'\x18\x01 \x01(\r\x12\x0e\n\x06points\x18\x02 \x01(\r\x12\x15\n\runlock_'
        b'status\x18\x03 \x01(\r\"\xb3\x01\n\x0e\x41\x63\x63ountPrefers\x12\x17\n'
        b'\x0f\x62r_pregame_show\x18\x01 \x01(\r\x12\x16\n\x0ehide_clan_info\x18\x04'
        b' \x01(\x08\x12\x19\n\x11hide_weapon_skins\x18\x05 \x01(\x08\x12\x17\n\x0f'
        b'show_elite_pass\x18\x07 \x01(\x08\x12\x12\n\nshow_title\x18\x08 \x01(\x08'
        b'\x12\x18\n\x0braw_field_3\x18\x03 \x01(\rH\x00\x88\x01\x01\x42\x0e\n\x0c'
        b'_raw_field_3\"\xdc\x01\n\rAvatarProfile\x12\x11\n\tavatar_id\x18\x01 \x01'
        b'(\r\x12\x16\n\x0e\x63osmetic_items\x18\x03 \x03(\r\x12\x17\n\x0f\x65quipped'
        b'_skills\x18\x04 \x03(\r\x12\x1a\n\x12pve_primary_weapon\x18\x06 \x01(\r'
        b'\x12%\n\x0bskill_slots\x18\x05 \x03(\x0b\x32\x10.proto.SkillSlot\x12\x18'
        b'\n\x10skin_unlock_time\x18\x08 \x01(\r\x12\x19\n\x0craw_field_12\x18\x0c '
        b'\x01(\rH\x00\x88\x01\x01\x42\x0f\n\r_raw_field_12\"1\n\tSkillSlot\x12\x12'
        b'\n\nslot_index\x18\x01 \x01(\r\x12\x10\n\x08skill_id\x18\x02 \x01(\r\"\x89'
        b'\x01\n\rClanInfoBasic\x12\x0f\n\x07\x63lan_id\x18\x01 \x01(\x04\x12\x11'
        b'\n\tclan_name\x18\x02 \x01(\t\x12\x12\n\ncaptain_id\x18\x03 \x01(\x04\x12'
        b'\x12\n\nclan_level\x18\x04 \x01(\r\x12\x13\n\x0bmax_members\x18\x05 \x01'
        b'(\r\x12\x17\n\x0f\x63urrent_members\x18\x06 \x01(\r\"\x88\x01\n\x07PetInfo'
        b'\x12\x0e\n\x06pet_id\x18\x01 \x01(\r\x12\x10\n\x08pet_name\x18\x02 \x01'
        b'(\t\x12\r\n\x05level\x18\x03 \x01(\r\x12\x0b\n\x03\x65xp\x18\x04 \x01(\r'
        b'\x12\x13\n\x0bis_selected\x18\x05 \x01(\x08\x12\x0f\n\x07skin_id\x18\x06 '
        b'\x01(\r\x12\x19\n\x11selected_skill_id\x18\t \x01(\r\"\xd4\x01\n\x0f'
        b'SocialBasicInfo\x12\x12\n\naccount_id\x18\x01 \x01(\x04\x12\x1d\n\x06gender'
        b'\x18\x02 \x01(\x0e\x32\r.proto.Gender\x12!\n\x08language\x18\x03 \x01(\x0e'
        b'\x32\x0f.proto.Language\x12\x18\n\x10social_highlight\x18\t \x01(\t\x12\''
        b'\n\x07privacy\x18\n \x01(\x0e\x32\x16.proto.PrivacySettings\x12(\n\x0cregion'
        b'_stats\x18\x0e \x03(\x0b\x32\x12.proto.RegionStats\"\x92\x01\n\x0bRegionStats'
        b'\x12\x13\n\x0bregion_code\x18\x01 \x01(\x0c\x12\x15\n\rtotal_matches\x18'
        b'\x02 \x01(\r\x12\x0c\n\x04wins\x18\x03 \x01(\r\x12\x14\n\x0chighest_rank'
        b'\x18\x04 \x01(\r\x12\x1a\n\x12last_season_played\x18\x05 \x01(\r\x12\x17'
        b'\n\x0flast_match_time\x18\x06 \x01(\x03\"\\\n\x0f\x43reditScoreInfo\x12\r\n'
        b'\x05score\x18\x01 \x01(\r\x12\x0e\n\x06status\x18\x03 \x01(\r\x12\r\n\x05'
        b'start\x18\x08 \x01(\x03\x12\x0b\n\x03\x65nd\x18\t \x01(\x03\x12\x0e\n\x06'
        b'reason\x18\n \x01(\r\"\x89\x01\n\x10\x45xternalIconInfo\x12!\n\x06status'
        b'\x18\x01 \x01(\x0e\x32\x11.proto.IconStatus\x12(\n\tshow_type\x18\x02 \x01'
        b'(\x0e\x32\x15.proto.IconVisibility\x12\x18\n\x0braw_field_3\x18\x03 \x01('
        b'\rH\x00\x88\x01\x01\x42\x0e\n\x0c_raw_field_3\"\x85\x02\n\x08NewsItem\x12'
        b'\x0f\n\x07news_id\x18\x01 \x01(\x05\x12\x14\n\x0c\x63ontent_data\x18\x02 '
        b'\x01(\x0c\x12\x11\n\tnews_type\x18\x03 \x01(\x05\x12\x10\n\x08priority'
        b'\x18\x04 \x01(\x05\x12\x14\n\x0cpublish_time\x18\x05 \x01(\x03\x12\x13\n'
        b'\x0b\x65xpire_time\x18\x06 \x01(\x03\x12-\n\nextra_info\x18\x07 \x01(\x0b'
        b'\x32\x19.proto.NewsItem.NewsExtra\x1aS\n\tNewsExtra\x12\x17\n\x0fsource_'
        b'platform\x18\x01 \x01(\x05\x12\x19\n\x11localization_data\x18\x02 \x01(\x0c'
        b'\x12\x12\n\nimage_data\x18\x03 \x01(\x0c\"\xe4\x01\n\rHistoryEpInfo\x12\x11'
        b'\n\tseason_id\x18\x01 \x01(\x05\x12\x12\n\nepisode_id\x18\x02 \x01(\x05'
        b'\x12\x30\n\x05stats\x18\x03 \x01(\x0b\x32!.proto.HistoryEpInfo.EpisodeStats'
        b'\x1az\n\x0c\x45pisodeStats\x12\x16\n\x0ematches_played\x18\x01 \x01(\x05'
        b'\x12\x16\n\x0etop_placements\x18\x02 \x01(\x05\x12\r\n\x05kills\x18\x03 '
        b'\x01(\x05\x12\x14\n\x0c\x64\x61mage_dealt\x18\x04 \x01(\x05\x12\x15\n\r'
        b'survival_time\x18\x05 \x01(\x05\"W\n\x0e\x44iamondCostRes\x12\x14\n\x0c'
        b'\x64iamond_cost\x18\x01 \x01(\r\x12\x15\n\rcurrency_type\x18\x02 \x01(\r'
        b'\x12\x18\n\x10\x64iscount_percent\x18\x03 \x01(\r\"C\n\x10PreVeteranAction'
        b'\x12\x13\n\x0b\x61\x63tion_type\x18\x01 \x01(\r\x12\x1a\n\x12\x61\x63tion_'
        b'expire_time\x18\x02 \x01(\x03\"\\\n\x13\x45quippedAchievement\x12\x16\n'
        b'\x0e\x61\x63hievement_id\x18\x01 \x01(\r\x12\x16\n\x0eprogress_value\x18'
        b'\x02 \x01(\r\x12\x15\n\runlock_status\x18\x03 \x01(\r*@\n\x06Gender\x12\x12'
        b'\n\x0eGENDER_UNKNOWN\x10\x00\x12\x0f\n\x0bGENDER_MALE\x10\x02\x12\x11\n\r'
        b'GENDER_FEMALE\x10\x01*O\n\x08Language\x12\x14\n\x10LANGUAGE_UNKNOWN\x10'
        b'\x00\x12\x14\n\x10LANGUAGE_ENGLISH\x10\x01\x12\x17\n\x13LANGUAGE_PORTUGUESE'
        b'\x10\x07*Q\n\x0fPrivacySettings\x12\x10\n\x0cPRIVACY_OPEN\x10\x00\x12\x18'
        b'\n\x14PRIVACY_FRIENDS_ONLY\x10\x01\x12\x12\n\x0ePRIVACY_CLOSED\x10\x02*0\n'
        b'\nIconStatus\x12\x11\n\rICON_INACTIVE\x10\x00\x12\x0f\n\x0bICON_ACTIVE\x10'
        b'\x01*3\n\x0eIconVisibility\x12\x0f\n\x0bICON_HIDDEN\x10\x00\x12\x10\n\x0c'
        b'ICON_VISIBLE\x10\x01\x62\x06proto3'
    )
    AccountPersonalShowInfo = _register(
        "data.proto", _DATA_DESC, ["AccountPersonalShowInfo"]
    )["AccountPersonalShowInfo"]
    logger.info("[PROTO] data from embedded")


CSGetWishListItemsReq = None
CSGetWishListItemsRes = None
try:
    import GetWishListItems_pb2 as _wish_ext
    CSGetWishListItemsReq = _wish_ext.CSGetWishListItemsReq
    CSGetWishListItemsRes = _wish_ext.CSGetWishListItemsRes
    logger.info("[PROTO] wishlist from external .pb2")
except ImportError:
    pass

if CSGetWishListItemsReq is None or CSGetWishListItemsRes is None:
    _WISH_DESC = (
        b'\n\x16GetWishListItems.proto\x12\x05proto\"+\n\x15\x43SGetWishListItemsReq'
        b'\x12\x12\n\naccount_id\x18\x01 \x01(\x04\"5\n\x0cWishItemInfo\x12\x0f\n'
        b'\x07item_id\x18\x01 \x01(\r\x12\x14\n\x0crelease_time\x18\x02 \x01(\x04'
        b'\";\n\x15\x43SGetWishListItemsRes\x12\"\n\x05items\x18\x01 \x03(\x0b\x32'
        b'\x13.proto.WishItemInfob\x06proto3'
    )
    _w = _register(
        "GetWishListItems.proto", _WISH_DESC,
        ["CSGetWishListItemsReq", "CSGetWishListItemsRes"])
    CSGetWishListItemsReq = CSGetWishListItemsReq or _w["CSGetWishListItemsReq"]
    CSGetWishListItemsRes = CSGetWishListItemsRes or _w["CSGetWishListItemsRes"]
    logger.info("[PROTO] wishlist from embedded")


def _load_json(path: str) -> Any:
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _save_json(path: str, data: Any) -> None:
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        os.replace(tmp, path)
    except Exception as e:
        logger.warning(f"save {path}: {e}")


def _file_mtime(path: str) -> float:
    try:
        return os.path.getmtime(path)
    except Exception:
        return 0.0


class PlayerStorage:

    def __init__(self):
        self.cache: Dict[str, Any] = _load_json(PLAYER_CACHE_FILE) or {}
        self.stats: Dict[str, Any] = _load_json(PLAYER_STATS_FILE) or {}
        self.images: Dict[str, Any] = _load_json(IMAGE_CACHE_FILE) or {}

    def save(self) -> None:
        _save_json(PLAYER_CACHE_FILE, self.cache)
        _save_json(PLAYER_STATS_FILE, self.stats)
        _save_json(IMAGE_CACHE_FILE, self.images)

    def get_cached(self, key: str) -> Optional[Dict]:
        entry = self.cache.get(key)
        if not entry:
            return None
        if time.time() - entry.get("ts", 0) > CACHE_TTL:
            return None
        return entry.get("data")

    def put_cached(self, key: str, data: Dict) -> None:
        self.cache[key] = {"data": data, "ts": time.time()}
        self.save()

    def get_image(self, key: str) -> Optional[bytes]:
        entry = self.images.get(key)
        if not entry:
            return None
        if time.time() - entry.get("ts", 0) > IMAGE_CACHE_TTL:
            return None
        try:
            return base64.b64decode(entry["data"])
        except Exception:
            return None

    def put_image(self, key: str, img: bytes) -> None:
        self.images[key] = {
            "data": base64.b64encode(img).decode("ascii"),
            "ts": time.time(),
        }
        self.save()

    def bump_stats(self, uid: str, region: str) -> None:
        k = f"{region.upper()}_{uid}"
        entry = self.stats.get(k) or {
            "uid": uid, "region": region.upper(),
            "first_seen": datetime.now().isoformat(),
            "search_count": 0,
        }
        entry["last_seen"] = datetime.now().isoformat()
        entry["search_count"] = int(entry.get("search_count", 0)) + 1
        self.stats[k] = entry
        self.save()


player_storage = PlayerStorage()


class TokenManager:

    def __init__(self):
        self._manual: Dict[str, List[str]] = {}
        self._cache_tokens: Dict[str, List[str]] = {}
        self._index: Dict[str, int] = {}
        self._invalid: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()
        self._last_mtime: float = 0.0
        self._last_refresh: float = 0.0

    def _manual_file(self, region: str) -> str:
        return os.path.join(TOKEN_DIR, f"token_{region.lower()}.json")

    def _load_manual(self, region: str) -> List[str]:
        data = _load_json(self._manual_file(region))
        if not isinstance(data, list):
            return []
        out: List[str] = []
        for item in data:
            if isinstance(item, dict) and item.get("token"):
                out.append(str(item["token"]).strip())
            elif isinstance(item, str) and item.strip():
                out.append(item.strip())
        return out

    def _load_cache_tokens(self) -> Dict[str, List[str]]:
        raw = _load_json(TOKEN_CACHE_FILE)
        grouped: Dict[str, List[str]] = {}
        if not isinstance(raw, dict):
            return grouped
        for _key, entry in raw.items():
            if not isinstance(entry, dict):
                continue
            token = entry.get("access_token")
            if not token:
                continue
            region = (entry.get("region") or "").upper()
            if not region or region not in _regions.REGIONS:
                continue
            grouped.setdefault(region, [])
            if token not in grouped[region]:
                grouped[region].append(token)
        return grouped

    def _maybe_refresh_cache_tokens(self) -> None:
        now = time.time()
        if now - self._last_refresh < TOKEN_FILE_TTL:
            return
        mtime = _file_mtime(TOKEN_CACHE_FILE)
        if mtime == self._last_mtime and self._cache_tokens:
            self._last_refresh = now
            return
        self._last_mtime = mtime
        self._last_refresh = now
        self._cache_tokens = self._load_cache_tokens()

    @staticmethod
    def _runtime_tokens(region: str) -> List[str]:
        try:
            from dashboard_server import bot_state
        except Exception:
            return []
        out: List[str] = []
        for creds in list(bot_state.account_credentials.values()):
            if not isinstance(creds, dict):
                continue
            if (creds.get("region") or "").upper() != region.upper():
                continue
            tok = creds.get("access_token")
            if tok and tok not in out:
                out.append(tok)
        return out

    def _pool(self, region: str) -> List[str]:
        region = region.upper()
        self._maybe_refresh_cache_tokens()
        if region not in self._manual:
            self._manual[region] = self._load_manual(region)
        pool = (
            list(self._manual.get(region, []))
            + list(self._cache_tokens.get(region, []))
            + self._runtime_tokens(region)
        )
        seen: set = set()
        return [t for t in pool if not (t in seen or seen.add(t))]

    async def get(self, region: str) -> Optional[str]:
        region = region.upper()
        async with self._lock:
            pool = self._pool(region)
            if not pool:
                logger.warning(f"[TOKEN] no tokens available for {region}")
                return None
            n = len(pool)
            self._index.setdefault(region, 0)
            self._invalid.setdefault(region, [])
            for _ in range(n):
                idx = self._index[region]
                tok = pool[idx]
                self._index[region] = (idx + 1) % n
                if tok not in self._invalid[region]:
                    return tok
            return None

    def add(self, region: str, token: str) -> int:
        region = region.upper()
        path = self._manual_file(region)
        existing = _load_json(path) or []
        if not isinstance(existing, list):
            existing = []
        existing.append({"token": token.strip()})
        _save_json(path, existing)
        self._manual[region] = self._load_manual(region)
        self._index[region] = 0
        self._invalid[region] = []
        return len(self._manual[region])

    def mark_invalid(self, region: str, token: str) -> None:
        region = region.upper()
        self._invalid.setdefault(region, [])
        if token not in self._invalid[region]:
            self._invalid[region].append(token)

    def clear_invalid(self, region: str) -> None:
        self._invalid[region.upper()] = []

    def list_tokens(self, region: str) -> Tuple[List[str], List[str]]:
        return self._pool(region), self._invalid.get(region.upper(), [])

    def sources(self, region: str) -> Dict[str, int]:
        region = region.upper()
        self._maybe_refresh_cache_tokens()
        if region not in self._manual:
            self._manual[region] = self._load_manual(region)
        return {
            "manual":  len(self._manual.get(region, [])),
            "cache":   len(self._cache_tokens.get(region, [])),
            "runtime": len(self._runtime_tokens(region)),
            "invalid": len(self._invalid.get(region, [])),
        }


player_tokens = TokenManager()


def encrypt_aes(hex_data: str, key: str = MAIN_KEY, iv: str = MAIN_IV) -> str:
    key_b = key.encode()[:16]
    iv_b = iv.encode()[:16]
    cipher = AES.new(key_b, AES.MODE_CBC, iv_b)
    padded = pad(bytes.fromhex(hex_data), AES.block_size)
    return binascii.hexlify(cipher.encrypt(padded)).decode()


def _headers(region: str, token: str) -> Dict[str, str]:
    return {
        "User-Agent": USERAGENT,
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/octet-stream",
        "Expect": "100-continue",
        "Authorization": f"Bearer {token}",
        "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1",
        "ReleaseVersion": _regions.get_release_version(region),
    }


def _try_struct_parse(blob: bytes) -> Optional[Dict[str, Any]]:
    if AccountPersonalShowInfo is None:
        return None
    for candidate in (blob, blob[5:] if len(blob) > 5 else b""):
        if not candidate:
            continue
        try:
            msg = AccountPersonalShowInfo()
            msg.ParseFromString(candidate)
        except Exception:
            continue
        if getattr(msg, "basic_info", None) and msg.basic_info.account_id:
            try:
                d = json.loads(json_format.MessageToJson(msg))
            except Exception:
                continue
            return {
                "basicInfo":            d.get("basicInfo", {}),
                "clanBasicInfo":        d.get("clanBasicInfo", {}),
                "socialInfo":           d.get("socialInfo", {}),
                "petInfo":              d.get("petInfo", {}),
                "profileInfo":          d.get("profileInfo", {}),
                "creditScoreInfo":      d.get("creditScoreInfo", {}),
                "captainBasicInfo":     d.get("captainBasicInfo", {}),
                "news":                 d.get("news", []),
                "historyEpInfo":        d.get("historyEpInfo", []),
                "equippedAchievements": d.get("equippedAchievements", []),
                "mmrRatings":           d.get("mmrRatings", []),
                "diamondCostRes":       d.get("diamondCostRes", {}),
                "preVeteranAction":     d.get("preVeteranAction", {}),
            }
    return None


async def fetch_player_info(uid: str, region: str = "BD",
                            timeout: float = 30.0,
                            force: bool = False) -> Optional[Dict[str, Any]]:
    region = region.upper()
    cache_key = f"player_{region}_{uid}"
    if not force:
        cached = player_storage.get_cached(cache_key)
        if cached:
            return cached

    pool, _ = player_tokens.list_tokens(region)
    attempts = max(1, len(pool) + 1)

    for _ in range(attempts):
        token = await player_tokens.get(region)
        if not token:
            logger.warning(f"[PLAYER] no tokens for {region}")
            return None

        msg = uid_generator()
        msg.saturn_ = int(uid)
        msg.garena = 1
        enc = encrypt_aes(binascii.hexlify(msg.SerializeToString()).decode())

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(
                    _regions.get_personal_show_url(region),
                    data=bytes.fromhex(enc),
                    headers=_headers(region, token),
                )
        except Exception as e:
            logger.error(f"[PLAYER] {region} {uid} net: {e}")
            return None

        if resp.status_code == 401:
            player_tokens.mark_invalid(region, token)
            continue
        if resp.status_code != 200:
            logger.error(f"[PLAYER] HTTP {resp.status_code} {region}")
            return None

        structured = _try_struct_parse(resp.content) or {}
        result: Dict[str, Any] = dict(structured)
        result["ban_status"] = (
            "BANNED" if result.get("isBanned", False) else "UNBANNED")
        result["_region"] = region
        result["_uid"] = uid
        result["_fetched_at"] = datetime.now().isoformat()
        result["raw_hex"] = resp.content.hex()

        player_storage.put_cached(cache_key, result)
        player_storage.bump_stats(uid, region)
        return result

    logger.error(f"[PLAYER] tokens exhausted for {region}")
    return None


async def fetch_wishlist(uid: str, region: str = "BD",
                         timeout: float = 30.0) -> Optional[Dict[str, Any]]:
    region = region.upper()
    cache_key = f"wishlist_{region}_{uid}"
    cached = player_storage.get_cached(cache_key)
    if cached:
        return cached

    token = await player_tokens.get(region)
    if not token:
        return None

    req = CSGetWishListItemsReq()
    req.account_id = int(uid)
    enc = encrypt_aes(binascii.hexlify(req.SerializeToString()).decode())

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                _regions.get_wishlist_url(region),
                data=bytes.fromhex(enc),
                headers=_headers(region, token),
            )
    except Exception as e:
        logger.error(f"[WISH] {region} {uid} net: {e}")
        return None

    if resp.status_code == 401:
        player_tokens.mark_invalid(region, token)
        return None
    if resp.status_code != 200:
        return None

    try:
        res = CSGetWishListItemsRes()
        res.ParseFromString(resp.content)
        items = [{"item_id": it.item_id, "release_time": it.release_time}
                 for it in res.items]
    except Exception:
        return None

    result = {"items": items, "_region": region, "_uid": uid}
    player_storage.put_cached(cache_key, result)
    return result


async def fetch_avatar(head_pic_id: int) -> Optional[bytes]:
    if not head_pic_id:
        return None
    cache_key = f"avatar_{head_pic_id}"
    cached = player_storage.get_image(cache_key)
    if cached:
        return cached

    urls = [
        f"https://avatar.freefire.com/avatar/{head_pic_id}.png",
        f"https://avatar.freefire.com/avatar/{head_pic_id}.jpg",
        f"https://cdn.freefire.com/avatar/{head_pic_id}.png",
    ]
    async with httpx.AsyncClient(timeout=10.0) as client:
        for u in urls:
            try:
                r = await client.get(u)
                if r.status_code == 200 and len(r.content) > 100:
                    player_storage.put_image(cache_key, r.content)
                    return r.content
            except Exception:
                continue
    return None


async def check_ban(uid: str, timeout: float = 15.0) -> Optional[Dict[str, Any]]:
    def _do() -> Optional[Dict[str, Any]]:
        try:
            r = requests.get(_regions.BAN_API_URL.format(uid),
                             timeout=timeout, verify=False)
            try:
                data = r.json()
            except json.JSONDecodeError:
                return None
            if isinstance(data, list) and data:
                data = data[0]
            if not isinstance(data, dict):
                return None
            if "account_id" not in data and "error" in data:
                return {"error": data.get("error")}
            return data
        except Exception as e:
            logger.error(f"[BAN] {uid}: {e}")
            return None

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _do)


def ban_summary(ban: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not ban:
        return {"known": False, "banned": None}
    if "error" in ban and "account_id" not in ban:
        return {"known": False, "banned": None, "error": ban["error"]}
    bi = ban.get("ban_info", {}) or {}
    status_lower = str(bi.get("status", "")).lower()
    duration = bi.get("ban_expire_duration")
    duration_valid = bool(
        duration and str(duration).strip().lower() not in
        ("n/a", "none", "null", "unknown", "")
    )
    if "permanent" in status_lower:
        ban_type = "Permanent"
    elif duration_valid:
        ban_type = "Temporary"
    else:
        ban_type = "Permanent"
    return {
        "known": True,
        "banned": bool(bi.get("is_banned")),
        "nickname": ban.get("nickname"),
        "level": ban.get("level"),
        "likes": ban.get("liked"),
        "region": ban.get("region"),
        "prime_level": ban.get("prime_level"),
        "ban_start": bi.get("ban_start_time"),
        "ban_duration": duration,
        "ban_type": ban_type,
    }


async def fetch_guild_info(guild_id: str, region: str = "BD",
                           web_token: Optional[str] = None
                           ) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": "guild_endpoint_not_configured",
        "hint": "Supply guild glory endpoint + DW/TW web token flow.",
        "guild_id": guild_id,
        "region": region.upper(),
    }


_RANK_TABLE = [
    (0, "Bronze I"), (100, "Bronze II"), (200, "Bronze III"),
    (300, "Silver I"), (400, "Silver II"), (500, "Silver III"),
    (600, "Gold I"), (700, "Gold II"), (800, "Gold III"),
    (900, "Platinum I"), (1000, "Platinum II"), (1100, "Platinum III"),
    (1200, "Diamond I"), (1300, "Diamond II"), (1400, "Diamond III"),
    (1500, "Heroic"), (2000, "Master"),
]


def rank_name(points: Any) -> str:
    try:
        p = int(points)
    except Exception:
        return "N/A"
    if p >= 2000:
        return "Grandmaster"
    name = "Bronze I"
    for threshold, label in _RANK_TABLE:
        if p >= threshold:
            name = label
    return name


def ts_bst(ts: Any) -> str:
    try:
        dt = datetime.fromtimestamp(int(ts)) + timedelta(hours=6)
        return dt.strftime("%d %b %Y %I:%M:%S %p") + " (BST)"
    except Exception:
        return "N/A"


def prime_level(val: Any) -> str:
    if isinstance(val, dict):
        return str(val.get("level", "N/A"))
    if val is None:
        return "N/A"
    return str(val)


def _basic(info: Dict[str, Any]) -> Dict[str, Any]:
    return (info.get("basicInfo") or {}) if isinstance(info, dict) else {}


def _clan(info: Dict[str, Any]) -> Dict[str, Any]:
    return (info.get("clanBasicInfo") or {}) if isinstance(info, dict) else {}


def format_terminal(info: Dict[str, Any],
                    ban: Optional[Dict[str, Any]] = None) -> str:
    if not info:
        return "[!] No player data"

    basic = _basic(info)
    clan = _clan(info)

    out: List[str] = []
    A = out.append

    A("== BASIC ==")
    A(f"  UID        : {info.get('_uid', 'N/A')}")
    A(f"  Region     : {info.get('_region', 'N/A')}")
    A(f"  Nickname   : {basic.get('nickname', 'N/A')}")
    A(f"  Level      : {basic.get('level', 'N/A')}")
    A(f"  EXP        : {basic.get('exp', 'N/A')}")
    A(f"  Likes      : {basic.get('liked', 'N/A')}")
    A(f"  BR Points  : {basic.get('rankingPoints', 'N/A')} "
      f"({rank_name(basic.get('rankingPoints', 0))})")
    A(f"  Elite Pass : {'YES' if basic.get('hasElitePass') else 'NO'}")
    A(f"  Prime Lvl  : {prime_level(basic.get('primeLevel'))}")
    A(f"  Created    : {ts_bst(basic.get('createAt', 0))}")
    A(f"  Last Login : {ts_bst(basic.get('lastLoginAt', 0))}")

    if clan:
        A("")
        A("== CLAN ==")
        A(f"  Name       : {clan.get('clanName', 'N/A')}")
        A(f"  ID         : {clan.get('clanId', 'N/A')}")
        A(f"  Level      : {clan.get('clanLevel', 'N/A')}")
        A(f"  Members    : {clan.get('currentMembers', 'N/A')}"
          f"/{clan.get('maxMembers', 'N/A')}")

    if ban is not None:
        s = ban_summary(ban)
        A("")
        A("== BAN ==")
        if s.get("known"):
            A(f"  Status     : "
              f"{'BANNED' if s.get('banned') else 'NOT BANNED'}")
            if s.get("banned"):
                A(f"  Type       : {s.get('ban_type', 'N/A')}")
                A(f"  Duration   : {s.get('ban_duration', 'N/A')}")
        else:
            A("  Status     : UNKNOWN")

    if not basic:
        A("")
        A("[i] Structured parse empty — raw wire data available.")
        A(f"    raw_hex len: {len(info.get('raw_hex', '')) // 2} bytes")

    return "\n".join(out)


def format_dashboard(info: Dict[str, Any],
                     ban: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not info:
        return {"ok": False, "error": "no_data"}

    basic = _basic(info)
    clan = _clan(info)
    ban_info = ban_summary(ban) if ban is not None else {"known": False}

    return {
        "ok": True,
        "uid": info.get("_uid"),
        "region": info.get("_region"),
        "fetched_at": info.get("_fetched_at"),
        "basic": {
            "account_id": basic.get("accountId"),
            "nickname": basic.get("nickname"),
            "level": basic.get("level"),
            "exp": basic.get("exp"),
            "likes": basic.get("liked"),
            "br_points": basic.get("rankingPoints"),
            "br_rank": rank_name(basic.get("rankingPoints", 0)),
            "elite_pass": bool(basic.get("hasElitePass")),
            "prime_level": prime_level(basic.get("primeLevel")),
            "created": ts_bst(basic.get("createAt", 0)),
            "last_login": ts_bst(basic.get("lastLoginAt", 0)),
        },
        "clan": {
            "id": clan.get("clanId"),
            "name": clan.get("clanName"),
            "level": clan.get("clanLevel"),
            "members": f"{clan.get('currentMembers', '?')}"
                       f"/{clan.get('maxMembers', '?')}",
            "captain_id": clan.get("captainId"),
        },
        "ban": ban_info,
        "raw_hex_len": len(info.get("raw_hex", "")) // 2,
    }


async def lookup(uid: str, region: str = "BD",
                 include_ban: bool = True,
                 force: bool = False) -> Dict[str, Any]:
    info = await fetch_player_info(uid, region, force=force)
    if not info:
        return {"ok": False, "error": "not_found",
                "uid": uid, "region": region.upper()}
    ban: Optional[Dict[str, Any]] = None
    if include_ban:
        try:
            ban = await check_ban(uid)
        except Exception:
            ban = None
    return {
        "ok": True,
        "uid": uid,
        "region": region.upper(),
        "terminal": format_terminal(info, ban),
        "dashboard": format_dashboard(info, ban),
    }


__all__ = [
    "player_tokens",
    "player_storage",
    "fetch_player_info",
    "fetch_wishlist",
    "fetch_avatar",
    "fetch_guild_info",
    "check_ban",
    "ban_summary",
    "lookup",
    "format_terminal",
    "format_dashboard",
    "rank_name",
    "ts_bst",
]