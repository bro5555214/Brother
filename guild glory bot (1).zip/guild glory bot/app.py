from __future__ import annotations

import asyncio
import base64
import hashlib
import itertools
import json
import os
import random
import secrets
import socket
import struct
import sys
import time
import traceback
import unicodedata
import uuid
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

try:
    import httpx
except ImportError:
    raise SystemExit("httpx missing. Run: pip install httpx")

try:
    from google_play_scraper import app as play_scraper
except ImportError:
    raise SystemExit("google-play-scraper missing. Run: pip install google-play-scraper")

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
except ImportError:
    raise SystemExit("pycryptodome missing. Run: pip install pycryptodome")

try:
    from protobuf_decoder.protobuf_decoder import Parser
except ImportError:
    raise SystemExit("protobuf-decoder missing. Run: pip install protobuf-decoder")

try:
    from message_ids import MESSAGE_ID_TO_NAME
except ImportError:
    raise SystemExit("message_ids.py missing from the project folder")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
PB2_DIR = os.path.join(BASE_DIR, "pb2")
if os.path.isdir(PB2_DIR) and PB2_DIR not in sys.path:
    sys.path.insert(0, PB2_DIR)
BOTS_DIR = os.path.join(BASE_DIR, "bots")
if os.path.isdir(BOTS_DIR) and BOTS_DIR not in sys.path:
    sys.path.insert(0, BOTS_DIR)

try:
    import thunderFF_pb2 as _canonical_pb2
except ImportError:
    try:
        import RbcFF_pb2 as _canonical_pb2
    except ImportError:
        try:
            import RbcTeam_pb2 as _canonical_pb2
        except ImportError:
            raise SystemExit(
                "No protobuf module found. Put thunderFF_pb2.py (or RbcFF_pb2.py "
                "or RbcTeam_pb2.py) in the project folder or in pb2/."
            )

thunderFF_pb2 = _canonical_pb2
RbcFF_pb2 = _canonical_pb2
RbcTeam_pb2 = _canonical_pb2
CguFF_pb2 = _canonical_pb2
StartMatch_pb2 = _canonical_pb2

try:
    from dashboard_server import bot_state, start_web_dashboard
except ImportError:
    raise SystemExit("dashboard_server.py missing from the project folder")

# ── Region registry (new) ────────────────────────────────────────
try:
    import regions as _regions
except ImportError:
    raise SystemExit("regions.py missing from the project folder")

DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

WEB_HOST = os.environ.get("WEB_HOST", "127.0.0.1")
WEB_PORT = int(os.environ.get("PORT", "5000"))

ACCOUNTS_FILE = os.environ.get("ACCOUNTS_FILE", os.path.join(DATA_DIR, "accounts.json"))
TOKEN_CACHE_FILE = os.path.join(DATA_DIR, "token_cache.json")
DEVICES_FILE = os.path.join(DATA_DIR, "devices.json")
SETTINGS_CACHE_FILE = os.path.join(DATA_DIR, "settings.json")
SQUADS_FILE = os.path.join(DATA_DIR, "squads.json")

TOKEN_CACHE_TTL_LEVEL = 1200
TOKEN_CACHE_TTL_GUILD = 4500

LEVEL_START_MATCH_INTERVAL = float(os.environ.get("LEVEL_START_MATCH_INTERVAL", "4.0"))
LEVEL_NEW_MATCH_DELAY = float(os.environ.get("LEVEL_NEW_MATCH_DELAY", "5.0"))
LEVEL_MAX_MATCH_DURATION = 700
LEVEL_MATCH_IDLE_TIMEOUT = 10.0
LEVEL_EXP_REFRESH_INTERVAL = float(os.environ.get("LEVEL_EXP_REFRESH_INTERVAL", "45.0"))
LEVEL_IDLE_READ_TIMEOUT = 0.5
LEVEL_IDLE_READ_LIMIT = 30
LEVEL_HANDSHAKE_TIMEOUT = 25.0
LEVEL_MAX_IDLE_BEFORE_HELLO_RESEND = 7.0
LEVEL_MAX_CONSECUTIVE_PARSE_FAILURES = 5
LEVEL_NON_MATCH_RECONNECT_DELAY = 1.0

GUILD_START_MATCH_INTERVAL = float(os.environ.get("GUILD_START_MATCH_INTERVAL", "4.0"))
GUILD_NEW_MATCH_DELAY = float(os.environ.get("GUILD_NEW_MATCH_DELAY", "6.0"))
GUILD_MAX_MATCH_DURATION = 3000
GUILD_MATCH_IDLE_TIMEOUT = 90.0
GUILD_EXP_REFRESH_INTERVAL = float(os.environ.get("GUILD_EXP_REFRESH_INTERVAL", "30.0"))
GUILD_EXP_REFRESH_AFTER_MATCH_DELAY = 9.0
GUILD_MAX_CONSECUTIVE_PARSE_FAILURES = 5
GUILD_NON_MATCH_RECONNECT_DELAY = 1.0
GUILD_MATCH_SEARCH_TIMEOUT = 90.0
GUILD_MATCH_WATCHDOG_CHECK = 30.0
GUILD_MAX_SEARCH_ATTEMPTS = 25
GUILD_SQUAD_DEATH_WAIT_TIMEOUT = float(
    os.environ.get("GUILD_SQUAD_DEATH_WAIT_TIMEOUT", "360.0"))

# ── Smart mode: how long to wait for squad peers before playing solo ──
SMART_WAIT_MIN = float(os.environ.get("SMART_WAIT_MIN", "10.0"))
SMART_WAIT_MAX = float(os.environ.get("SMART_WAIT_MAX", "20.0"))
SMART_MODE_ENABLED = os.environ.get("SMART_MODE", "1").lower() not in ("0", "false", "no")
GUILD_TEAM_RETRY_INTERVAL = float(os.environ.get("GUILD_TEAM_RETRY_INTERVAL", "15.0"))
# Continuous search loop even when alone
GUILD_SEARCH_FOREVER = os.environ.get("GUILD_SEARCH_FOREVER", "1").lower() not in (
    "0", "false", "no")

# ── Auto-restart: full-process restart after N seconds (0 = disabled) ──
AUTO_RESTART_INTERVAL = float(os.environ.get("AUTO_RESTART_INTERVAL", "300"))
AUTO_RESTART_ENABLED = AUTO_RESTART_INTERVAL > 0

GUILD_REGION_ROTATION_LIST = list(_regions.PRIORITY_REGIONS_GUILD)
GUILD_REGION_ROTATE_EVERY_N = 2

PRIORITY_REGIONS_LEVEL = list(_regions.PRIORITY_REGIONS_LEVEL)

BR_MODE_ID = 1
BR_MAP_ID = 1

ANTI_AFK_MIN_INTERVAL = 1.8
ANTI_AFK_MAX_INTERVAL = 3.5

SAFE_PLAY_MODE = True
BYPASS_TIMING_JITTER = True
BYPASS_PACKET_JITTER = True
BYPASS_HELLO_DELAY = True
BYPASS_KA_JITTER = True

ENABLE_SPEED_MOVEMENT = True
MOVEMENT_SPEED_MIN = 1.0
MOVEMENT_SPEED_MAX = 1.4
MOVEMENT_PATTERN = "circle"
MOVEMENT_TICK_MS = 240
MOVEMENT_RADIUS = 180
MOVEMENT_UPDATE_SPEED_EVERY = 4.0
MOVEMENT_STATE_IDLE_CHANCE = 0.10
MOVEMENT_STATE_WALK_CHANCE = 0.28
MOVEMENT_STATE_RUN_CHANCE = 0.32
MOVEMENT_STATE_SPRINT_CHANCE = 0.10
MOVEMENT_STATE_JUMP_CHANCE = 0.08
MOVEMENT_STATE_CROUCH_CHANCE = 0.06
MOVEMENT_STATE_PRONE_CHANCE = 0.06

ENABLE_HTTP_PING = True
PING_INTERVAL = 20.0
PING_TIMEOUT = 8.0
PING_URL = "https://loginbp.ppmainecoonghj.com/Ping"
PING_REAL_IP = "103.109.214.211"

TEAM_MODE = True
TEAM_SIZE = int(os.environ.get("TEAM_SIZE", "4"))
TEAM_PEER_WAIT_TIMEOUT = 90.0
TEAM_CREATE_WAIT = 4.0
TEAM_INVITE_CYCLE_WAIT = 4.0
TEAM_INVITE_MAX_TIME = 120.0
TEAM_HEARTBEAT_INTERVAL = 3.0
TEAM_IDLE_ITERS_TEAM = 1800
TEAM_MEMBER_START_DELAY = 20.0
TEAM_FINAL_WAIT = 8.0
TEAM_READY_DELAY = 5.0
_accept_friend_request = True
DEBUG_TEAM_PACKETS = True

STARTUP_LOGIN_CONCURRENCY = int(os.environ.get("STARTUP_LOGIN_CONCURRENCY", "3"))
STARTUP_LOGIN_DELAY = float(os.environ.get("STARTUP_LOGIN_DELAY", "0.4"))

PLAIN_MODE = ("--plain" in sys.argv) or ("--no-ui" in sys.argv)


class ColorMode:
    NONE = "none"
    ANSI16 = "16"
    ANSI256 = "256"
    TRUECOLOR = "truecolor"


def _detect_color_mode() -> str:
    if PLAIN_MODE:
        return ColorMode.NONE
    if os.environ.get("NO_COLOR"):
        return ColorMode.NONE
    if os.environ.get("FORCE_COLOR"):
        return ColorMode.TRUECOLOR
    try:
        if not sys.stdout.isatty():
            return ColorMode.NONE
    except Exception:
        return ColorMode.NONE
    ct = os.environ.get("COLORTERM", "").strip().lower()
    if ct in ("truecolor", "24bit"):
        return ColorMode.TRUECOLOR
    term = os.environ.get("TERM", "").strip().lower()
    if "256color" in term:
        return ColorMode.ANSI256
    if term and term != "dumb":
        return ColorMode.ANSI16
    return ColorMode.NONE


_COLOR_MODE = _detect_color_mode()
_COLOR_ON = _COLOR_MODE != ColorMode.NONE


class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    ITALIC  = "\033[3m"
    UNDER   = "\033[4m"

    BLACK   = "\033[30m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    BLUE    = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN    = "\033[36m"
    WHITE   = "\033[37m"

    BRED     = "\033[91m"
    BGREEN   = "\033[92m"
    BYELLOW  = "\033[93m"
    BBLUE    = "\033[94m"
    BMAGENTA = "\033[95m"
    BCYAN    = "\033[96m"
    BWHITE   = "\033[97m"
    BGRAY    = "\033[90m"

    GOLD     = "\033[38;5;221m"
    GOLD_HI  = "\033[38;5;229m"
    GOLD_LO  = "\033[38;5;178m"
    VIOLET   = "\033[38;5;141m"
    CYAN_HI  = "\033[38;5;87m"
    EMERALD  = "\033[38;5;85m"
    AMBER    = "\033[38;5;222m"
    ROSE     = "\033[38;5;211m"
    MUTED    = "\033[38;5;102m"
    FAINT    = "\033[38;5;240m"


class Colors:
    """Legacy ANSI palette — kept so guild subsystems can use the same names."""
    GREEN   = C.BGREEN
    FAIL    = C.BRED
    WARNING = C.BYELLOW
    CYAN    = C.BCYAN
    MAGENTA = C.BMAGENTA
    WHITE   = C.BWHITE
    ENDC    = C.RESET


def _color(code: str) -> str:
    if not _COLOR_ON:
        return ""
    if _COLOR_MODE in (ColorMode.TRUECOLOR, ColorMode.ANSI256):
        return code
    if _COLOR_MODE == ColorMode.ANSI16:
        mapping = {
            C.GOLD: C.YELLOW, C.GOLD_HI: C.BYELLOW, C.GOLD_LO: C.YELLOW,
            C.VIOLET: C.MAGENTA, C.CYAN_HI: C.BCYAN, C.EMERALD: C.BGREEN,
            C.AMBER: C.YELLOW, C.ROSE: C.BRED, C.MUTED: C.BGRAY, C.FAINT: C.BGRAY,
        }
        return mapping.get(code, code)
    return ""


def paint(text: str, *codes: str) -> str:
    if not _COLOR_ON or not codes:
        return text
    resolved = "".join(_color(c) or c for c in codes)
    return resolved + text + C.RESET


def print_colored(text: str, color: str = Colors.WHITE) -> None:
    if not _COLOR_ON:
        print(text, flush=True)
        return
    print(f"{color}{text}{Colors.ENDC}", flush=True)


def _cw(ch: str) -> int:
    if not ch:
        return 0
    cp = ord(ch)
    if unicodedata.combining(ch):
        return 0
    if cp in (0x200B, 0x200C, 0x200D, 0xFEFF):
        return 0
    if 0xFE00 <= cp <= 0xFE0F:
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    return 1


def _dw(s: str) -> int:
    return sum(_cw(c) for c in s)


def _clip(s: str, width: int, suffix: str = "…") -> str:
    if _dw(s) <= width:
        return s
    sw = _dw(suffix)
    limit = max(0, width - sw)
    out: List[str] = []
    used = 0
    for ch in s:
        c = _cw(ch)
        if used + c > limit:
            break
        out.append(ch)
        used += c
    return "".join(out) + suffix


def _pad(s: str, width: int) -> str:
    return s + " " * max(0, width - _dw(s))


def _wrap(text: str, width: int) -> List[str]:
    if width <= 0:
        return [""]
    out: List[str] = []
    for raw in str(text).splitlines() or [""]:
        if not raw.strip():
            out.append("")
            continue
        words = raw.split()
        line = ""
        for word in words:
            candidate = word if not line else line + " " + word
            if _dw(candidate) <= width:
                line = candidate
                continue
            if line:
                out.append(line)
                line = ""
            while _dw(word) > width:
                piece: List[str] = []
                used = 0
                for ch in word:
                    c = _cw(ch)
                    if used + c > width:
                        break
                    piece.append(ch)
                    used += c
                out.append("".join(piece))
                word = word[len(piece):]
            line = word
        if line:
            out.append(line)
    return out or [""]


BOX_W = 58
_INNER = BOX_W - 4


class Box:

    def __init__(self, title: str = "", color: str = C.BCYAN, width: int = BOX_W):
        self.title = title
        self.color = color
        self.width = width
        self._rows: List[str] = []

    def _inner(self) -> int:
        return self.width - 4

    def _top(self) -> str:
        if not self.title:
            return "╭" + "═" * (self.width - 2) + "╮"
        label = f" ✧{self.title}✧ "
        lw = _dw(label)
        inner = self.width - 2
        if lw >= inner:
            return "╭" + _clip(label, inner - 2, "") + "╮"
        left = (inner - lw) // 2
        right = inner - lw - left
        return "╭" + "═" * left + label + "═" * right + "╮"

    def _bottom(self) -> str:
        return "╰" + "═" * (self.width - 2) + "╯"

    def _divider(self) -> str:
        return "├" + "─" * (self.width - 2) + "┤"

    def _heavy_line(self) -> str:
        inner = "═━──" + "━" * (self.width - 6)
        return "├" + inner[: self.width - 2]

    def _body(self, content: str) -> str:
        inner = self._inner()
        lines = _wrap(content, inner) if content else [""]
        return "\n".join("│ " + _pad(line, inner) + " │" for line in lines)

    def blank(self):
        self._rows.append("│ " + " " * self._inner() + " │")
        return self

    def text(self, content: str):
        inner = self._inner()
        for chunk in _wrap(str(content), inner):
            self._rows.append("│ " + _pad(chunk, inner) + " │")
        return self

    def center(self, content: str):
        inner = self._inner()
        for chunk in _wrap(str(content), inner):
            if _dw(chunk) >= inner:
                self._rows.append("│ " + _clip(chunk, inner) + " │")
            else:
                left = (inner - _dw(chunk)) // 2
                right = inner - _dw(chunk) - left
                self._rows.append("│ " + " " * left + chunk + " " * right + " │")
        return self

    def item(self, label: str, value: str = ""):
        line = f"├─➜ {label}" + (f" : {value}" if value else "")
        self._rows.append(self._body(line))
        return self

    def fancy(self, label: str, value: str = ""):
        line = f"├═━✧ {label}" + (f" :- {value}" if value else "")
        self._rows.append(self._body(line))
        return self

    def divider(self):
        self._rows.append(self._divider())
        return self

    def heavy(self):
        self._rows.append(self._heavy_line())
        return self

    def footer(self, dm: str = "@EXONIDEPRO"):
        line = f"  DM├─ {dm}"
        self._rows.append("│" + line + " " * (self.width - 2 - _dw(line)) + "│")
        return self

    def render(self) -> str:
        parts = [self._top()]
        parts.extend(self._rows)
        parts.append(self._bottom())
        return "\n".join(parts)

    def print(self):
        print(paint(self.render(), self.color), flush=True)


def _emit(box: Box, plain: str, level: str, uid: Optional[str] = None,
          bot_type: Optional[str] = None):
    box.print()
    try:
        tag = f"[{bot_type.upper()}] {plain}" if bot_type else plain
        bot_state.log(tag, level, uid)
    except Exception:
        pass


def print_success(text: str, uid: Optional[str] = None, bot_type: Optional[str] = None):
    _emit(Box("SUCCESS", C.EMERALD).blank().text(f"[+] {text}").footer(),
          text, "success", uid, bot_type)


def print_error(text: str, uid: Optional[str] = None, bot_type: Optional[str] = None):
    _emit(Box("ERROR", C.ROSE).blank().text(f"[-] {text}").footer(),
          text, "error", uid, bot_type)


def print_warning(text: str, uid: Optional[str] = None, bot_type: Optional[str] = None):
    _emit(Box("WARNING", C.AMBER).blank().text(f"[!] {text}").footer(),
          text, "warning", uid, bot_type)


def print_info(text: str, uid: Optional[str] = None, bot_type: Optional[str] = None):
    _emit(Box("INFO", C.CYAN_HI).blank().text(f"[i] {text}").footer(),
          text, "info", uid, bot_type)


def _gradient_text(text: str) -> str:
    if not _COLOR_ON:
        return text
    n = max(1, len(text) - 1)
    out: List[str] = []
    for i, ch in enumerate(text):
        t = i / n
        if t < 0.35:
            out.append(paint(ch, C.GOLD_HI))
        elif t < 0.7:
            out.append(paint(ch, C.GOLD))
        else:
            out.append(paint(ch, C.GOLD_LO))
    return "".join(out)


def print_banner():
    top = "╭" + "═" * (BOX_W - 2) + "╮"
    bot = "╰" + "═" * (BOX_W - 2) + "╯"
    brand = _gradient_text("✧ EXONIDE PRO ✧")
    sub = paint("Dual Bot Engine · Level Up + Guild Glory", C.MUTED)

    def cent(text: str) -> str:
        w = BOX_W - 2
        dw = _dw(text)
        if dw >= w:
            text = _clip(text, w)
            dw = _dw(text)
        l = (w - dw) // 2
        r = w - dw - l
        return "│" + " " * l + text + " " * r + "│"

    print(top, flush=True)
    print(cent(""), flush=True)
    print(cent(brand), flush=True)
    print(cent(sub), flush=True)
    print(cent(""), flush=True)
    print(bot, flush=True)

    b = Box("SYSTEM", C.VIOLET)
    b.blank()
    b.item("Dashboard", f"http://{WEB_HOST}:{WEB_PORT}")
    b.item("Root", os.path.basename(BASE_DIR) or BASE_DIR)
    b.item("Terminal", f"{_COLOR_MODE} mode")
    b.item("Level Bot", f"interval={LEVEL_START_MATCH_INTERVAL}s")
    b.item("Guild Bot", f"interval={GUILD_START_MATCH_INTERVAL}s size={TEAM_SIZE}")
    b.item("Cache TTL", f"level={TOKEN_CACHE_TTL_LEVEL}s guild={TOKEN_CACHE_TTL_GUILD}s")
    b.item("Startup Concurrency", str(STARTUP_LOGIN_CONCURRENCY))
    if AUTO_RESTART_ENABLED:
        b.item("Auto Restart", f"every {int(AUTO_RESTART_INTERVAL)}s")
    else:
        b.item("Auto Restart", "disabled")
    b.item("Smart Mode", "ON" if SMART_MODE_ENABLED else "OFF")
    b.item("Regions", f"{len(_regions.list_regions())} configured")
    b.item("Level Regions", ", ".join(PRIORITY_REGIONS_LEVEL[:4]) + " …")
    b.item("Guild Regions", ", ".join(GUILD_REGION_ROTATION_LIST[:4]) + " …")
    b.heavy()
    b.footer()
    b.print()


def print_account_box(index: int, account: dict, runtime: dict):
    uid = str(account.get("uid", account.get("token", "TOKEN"))[:32])
    auth = "UID + Password" if account.get("uid") else "Access Token"
    bot_type = str(account.get("bot_type", "level")).upper()
    b = Box(f"ACCOUNT #{index} · {bot_type}", C.BWHITE)
    b.blank()
    b.item("UID", _clip(uid, _INNER - 20))
    b.item("Auth", auth)
    b.item("Bot", bot_type)
    b.divider()
    b.fancy("Status", str(runtime.get("status", "INITIALIZING")))
    b.fancy("Level", str(runtime.get("level", "N/A")))
    b.fancy("Current", str(runtime.get("current_exp", "N/A")))
    b.fancy("Session", f"+{runtime.get('gained_session', 0)}")
    b.fancy("Matches", str(runtime.get("matches", {}).get("total", 0)))
    b.fancy("Active", str(runtime.get("matches", {}).get("active", 0)))
    b.fancy("Updated", str(runtime.get("last_updated", "N/A")))
    b.heavy()
    b.footer()
    b.print()


def print_match_box(match_seq: int, match_id: str, uid: str, server: str,
                    status: str, bot_type: str = "level"):
    b = Box(f"MATCH #{match_seq} · {bot_type.upper()}", C.BMAGENTA)
    b.blank()
    b.item("Match ID", match_id)
    b.item("UID", _clip(uid, _INNER - 20))
    b.item("Server", _clip(server, _INNER - 20))
    b.divider()
    b.fancy("Status", status)
    b.heavy()
    b.footer()
    b.print()


def print_profile_box(uid: str, nickname: str, level: int, exp: int,
                      gained: int, matches: int, likes: int = 0,
                      status: str = "ONLINE", bot_type: str = "level"):
    b = Box(f"PLAYER PROFILE · {bot_type.upper()}", C.EMERALD)
    b.blank()
    b.item("Nick", _clip(nickname or "-", _INNER - 20))
    b.item("UID", _clip(uid, _INNER - 20))
    b.divider()
    b.fancy("Level", str(level))
    b.fancy("EXP", str(exp))
    b.fancy("Gained", f"+{gained}")
    b.fancy("Likes", str(likes))
    b.fancy("Matches", str(matches))
    b.fancy("Status", status)
    b.heavy()
    b.footer()
    b.print()


CLOUDFLARE_PRIMARY_DNS = "1.1.1.1"
CLOUDFLARE_SECONDARY_DNS = "1.0.0.1"
_DNS_CACHE: Dict[str, Tuple[str, float]] = {}
_DNS_CACHE_TTL = 300.0


async def resolve_host_cloudflare(hostname: str) -> str:
    if not hostname:
        return hostname
    parts = hostname.split(".")
    if len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
        return hostname
    now = time.time()
    if hostname in _DNS_CACHE:
        ip, exp = _DNS_CACHE[hostname]
        if now < exp:
            return ip

    def _query(server_ip: str) -> Optional[str]:
        s = None
        try:
            tx_id = random.randint(1000, 65535)
            header = struct.pack(">HHHHHH", tx_id, 0x0100, 1, 0, 0, 0)
            qname = b"".join(bytes([len(part)]) + part.encode("ascii")
                             for part in hostname.split(".")) + b"\x00"
            query_pkt = header + qname + struct.pack(">HH", 1, 1)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1.2)
            s.sendto(query_pkt, (server_ip, 53))
            resp, _ = s.recvfrom(1024)
            if len(resp) >= 12:
                ancount = struct.unpack(">H", resp[6:8])[0]
                if ancount > 0:
                    offset = 12 + len(qname) + 4
                    for _ in range(ancount):
                        if offset >= len(resp):
                            break
                        if (resp[offset] & 0xC0) == 0xC0:
                            offset += 2
                        else:
                            while offset < len(resp) and resp[offset] != 0:
                                offset += 1 + resp[offset]
                            offset += 1
                        if offset + 10 > len(resp):
                            break
                        rtype, _rclass, _ttl, rdlen = struct.unpack(
                            ">HHIH", resp[offset:offset + 10])
                        offset += 10
                        if rtype == 1 and rdlen == 4 and offset + 4 <= len(resp):
                            return socket.inet_ntoa(resp[offset:offset + 4])
                        offset += rdlen
        except Exception:
            return None
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass
        return None

    loop = asyncio.get_running_loop()
    ip = await loop.run_in_executor(None, _query, CLOUDFLARE_PRIMARY_DNS)
    if not ip:
        ip = await loop.run_in_executor(None, _query, CLOUDFLARE_SECONDARY_DNS)
    if not ip:
        try:
            info = await loop.getaddrinfo(hostname, None, family=socket.AF_INET)
            if info:
                ip = info[0][4][0]
        except Exception:
            ip = hostname
    if ip:
        _DNS_CACHE[hostname] = (ip, now + _DNS_CACHE_TTL)
        if len(_DNS_CACHE) > 512:
            cutoff = now
            for k in [k for k, (_v, e) in _DNS_CACHE.items() if e < cutoff]:
                _DNS_CACHE.pop(k, None)
    return ip or hostname


def optimize_tcp_socket(sock: socket.socket):
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        if hasattr(socket, "TCP_KEEPIDLE"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 3)
        if hasattr(socket, "TCP_KEEPINTVL"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 3)
        if hasattr(socket, "TCP_KEEPCNT"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 3)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
    except Exception:
        pass


def optimize_udp_socket(sock: socket.socket):
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 131072)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 131072)
        if hasattr(socket, "SIO_UDP_CONNRESET") and os.name == "nt":
            try:
                sock.ioctl(socket.SIO_UDP_CONNRESET, False)
            except Exception:
                pass
    except Exception:
        pass


AES_KEY = b"Yg&tc%DEuh6%Zc^8"
AES_IV = b"6oyZDr22E3ychjM%"

CRC7_TABLE = bytes([
    0, 9, 18, 27, 36, 45, 54, 63, 72, 65, 90, 83, 108, 101, 126, 119,
    25, 16, 11, 2, 61, 52, 47, 38, 81, 88, 67, 74, 117, 124, 103, 110,
    50, 59, 32, 41, 22, 31, 4, 13, 122, 115, 104, 97, 94, 87, 76, 69,
    43, 34, 57, 48, 15, 6, 29, 20, 99, 106, 113, 120, 71, 78, 85, 92,
    100, 109, 118, 127, 64, 73, 82, 91, 44, 37, 62, 55, 8, 1, 26, 19,
    125, 116, 111, 102, 89, 80, 75, 66, 53, 60, 39, 46, 17, 24, 3, 10,
    86, 95, 68, 77, 114, 123, 96, 105, 30, 23, 12, 5, 58, 51, 40, 33,
    79, 70, 93, 84, 107, 98, 121, 112, 7, 14, 21, 28, 35, 42, 49, 56,
    65, 72, 83, 90, 101, 108, 119, 126, 9, 0, 27, 18, 45, 36, 63, 54,
    88, 81, 74, 67, 124, 117, 110, 103, 16, 25, 2, 11, 52, 61, 38, 47,
    115, 122, 97, 104, 87, 94, 69, 76, 59, 50, 41, 32, 31, 22, 13, 4,
    106, 99, 120, 113, 78, 71, 92, 85, 34, 43, 48, 57, 6, 15, 20, 29,
    37, 44, 55, 62, 1, 8, 19, 26, 109, 100, 127, 118, 73, 64, 91, 82,
    60, 53, 46, 39, 24, 17, 10, 3, 116, 125, 102, 111, 80, 89, 66, 75,
    23, 30, 5, 12, 51, 58, 33, 40, 95, 86, 77, 68, 123, 114, 105, 96,
    14, 7, 28, 21, 42, 35, 56, 49, 70, 79, 84, 93, 98, 107, 112, 121,
])

_DELTA = 0x9E3779B9
_ROUNDS = 16
_FIELD_SIZES = {0: 1, 1: 2, 2: 2, 3: 1, 4: 2}
_FIELD_NAMES = {0: "sendOption", 1: "cmd", 2: "orderId", 3: "flags", 4: "length"}


def _encode_varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            break
    return bytes(out)


def build_proto(fields: Dict[int, Any]) -> bytes:
    out = bytearray()
    for field_num in sorted(fields.keys()):
        value = fields[field_num]
        if isinstance(value, str):
            value = value.encode("utf-8")
        elif not isinstance(value, (bytes, bytearray)):
            value = str(value).encode("utf-8")
        else:
            value = bytes(value)
        tag = (field_num << 3) | 2
        out += _encode_varint(tag)
        out += _encode_varint(len(value))
        out += value
    return bytes(out)


def build_proto_loose(fields: Dict[Any, Any]) -> bytes:
    parts: List[bytes] = []
    for k, v in fields.items():
        if isinstance(k, str):
            try:
                k = int(k)
            except Exception:
                continue
        if isinstance(v, dict):
            nested = build_proto_loose(v)
            parts.append(_encode_varint((k << 3) | 2) + _encode_varint(len(nested)) + nested)
        elif isinstance(v, int):
            parts.append(_encode_varint((k << 3) | 0) + _encode_varint(v))
        elif isinstance(v, (str, bytes, bytearray)):
            ev = v.encode() if isinstance(v, str) else bytes(v)
            parts.append(_encode_varint((k << 3) | 2) + _encode_varint(len(ev)) + ev)
    return b"".join(parts)


def encrypt_api_bytes(plain_bytes: bytes) -> bytes:
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(plain_bytes, AES.block_size))


def encrypt_api_hex(plain_hex: str) -> str:
    return encrypt_api_bytes(bytes.fromhex(plain_hex)).hex()


async def aes_encrypt(payload: bytes, key: bytes, iv: bytes) -> bytes:
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(payload, AES.block_size))


def get_proto_field(d, key, default=None):
    if not isinstance(d, dict):
        return default
    field = d.get(key)
    if field is None:
        field = d.get(str(key))
    if not isinstance(field, dict):
        return default
    value = field.get("data")
    return default if value is None else value


def _json_bytes_hook(obj):
    if isinstance(obj, (bytes, bytearray)):
        return {"__bytes_hex__": bytes(obj).hex()}
    raise TypeError(f"Type {type(obj)} not serializable")


def _json_bytes_unhook(obj):
    if isinstance(obj, dict):
        if "__bytes_hex__" in obj and len(obj) == 1:
            try:
                return bytes.fromhex(obj["__bytes_hex__"])
            except Exception:
                return b""
        return {k: _json_bytes_unhook(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_bytes_unhook(x) for x in obj]
    return obj
class _SlidingWindow:

    def __init__(self, span: float, max_points: int = 4096):
        self._span = span
        self._max = max_points
        self._points: List[Tuple[float, int]] = []

    def add(self, ts: float, value: int) -> None:
        self._points.append((ts, value))
        cutoff = ts - self._span
        while self._points and self._points[0][0] < cutoff:
            self._points.pop(0)
        if len(self._points) > self._max:
            del self._points[: len(self._points) - self._max]

    def rate_per_hour(self, now: float) -> Optional[float]:
        if len(self._points) < 2:
            return None
        cutoff = now - self._span
        points = [p for p in self._points if p[0] >= cutoff]
        if len(points) < 2:
            return None
        first_ts, first_val = points[0]
        last_ts, last_val = points[-1]
        elapsed = last_ts - first_ts
        if elapsed < 1.0:
            return None
        gained = last_val - first_val
        if gained < 0:
            return None
        return round(gained / (elapsed / 3600.0), 2)


class LevelTokenCache:

    _memo: Dict[str, Any] = {}
    _memo_time: float = 0.0
    _memo_ttl = 5.0
    _errors_logged: set = set()

    @classmethod
    def load(cls) -> Dict[str, Any]:
        now = time.time()
        if cls._memo and (now - cls._memo_time) < cls._memo_ttl:
            return cls._memo
        if not os.path.exists(TOKEN_CACHE_FILE):
            return {}
        try:
            with open(TOKEN_CACHE_FILE, "r", encoding="utf-8") as f:
                content = f.read().strip()
            if not content:
                return {}
            data = json.loads(content)
            if not isinstance(data, dict):
                raise ValueError("Cache root must be dict")
            parsed = _json_bytes_unhook(data)
            cls._memo = parsed
            cls._memo_time = now
            return parsed
        except Exception as e:
            if "corrupt" not in cls._errors_logged:
                print_error(f"Token cache corrupt, archiving: {e}", bot_type="common")
                cls._errors_logged.add("corrupt")
            try:
                backup = TOKEN_CACHE_FILE + ".bak"
                if os.path.exists(TOKEN_CACHE_FILE) and not os.path.exists(backup):
                    os.replace(TOKEN_CACHE_FILE, backup)
                elif os.path.exists(TOKEN_CACHE_FILE):
                    os.remove(TOKEN_CACHE_FILE)
            except Exception:
                pass
            return {}

    @classmethod
    def save(cls, cache: Dict[str, Any]) -> None:
        try:
            tmp = TOKEN_CACHE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cache, f, indent=2, default=_json_bytes_hook)
            try:
                os.chmod(tmp, 0o600)
            except Exception:
                pass
            os.replace(tmp, TOKEN_CACHE_FILE)
            cls._memo = cache
            cls._memo_time = time.time()
            cls._errors_logged.discard("save")
        except Exception as e:
            if "save" not in cls._errors_logged:
                print_error(f"Token cache save error: {e}", bot_type="common")
                cls._errors_logged.add("save")

    @classmethod
    def get(cls, key: str, ttl: int) -> Optional[Dict]:
        cache = cls.load()
        entry = cache.get(str(key))
        if not entry:
            return None
        if time.time() - entry.get("cached_at", 0) > ttl:
            print_info(f"[CACHE] {key} expired, re-login needed",
                       str(key), bot_type="common")
            cls.invalidate(key)
            return None
        if str(entry.get("account_id", "")).isdigit():
            entry["account_id"] = int(entry["account_id"])
        if not isinstance(entry.get("login_payload_data"), (bytes, bytearray)):
            print_warning(f"[CACHE] {key} missing payload, invalidating",
                          str(key), bot_type="common")
            cls.invalidate(key)
            return None
        return entry

    @classmethod
    def put(cls, key: str, data: Dict[str, Any], label: str = "cache") -> None:
        cache = cls.load()
        entry = dict(data)
        entry.pop("auth_password", None)
        entry.pop("password", None)
        entry["cached_at"] = time.time()
        # Ensure region field is always present so guild_info can group tokens
        if not entry.get("region"):
            entry["region"] = "BD"
        cache[str(key)] = entry
        cls.save(cache)
        print_success(f"[CACHE] Saved {label} for {key}", str(key), bot_type="common")

    @classmethod
    def invalidate(cls, key: str) -> None:
        cache = cls.load()
        if str(key) in cache:
            del cache[str(key)]
            cls.save(cache)
            print_warning(f"[CACHE] Invalidated {key}", str(key), bot_type="common")

    @classmethod
    def store_access_token(cls, region: str, account_id: str,
                           access_token: str, nickname: str = "") -> None:
        """Persist a lightweight access-token record for guild_info consumption."""
        if not access_token:
            return
        cache = cls.load()
        key = f"tok_acc_{region.upper()}_{account_id}"
        cache[key] = {
            "account_id": str(account_id),
            "region": region.upper(),
            "access_token": access_token,
            "nickname": nickname,
            "cached_at": time.time(),
        }
        cls.save(cache)


def _level_device_list() -> List[Tuple[str, str, str, str]]:
    return [
        ("Samsung", "SM-G998B", "Adreno (TM) 660", "Android OS 12 / API-31"),
        ("Xiaomi", "2201122G", "Adreno (TM) 730", "Android OS 13 / API-33"),
        ("Realme", "RMX3700", "Mali-G710", "Android OS 14 / API-34"),
        ("OnePlus", "CPH2451", "Adreno (TM) 740", "Android OS 13 / API-33"),
        ("OPPO", "CPH2611", "Adreno (TM) 720", "Android OS 14 / API-34"),
        ("Vivo", "V2203", "Mali-G710", "Android OS 12 / API-31"),
        ("Poco", "M2102J20SG", "Adreno (TM) 660", "Android OS 13 / API-33"),
    ]


def _guild_device_list() -> List[Tuple[str, str, str, str]]:
    return [
        ("Samsung", "SM-G998B", "Adreno (TM) 660", "Android OS 12 / API-31"),
        ("Xiaomi", "2201122G", "Adreno (TM) 730", "Android OS 13 / API-33"),
        ("Realme", "RMX3700", "Mali-G710", "Android OS 14 / API-34"),
        ("OnePlus", "CPH2451", "Adreno (TM) 740", "Android OS 13 / API-33"),
        ("OPPO", "CPH2611", "Adreno (TM) 720", "Android OS 14 / API-34"),
    ]


def get_device_for_account(account_identifier: str, bot_type: str = "level") -> Dict[str, Any]:
    devices: Dict[str, Any] = {}
    if os.path.exists(DEVICES_FILE):
        try:
            with open(DEVICES_FILE, "r", encoding="utf-8") as f:
                devices = json.load(f)
        except Exception:
            devices = {}
    key = f"{bot_type}:{account_identifier}"
    if key in devices:
        return devices[key]
    pool = _guild_device_list() if bot_type == "guild" else _level_device_list()
    brand, model, gpu, os_ver = random.choice(pool)
    device = {
        "unique_device_id": f"Google|{uuid.uuid4()}",
        "brand": brand,
        "model": model,
        "gpu_renderer": gpu,
        "system_software": os_ver,
        "screen_width": random.choice([1080, 1440, 720, 1280]),
        "screen_height": random.choice([2400, 3200, 1600, 2400]),
        "screen_dpi": str(random.randint(300, 420)),
        "memory": random.randint(2800, 6500),
        "processor_details": (
            f"ARM64 FP ASIMD AES VMH | {random.randint(2200, 3200)} | "
            f"{random.randint(6, 12)}"
        ),
        "client_ip": (
            f"{random.randint(103, 223)}.{random.randint(10, 250)}."
            f"{random.randint(10, 250)}.{random.randint(10, 250)}"
        ),
        "bot_type": bot_type,
    }
    devices[key] = device
    try:
        with open(DEVICES_FILE, "w", encoding="utf-8") as f:
            json.dump(devices, f, indent=4)
    except Exception as e:
        print_error(f"Failed to save device mapping: {e}", bot_type="common")
    return device


http_client = httpx.AsyncClient(
    verify=False,
    timeout=httpx.Timeout(10.0),
    limits=httpx.Limits(max_connections=100, max_keepalive_connections=50),
)

REQ_HEADERS = {
    "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/x-www-form-urlencoded",
    "Expect": "100-continue",
    "X-Unity-Version": "2018.4.12f1",
    "X-GA-SV": "1789535859",
    "X-GA": "v1 1",
    "ReleaseVersion": "OB55",
}

_settings_cache_memo: Dict[str, Any] = {}
_settings_cache_time: float = 0.0
_SETTINGS_CACHE_TTL = 5.0
_settings_errors_logged: set = set()


def _load_settings_cache() -> Dict[str, Any]:
    global _settings_cache_memo, _settings_cache_time
    now = time.time()
    if _settings_cache_memo and (now - _settings_cache_time) < _SETTINGS_CACHE_TTL:
        return _settings_cache_memo
    if not os.path.exists(SETTINGS_CACHE_FILE):
        return {}
    try:
        with open(SETTINGS_CACHE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            _settings_cache_memo = data
            _settings_cache_time = now
            return data
    except Exception:
        pass
    return {}


def _save_settings_cache(data: Dict[str, Any]) -> None:
    global _settings_cache_memo, _settings_cache_time
    try:
        tmp = SETTINGS_CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, SETTINGS_CACHE_FILE)
        _settings_cache_memo = data
        _settings_cache_time = time.time()
    except Exception as e:
        if "settings" not in _settings_errors_logged:
            print_warning(f"Settings cache save failed: {e}", bot_type="common")
            _settings_errors_logged.add("settings")


def _read_cached_version() -> Optional[str]:
    data = _load_settings_cache()
    version = data.get("cached_client_version")
    return str(version) if version else None


def _write_cached_version(version: str) -> None:
    if not version:
        return
    data = _load_settings_cache()
    data["cached_client_version"] = str(version)
    data["cached_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    _save_settings_cache(data)


async def get_playstore_version() -> Optional[str]:
    loop = asyncio.get_running_loop()
    try:
        result = await asyncio.wait_for(
            loop.run_in_executor(
                None,
                lambda: play_scraper("com.dts.freefireth", lang="hi", country="id"),
            ),
            timeout=8.0,
        )
    except Exception:
        result = None
    if isinstance(result, dict):
        version = result.get("version")
        if version:
            _write_cached_version(str(version))
            return str(version)
    cached = _read_cached_version()
    if cached:
        print_warning(
            f"Play Store unreachable, using cached client version {cached}",
            bot_type="common",
        )
        return cached
    return None


_version_config_memo: Dict[str, Any] = {"ts": 0.0, "value": None, "region": None}
_VERSION_CONFIG_TTL = 900.0


async def version_config(region: str = "BD") -> Optional[Tuple[str, str, str]]:
    now = time.time()
    memo = _version_config_memo
    if (memo["value"] and memo["region"] == region
            and (now - memo["ts"]) < _VERSION_CONFIG_TTL):
        return memo["value"]

    app_version = await get_playstore_version()
    if not app_version:
        return memo["value"]

    api_url = (
        f"{_regions.VERSION_URL}"
        f"?version={app_version}"
        "&lang=hi&device=android&channel=android"
        "&appstore=googleplay"
        f"&region={region}"
        "&whitelist_version=1.3.0&whitelist_sp_version=1.0.0"
    )
    try:
        response = await http_client.get(api_url)
        response.raise_for_status()
        data = response.json()
        server_url = data.get("server_url")
        remote_version = data.get("remote_version")
        latest_release_version = data.get("latest_release_version")
        if not server_url or not remote_version or not latest_release_version:
            return memo["value"]
        value = (latest_release_version, remote_version, server_url)
        memo["ts"] = now
        memo["value"] = value
        memo["region"] = region
        return value
    except Exception:
        return memo["value"]


async def get_access_token(uid: str, password: str,
                           region: str = "BD") -> Optional[Tuple[str, str, Any]]:
    url = _regions.get_connect_url(region)
    hdrs = {
        "Host": "100067.connect.garena.com",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; SM-G998B Build/SP1A.210812.016)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close",
    }
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067",
    }
    for attempt in range(5):
        try:
            response = await http_client.post(url, headers=hdrs, data=data)
            if response.status_code == 200:
                rd = response.json()
                oid = rd.get("open_id")
                tok = rd.get("access_token")
                plat = rd.get("platform", 4)
                if oid and tok:
                    return oid, tok, plat
            if response.status_code == 429:
                await asyncio.sleep(1)
                continue
        except Exception:
            pass
        await asyncio.sleep(0.5)
    return None


async def inspect_access_token(access_token: str) -> Optional[Dict[str, Any]]:
    url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
    hdrs = {
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "100067.connect.garena.com",
        "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
    }
    try:
        response = await http_client.get(url, headers=hdrs)
        if response.status_code != 200:
            return None
        data = response.json()
        if not isinstance(data, dict) or "error" in data:
            return None
        return data
    except Exception:
        return None


def _parse_results_sync(parsed_results) -> Dict[str, Any]:
    result_dict: Dict[str, Any] = {}
    for result in parsed_results:
        field_data: Dict[str, Any] = {"wire_type": result.wire_type}
        if result.wire_type == "varint":
            field_data["data"] = result.data
        elif result.wire_type == "string":
            field_data["data"] = result.data
        elif result.wire_type == "bytes":
            field_data["data"] = result.data
        elif result.wire_type == "length_delimited":
            field_data["data"] = _parse_results_sync(result.data.results)
        result_dict[result.field] = field_data
    return result_dict


def _decode_protobuf_sync(data_hex: str) -> str:
    parsed = Parser().parse(data_hex)
    return json.dumps(_parse_results_sync(parsed))


async def decode_protobuf_async(data_hex: str) -> str:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _decode_protobuf_sync, data_hex)


def decode_protobuf_dict_safe(data: bytes) -> Dict[str, Any]:
    try:
        parsed = Parser().parse(
            data.hex() if isinstance(data, (bytes, bytearray)) else str(data))
        return _recursive_dict(parsed)
    except Exception:
        return {}


def _recursive_dict(results) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for r in results:
        fd: Dict[str, Any] = {"wire_type": r.wire_type}
        if r.wire_type in ("varint", "string", "bytes"):
            fd["data"] = r.data
        elif r.wire_type == "length_delimited":
            if hasattr(r.data, "results"):
                fd["data"] = _recursive_dict(r.data.results)
            elif isinstance(r.data, list):
                fd["data"] = _recursive_dict(r.data)
            else:
                fd["data"] = str(r.data)
        out[str(r.field)] = fd
    return out


def _decode_proto_manual(data: bytes) -> Dict[int, Any]:
    result: Dict[int, Any] = {}
    offset = 0
    data_len = len(data)
    while offset < data_len:
        header = 0
        shift = 0
        while offset < data_len:
            b = data[offset]
            offset += 1
            header |= (b & 0x7F) << shift
            if not (b & 0x80):
                break
            shift += 7
            if shift > 28:
                break
        if header == 0:
            break
        fn = header >> 3
        wt = header & 0x7
        if fn == 0:
            break
        if wt == 0:
            v = 0
            shift = 0
            while offset < data_len:
                b = data[offset]
                offset += 1
                v |= (b & 0x7F) << shift
                if not (b & 0x80):
                    break
                shift += 7
                if shift > 63:
                    break
            result[fn] = v
        elif wt == 2:
            length = 0
            shift = 0
            while offset < data_len:
                b = data[offset]
                offset += 1
                length |= (b & 0x7F) << shift
                if not (b & 0x80):
                    break
                shift += 7
                if shift > 28:
                    break
            if length > data_len - offset:
                break
            value = data[offset:offset + length]
            offset += length
            try:
                s = value.decode("utf-8")
                if s and all(31 < ord(c) < 127 or ord(c) in (9, 10, 13) for c in s):
                    result[fn] = s
                else:
                    nested = _decode_proto_manual(value)
                    result[fn] = nested if nested else value.hex()
            except UnicodeDecodeError:
                nested = _decode_proto_manual(value)
                result[fn] = nested if nested else value.hex()
        elif wt == 5:
            offset += 4
        elif wt == 1:
            offset += 8
        else:
            break
    return result


def wrap_manual_decode(inner: bytes) -> Optional[Dict[str, Any]]:
    try:
        alt = _decode_proto_manual(inner)
        if alt and len(alt) > 0:
            return {str(k): {"data": v} for k, v in alt.items()}
    except Exception:
        pass
    return None


async def send_majorlogin(data: bytes, release_version: str, server_url: str):
    try:
        if server_url.endswith("/"):
            url = f"{server_url}MajorLogin"
        else:
            url = f"{server_url}/MajorLogin"
        req_headers = REQ_HEADERS.copy()
        req_headers["ReleaseVersion"] = str(release_version)
        response = await http_client.post(url, headers=req_headers, data=data)
        if response.status_code != 200:
            return None
        content = response.content
        if len(content) < 40:
            return None
        for offset in [0, 64] + list(range(128)):
            try:
                res = thunderFF_pb2.MajorLoginRes()
                res.ParseFromString(content[offset:])
                if res.region and res.token:
                    return res
            except Exception:
                continue
        return None
    except Exception:
        return None


async def send_getlogin(data: bytes, base_url: str, token: str, release_version: str):
    try:
        url = f"{base_url.rstrip('/')}/GetLoginData"
        req_headers = REQ_HEADERS.copy()
        req_headers["ReleaseVersion"] = release_version
        req_headers["Authorization"] = f"Bearer {token}"
        req_headers["Host"] = "clientbp.ppmainecoonghj.com"
        response = await http_client.post(url, headers=req_headers, data=data)
        if response.status_code != 200:
            return None
        content = response.content
        res = thunderFF_pb2.GetLoginDataRes()
        ok = False
        try:
            res.ParseFromString(content)
            if res.functional_addrs or res.informational_addrs:
                ok = True
        except Exception:
            pass
        if not ok:
            for offset in range(min(128, len(content))):
                try:
                    cand = thunderFF_pb2.GetLoginDataRes()
                    cand.ParseFromString(content[offset:])
                    if cand.functional_addrs or cand.informational_addrs:
                        res = cand
                        break
                except Exception:
                    continue
        dict_res: Dict[str, Any] = {}
        try:
            loop = asyncio.get_running_loop()
            parsed = await loop.run_in_executor(None, Parser().parse, content.hex())
            dict_res = _parse_results_sync(parsed)
        except Exception:
            pass
        return res, dict_res
    except Exception:
        return None


async def build_majorlogin_payload(open_id: str, access_token: str, platform: Any,
                                   client_version: Optional[str],
                                   device_info: Dict[str, Any],
                                   bot_type: str = "level",
                                   region: str = "BD") -> Optional[bytes]:
    try:
        reg = str(region).upper() or "BD"
        if bot_type == "guild":
            payload = {
                3: str(datetime.now())[:-7],
                4: "free fire",
                5: "1",
                7: str(client_version) if client_version else "1.132.8",
                8: str(device_info.get("system_software", "Android OS 14 / API-34")),
                9: "Handheld",
                10: "Telkomsel",
                11: "CarrierDataNetwork",
                12: str(device_info.get("screen_width", 1639)),
                13: str(device_info.get("screen_height", 720)),
                14: str(device_info.get("screen_dpi", 320)),
                15: str(device_info.get("processor_details", "ARM64 FP ASIMD AES | 2000 | 8")),
                16: str(device_info.get("memory", 5653)),
                17: str(device_info.get("gpu_renderer", "Mali-G52 MC2")),
                18: "OpenGL ES 3.2 v1.r49p1-03bet0",
                19: str(device_info.get("unique_device_id", f"Google|{uuid.uuid4()}")),
                20: str(device_info.get("client_ip", "182.5.135.225")),
                21: "en",
                22: str(open_id),
                23: str(platform),
                24: "Handheld",
                25: str(device_info.get("model", "Xiaomi")),
                26: reg,
                29: str(access_token),
                30: "1",
                41: "Telkomsel",
                42: "4G",
                57: "7428b253defc164018c604a1ebbfebdf",
                60: "109278",
                61: "55402",
                62: "868",
                64: "55927",
                65: "109278",
                66: "55927",
                67: "109278",
                73: "2",
                74: "/data/app/~~6Cw028g_ld-8Z0z2qhrOLA==/com.dts.freefireth-i3wiaEmpx8CbiRVhUMx_ag==/lib/arm64",
                76: "1",
                77: "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/~~6Cw028g_ld-8Z0z2qhrOLA==/com.dts.freefireth-i3wiaEmpx8CbiRVhUMx_ag==/base.apk",
                78: "6",
                79: "1",
                81: "32",
                83: "2019121229",
                85: "3",
                86: "OpenGLES2",
                87: "3071",
                88: "4",
                89: "14466",
                93: "3rd_party",
                94: "KqsHTyb7yHjsAiyNWUUZa0DSOD6U0AhDQ76smAo1WeHHHpSmJ8KMRyRrxb2ttgJqO9YOqO/K6AORAvDMAX/qBS8+JahIkrM7kHfzlfULbgRAoZ9r",
                95: "111207",
                96: '{"cur_rate":[60,90,120],"support_etc2":true}',
                97: "1",
                98: "1",
                99: str(platform),
                100: str(platform),
                103: "1",
                104: "52837",
                105: "1",
                106: "https://dl.gmc.freefiremobile.com/live/ABHotUpdates/|211c933168f55902c7dfbfd8c4e2957d",
                107: "1.3fb8adbf45f44ce9",
            }
        else:
            payload = {
                3: str(datetime.now())[:-7],
                4: "free fire",
                5: "1",
                7: str(client_version) if client_version else "1.132.8",
                8: str(device_info.get("system_software", "Android OS 15 / API-35")),
                9: "Handheld",
                10: "Airtel",
                11: "CarrierDataNetwork",
                12: str(device_info.get("screen_width", 1639)),
                13: str(device_info.get("screen_height", 720)),
                14: str(device_info.get("screen_dpi", 320)),
                15: str(device_info.get("processor_details", "ARM64 FP ASIMD AES | 2000 | 8")),
                16: str(device_info.get("memory", 5653)),
                17: str(device_info.get("gpu_renderer", "Mali-G52 MC2")),
                18: "OpenGL ES 3.2 v1.r49p1-03bet0.19498e0ae1d5dac223383c39a2e58f04",
                19: str(device_info.get("unique_device_id", f"Google|{uuid.uuid4()}")),
                20: str(device_info.get("client_ip", "10.0.0.1")),
                21: "en",
                22: str(open_id),
                23: str(platform),
                24: "Handheld",
                25: str(device_info.get("model", "Xiaomi 2409BRN2CY")),
                26: reg,
                29: str(access_token),
                30: "1",
                41: "Airtel",
                42: "4G",
                57: "7428b253defc164018c604a1ebbfebdf",
                60: "109278",
                61: "55402",
                62: "868",
                64: "55927",
                65: "109278",
                66: "55927",
                67: "109278",
                73: "2",
                74: "/data/app/~~6Cw028g_ld-8Z0z2qhrOLA==/com.dts.freefireth-i3wiaEmpx8CbiRVhUMx_ag==/lib/arm64",
                76: "1",
                77: "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/~~6Cw028g_ld-8Z0z2qhrOLA==/com.dts.freefireth-i3wiaEmpx8CbiRVhUMx_ag==/base.apk",
                78: "3",
                79: "2",
                81: "64",
                83: "2019121229",
                85: "3",
                86: "OpenGLES2",
                87: "8191",
                88: str(platform),
                90: "Mumbai",
                91: "MH",
                92: "14466",
                93: "android",
                94: "KqsHTyb7yHjsAiyNWUUZa0DSOD6U0AhDQ76smAo1WeHHHpSmJ8KMRyRrxb2ttgJqO9YOqO/K6AORAvDMAX/qBS8+JahIkrM7kHfzlfULbgRAoZ9r",
                95: "111207",
                96: '{"cur_rate":[60,90,120],"support_etc2":false}',
                97: "1",
                98: "1",
                99: str(platform),
                100: str(platform),
                102: "D]C\x15\x05T\x0eU3",
                103: "1",
                104: "52837",
                105: "1",
                106: "https://dl.gmc.freefiremobile.com/live/ABHotUpdates/|https://core-gmc.freefiremobile.com/live/ABHotUpdates/|211c933168f55902c7dfbfd8c4e31f8d",
                107: "1.3fb8adbf45f44ce9",
            }
        raw = build_proto(payload)
        return encrypt_api_bytes(raw)
    except Exception as e:
        print_error(f"build_majorlogin_payload ({bot_type}): {e}", bot_type=bot_type)
        return None


def _build_account_data(majorlogin_response, res_proto, dict_res,
                        open_id, access_token, platform,
                        release_version, client_version,
                        login_payload_data, auth_type,
                        bot_type: str,
                        auth_uid=None, auth_password=None,
                        auth_token=None, login_uid=None):
    acc_id = str(majorlogin_response.account_id)
    level = int(get_proto_field(dict_res, 6, 1) or 1)
    exp = int(get_proto_field(dict_res, 7, 0) or 0)
    likes = int(get_proto_field(dict_res, 8, 0) or 0)
    nickname = res_proto.nickname or get_proto_field(dict_res, 4, f"Player_{acc_id}")
    region = majorlogin_response.region or get_proto_field(dict_res, 3, "BD")
    data: Dict[str, Any] = {
        "account_id": majorlogin_response.account_id,
        "login_uid": login_uid or auth_uid or acc_id,
        "nickname": nickname,
        "region": region,
        "level": level,
        "exp": exp,
        "likes": likes,
        "open_id": open_id,
        "access_token": access_token,
        "platform": str(platform),
        "token": majorlogin_response.token,
        "server_time": majorlogin_response.server_time,
        "aes_ak": majorlogin_response.aes_ak,
        "iv_i": majorlogin_response.iv_i,
        "functional_addrs": res_proto.functional_addrs or get_proto_field(dict_res, 14),
        "informational_addrs": res_proto.informational_addrs or get_proto_field(dict_res, 32),
        "release_version": release_version,
        "client_version": client_version,
        "server_url": majorlogin_response.url,
        "login_payload_data": login_payload_data,
        "auth_type": auth_type,
        "bot_type": bot_type,
    }
    if auth_uid:
        data["auth_uid"] = auth_uid
    if auth_password:
        data["auth_password"] = auth_password
    if auth_token:
        data["auth_token"] = auth_token
    return data


def register_credentials(account_data: Dict[str, Any]) -> None:
    try:
        acc_id = str(account_data["account_id"])
        login_uid = str(account_data.get("login_uid") or acc_id)
        bot_type = account_data.get("bot_type", "level")
        key_login = f"{bot_type}:{login_uid}"
        key_acc = f"{bot_type}:{acc_id}"
        bot_state.account_credentials[key_login] = account_data
        bot_state.account_credentials[key_acc] = account_data
        if account_data.get("auth_uid"):
            bot_state.account_credentials[
                f"{bot_type}:{account_data['auth_uid']}"] = account_data
        if account_data.get("auth_token"):
            bot_state.account_credentials[
                f"{bot_type}:tok_{account_data['auth_token'][:20]}"] = account_data
    except Exception:
        pass


async def refresh_account_profile(account_data_or_uid: Any,
                                  bot_type: str = "level") -> Optional[Dict[str, Any]]:
    try:
        if isinstance(account_data_or_uid, str):
            uid = str(account_data_or_uid)
            account_data = (bot_state.account_credentials.get(f"{bot_type}:{uid}")
                            or bot_state.account_credentials.get(uid))
        else:
            account_data = account_data_or_uid
            uid = str(account_data.get("login_uid")
                      or account_data.get("account_id")) if account_data else ""
            bot_type = account_data.get("bot_type", bot_type) if account_data else bot_type

        if not account_data:
            return None

        url = account_data.get("server_url")
        token = account_data.get("token")
        release_version = account_data.get("release_version")
        payload = account_data.get("login_payload_data")
        if not (url and token and release_version and payload):
            return None

        res = await send_getlogin(payload, url, token, release_version)
        if not res:
            return None

        res_proto, dict_res = res
        level = int(get_proto_field(dict_res, 6, 1) or 1)
        exp = int(get_proto_field(dict_res, 7, 0) or 0)
        likes = int(get_proto_field(dict_res, 8, 0) or 0)
        nickname = res_proto.nickname or get_proto_field(dict_res, 4, "")

        login_uid = str(account_data.get("login_uid")
                        or account_data.get("auth_uid") or uid)
        if exp > 0:
            bot_state.update_exp(f"{bot_type}:{login_uid}", exp, level)
        if likes > 0 and f"{bot_type}:{login_uid}" in bot_state.accounts:
            bot_state.accounts[f"{bot_type}:{login_uid}"]["likes"] = likes
        if nickname and f"{bot_type}:{login_uid}" in bot_state.accounts:
            bot_state.accounts[f"{bot_type}:{login_uid}"]["nickname"] = nickname

        account_data["level"] = level
        account_data["exp"] = exp
        if likes > 0:
            account_data["likes"] = likes
        if nickname:
            account_data["nickname"] = nickname

        print_info(
            f"[EXP-REFRESH] {login_uid} → Level {level}, EXP {exp}",
            login_uid, bot_type=bot_type,
        )
        return {"level": level, "exp": exp, "likes": likes, "nickname": nickname}
    except Exception as e:
        print_error(f"refresh_account_profile error: {e}", bot_type=bot_type)
        return None
def _level_match_counters() -> Dict[str, int]:
    return bot_state.level_match_counters


def _level_match_seq_counters() -> Dict[str, int]:
    return bot_state.level_match_seq_counters


async def level_inc_match(uid: str) -> int:
    async with bot_state.level_match_lock:
        counters = _level_match_counters()
        counters[uid] = counters.get(uid, 0) + 1
        return counters[uid]


async def level_dec_match(uid: str) -> int:
    async with bot_state.level_match_lock:
        counters = _level_match_counters()
        if uid in counters and counters[uid] > 0:
            counters[uid] -= 1
        return counters.get(uid, 0)


async def level_get_match_count(uid: str) -> int:
    async with bot_state.level_match_lock:
        return _level_match_counters().get(uid, 0)


async def level_get_total_match_count() -> int:
    async with bot_state.level_match_lock:
        return sum(_level_match_counters().values())


async def level_next_match_seq(uid: str) -> int:
    async with bot_state.level_match_lock:
        seqs = _level_match_seq_counters()
        seqs[uid] = seqs.get(uid, 0) + 1
        return seqs[uid]


def level_cleanup_match_counters(uid: str) -> None:
    _level_match_counters().pop(str(uid), None)
    _level_match_seq_counters().pop(str(uid), None)


def level_new_match_id() -> str:
    return uuid.uuid4().hex[:12]


async def level_build_tcp_startup_packet(account_id, token, server_time, key, iv,
                                         region="BD", typ="OnLine"):
    uid_hex = f"{int(account_id):016x}"
    timestamp_hex = f"{int(server_time):08x}"
    encoded_token = token.encode()
    encrypted_packet = (await aes_encrypt(encoded_token, key, iv)).hex()
    encrypted_packet_length = f"{len(encrypted_packet) // 2:08x}"
    reg = str(region).upper() if region else "BD"
    if typ == "OnLine":
        prefix = "7119" if reg == "BD" else ("7114" if reg == "IND" else "7115")
        return f"{prefix}{uid_hex}{timestamp_hex}00000000{encrypted_packet_length}{encrypted_packet}"
    prefix = "9219" if reg == "BD" else ("9214" if reg == "IND" else "9215")
    return f"{prefix}{uid_hex}{timestamp_hex}{encrypted_packet_length}{encrypted_packet}"


async def level_send_keep_alive(region="BD"):
    try:
        reg = str(region).upper() if region else "BD"
        if reg == "BD":
            return bytes.fromhex("0219")
        if reg == "IND":
            return bytes.fromhex("0214")
        return bytes.fromhex("0215")
    except Exception:
        return bytes.fromhex("0219")


async def level_start_game_lone_wolf(region, client_version, writer, key, iv):
    packet = bytes.fromhex(
        "080112800a0a010b102b3a110a044944433110aa011a064555524f50453a100a044944433210311a064555524f504540014a0801090a0b1219202758016291090a8001303838463832424630324139363736373032303130313030303030303030303030303136303030313030313530303032323246393745454530463030303030303436373632353134303030303030303030303030303030303030303030303030303030303030303030303030303066663030303030303030636163666131366410241afb02735d5e571400024a775d45414d1a041b1c001f11010449715f4243481a001e1d071c1703004b1a4066785c524570735c51486775421b5c5a4c07504042685a63610816054e19025e75196001477c015165406370195f5547404e4550640103020f1304064863754268676c755f65576e40467e5f0a417a4701026d675d6e73670b1108495a4c6a0b78470b740065645e525a057258425f584a447d4e6759440c11044e7c596d7f4b625f7d04055a47505c4e1d6b5b4107447d7201057d7f0f14084e430457674f7e517d72015172415d027473577c4d615f79535256780911030f4d5e027a797f614165067806505d53777750475e75064257076500460817014e741e7e5078487e7a7c465e7669767153497064605a7376677773550d160148037e18675966787f4c42607a645f577e7b441b460776026b18685d0b110205490060020f70676175654674706671797f41067346677c4e06585e780f15074c57047b40517075415f6364027259674b5b0166407f7340600407770a22047a5d5c52300b3a0a167305067162727516134208312e3133302e3232480350015ae90403626253513635686e556f4e36416456324b796f566c636f477776484f624e56526c4d727073504b4f43654177616848494176795556497273743752737149734a7a786b3247525268377a2f637664626d504f6a73552f79626d38547a4c69586d2f474351696d494b53486833447955726f39515152756c34545350626d6d624b7949565937545671577059455372323646572f59624578507338514f706d317372785455736c30796a434144444d4f34616a654b615753366361496c554b4963797a494e396d52516f715277687939797257476d337a644345337a6a61436f492f5a585233656f65365a42647a64677654636b6b665733356e4d4c6a6a565072564b6433523172756174394e50514150724a5546627859696c4c5a3859707336654d5447666b6649793574666a526c314d4648706b51774c6373374439656378566c41636f374e664f6d2b30654756466c4434744478706771385533595973587645384842502f70666c767a737138316a32524f4d7857437556445442492f684735625462773166456e4249725162762b636144775147696f74554e316d4c4b77734379456f4766706746614251457645672b736a764c4c78704743334c304a5344532f74526169504354553344374e6249306547516651622f5a466f4c36455630775a324d6f583932414c572f5049752f56634663584e70596b356f7966326151416a536971486a2f363276354843644f525551303578754e6171795251625653704654303137655237675255636b4966366c6f447476342b514e4a4670766d74757077707774396a5a5974437a4b56743657726d6e36785837706658456251555434684f3758a201050803108703a201050804108103a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815"
    )
    proto = thunderFF_pb2.StartMatch()
    proto.ParseFromString(packet)
    if hasattr(proto.main, "region_list") and len(proto.main.region_list) > 0:
        proto.main.region_list[0].region = region
        if len(proto.main.region_list) > 1:
            proto.main.region_list[1].region = region
    if hasattr(proto.main, "client_version"):
        proto.main.client_version.remote_version = client_version
    packet = proto.SerializeToString()
    encrypted_packet = (await aes_encrypt(packet, key, iv)).hex()
    packet_length = len(encrypted_packet) // 2
    hex_length = hex(packet_length)[2:]
    hex_length = hex_length if len(hex_length) > 1 else "0" + hex_length
    final_packet = "031400" + "0" * (6 - len(hex_length)) + hex_length + encrypted_packet
    writer.write(bytes.fromhex(final_packet))
    await writer.drain()


async def level_has_ssan_zig(n: int) -> bytes:
    z = (n << 1) & 0xFFFFFFFFFFFFFFFF
    out = bytearray()
    while z >= 0x80:
        out.append((z & 0x7F) | 0x80)
        z >>= 7
    out.append(z)
    return bytes(out)


async def level_uleb_encode(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            break
    return bytes(out)


async def tea_encrypt(v0, v1, k0, k1, k2, k3):
    s = 0
    for _ in range(_ROUNDS):
        s = (s + _DELTA) & 0xFFFFFFFF
        v0 = (v0 + (((((v1 << 4) & 0xFFFFFFFF) + k0) & 0xFFFFFFFF ^
                      ((v1 + s) & 0xFFFFFFFF) ^
                      (((v1 >> 5) + k1) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        v1 = (v1 + (((((v0 << 4) & 0xFFFFFFFF) + k2) & 0xFFFFFFFF ^
                      ((v0 + s) & 0xFFFFFFFF) ^
                      (((v0 >> 5) + k3) & 0xFFFFFFFF)))) & 0xFFFFFFFF
    return v0, v1


async def tea_decrypt(v0, v1, k0, k1, k2, k3):
    s = (_DELTA * _ROUNDS) & 0xFFFFFFFF
    for _ in range(_ROUNDS):
        v1 = (v1 - (((((v0 << 4) & 0xFFFFFFFF) + k2) & 0xFFFFFFFF ^
                      ((v0 + s) & 0xFFFFFFFF) ^
                      (((v0 >> 5) + k3) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        v0 = (v0 - (((((v1 << 4) & 0xFFFFFFFF) + k0) & 0xFFFFFFFF ^
                      ((v1 + s) & 0xFFFFFFFF) ^
                      (((v1 >> 5) + k1) & 0xFFFFFFFF)))) & 0xFFFFFFFF
        s = (s - _DELTA) & 0xFFFFFFFF
    return v0, v1


async def tea_cbc_encrypt(padded, key_bytes):
    k0, k1, k2, k3 = (struct.unpack_from("<I", key_bytes, o)[0] for o in (0, 4, 8, 12))
    out = bytearray(len(padded))
    prev_cipher = bytearray(8)
    prev_inter = bytearray(8)
    for i in range(0, len(padded), 8):
        xored = bytearray(8)
        for j in range(8):
            xored[j] = padded[i + j] ^ prev_cipher[j]
        e0, e1 = await tea_encrypt(
            struct.unpack_from("<I", xored, 0)[0],
            struct.unpack_from("<I", xored, 4)[0],
            k0, k1, k2, k3,
        )
        enc = bytearray(8)
        struct.pack_into("<I", enc, 0, e0)
        struct.pack_into("<I", enc, 4, e1)
        for j in range(8):
            out[i + j] = enc[j] ^ prev_inter[j]
        prev_cipher[:] = out[i:i + 8]
        prev_inter[:] = xored
    return bytes(out)


async def tea_cbc_decrypt(body, key_bytes):
    k0, k1, k2, k3 = (struct.unpack_from("<I", key_bytes, o)[0] for o in (0, 4, 8, 12))
    out = bytearray(len(body))
    prev_inter = bytearray(8)
    prev_cipher = bytearray(8)
    xored = bytearray(8)
    dec = bytearray(8)
    for i in range(0, len(body), 8):
        for j in range(8):
            xored[j] = body[i + j] ^ prev_inter[j]
        d0, d1 = await tea_decrypt(
            struct.unpack_from("<I", xored, 0)[0],
            struct.unpack_from("<I", xored, 4)[0],
            k0, k1, k2, k3,
        )
        struct.pack_into("<I", dec, 0, d0)
        struct.pack_into("<I", dec, 4, d1)
        for j in range(8):
            out[i + j] = dec[j] ^ prev_cipher[j]
        prev_cipher[:] = body[i:i + 8]
        prev_inter[:] = dec
    return bytes(out)


async def build_padded_content(content: bytes) -> bytes:
    pad_len = (8 - (len(content) + 10) % 8) % 8
    return bytes([pad_len, 0, 0]) + b"\x00" * pad_len + content + b"\x00" * 7


async def encode_header(layout, send_option, cmd, order_id, flags, length, k, v80):
    out = bytearray()
    for code in layout:
        value = {0: send_option, 1: cmd, 2: order_id, 3: flags, 4: length}[code]
        if _FIELD_SIZES[code] == 1:
            out.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            out.append(v & 0xFF)
            out.append((v >> 8) & 0xFF)
    return bytes(out)


async def crc7_buff(crc, buf):
    c = crc & 0x7F
    for b in buf:
        c = CRC7_TABLE[((2 * (c & 0xFF)) ^ (b & 0xFF)) & 0xFF] & 0x7F
    return c & 0x7F


async def sv_frame(msg_key, layout, send_option, cmd, order_id, flags, content, key,
                   encrypted=True):
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = await tea_cbc_encrypt(await build_padded_content(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0]) + await encode_header(
        layout, send_option, cmd, order_id, flags, len(body), k, v80)
    packet = bytearray(hdr + body)
    packet[1] = await crc7_buff(0, bytes(packet[2:])) & 0x7F
    return bytes(packet)


async def build_packet(msg_key, layout, send_option, cmd, order_id, flags,
                       content, key, encrypted=True):
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    body = await tea_cbc_encrypt(await build_padded_content(content), key) if encrypted else content
    hdr = bytearray([msg_key, 0])
    for code in layout:
        value = {0: send_option, 1: cmd, 2: order_id, 3: flags, 4: len(body)}[code]
        if _FIELD_SIZES[code] == 1:
            hdr.append((value & 0xFF) ^ k)
        else:
            v = ((value & 0xFFFF) ^ v80) & 0xFFFF
            hdr.append(v & 0xFF)
            hdr.append((v >> 8) & 0xFF)
    packet = bytearray(hdr + body)
    packet[1] = await crc7_buff(0, bytes(packet[2:])) & 0x7F
    return bytes(packet)


async def layouts_from_mask(mask):
    ru = [int(c) for c in str(mask).strip()]
    nr = [c for c in ru if c != 2]
    return ru, nr


async def build_hello_packet(text, key, layout):
    data = text.encode("utf-8")
    if len(data) > 25:
        raise ValueError(f"Text is too long ({len(data)} bytes)")
    content = b"\x10\x00\x00\x00" + data + b"\x00" * (29 - 4 - len(data))
    k = key[0] if key else 10
    v80 = ((k << 8) | k) & 0xFFFF
    layout = [int(c) for c in str(layout).strip()] if isinstance(layout, str) else list(layout)
    padded = await build_padded_content(content)
    enc_body = await tea_cbc_encrypt(padded, key)
    hdr = await encode_header(layout, 1, 1, 0, 1, len(enc_body), k, v80)
    packet = bytearray([0x63, 0x00]) + hdr + enc_body
    packet[1] = await crc7_buff(0, packet[2:]) & 0x7F
    return bytes(packet).hex()


async def classify_packet(frame):
    cmd = frame["cmd"]
    name = MESSAGE_ID_TO_NAME.get(cmd, f"UNKNOWN_{cmd}")
    if name == "UDP_HELLO":
        return "HELLO"
    if name == "UDP_ACK":
        return "ACK"
    if name == "UDP_PING":
        return "PING"
    if name == "RUDP_JOIN_MATCH":
        return "JOIN_MATCH"
    if name.startswith("RUDP_"):
        return name
    if name.startswith("UDP_"):
        return name
    return "DATA"


async def reply_for_packet(frame, key, mask, ack_key=0x68, ping_key=0x6D,
                           hello_key=0x5B, ack_style="short"):
    _ru, nr = await layouts_from_mask(mask)
    typ = await classify_packet(frame)
    if typ == "HELLO":
        if ack_style == "echo":
            content = frame["content"] if frame["content"] else b"\x10\x00\x00\x00"
            return typ, await build_packet(hello_key, nr, 1, 1, None, 1, content, key)
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, b"\x01\x00", key)
    if typ == "ACK":
        content = frame["content"] if frame["content"] else b"\x01\x00"
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, content, key)
    if typ == "PING":
        c = frame["content"]
        counter = c[:4] if len(c) >= 4 else c
        return typ, await build_packet(ping_key, nr, 0, 3, None, 0,
                                       counter + b"\x00\x00\x00", key, encrypted=False)
    if typ == "JOIN_MATCH":
        return typ, await build_packet(ack_key, nr, 0, 2, None, 1, b"\x02\x00", key)
    return typ, None


async def keepalive_ping_loop(sock, ip, port, key_bytes, mask, stop_event):
    _ru, nr = await layouts_from_mask(mask)
    ping_keys = [0x66, 0x6D, 0x69, 0x6C, 0x6B, 0x6E, 0x6F, 0x70]
    loop = asyncio.get_event_loop()
    i = 0
    while not stop_event.is_set():
        pk = ping_keys[i % len(ping_keys)]
        counter = int(time.time() * 1000) & 0xFFFFFFFF
        pkt = await build_packet(pk, nr, 0, 3, None, 0,
                                 struct.pack("<I", counter) + b"\x00\x00\x00",
                                 key_bytes, encrypted=False)
        try:
            await loop.sock_sendto(sock, pkt, (ip, port))
        except Exception:
            pass
        i += 1
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=3.0)
        except asyncio.TimeoutError:
            pass


async def try_header_parse(buf, layout, k, v80):
    off = 2
    out: Dict[str, Any] = {}
    for code in layout:
        size = _FIELD_SIZES[code]
        if off + size > len(buf):
            return None
        out[_FIELD_NAMES[code]] = (buf[off] ^ k) if size == 1 else (
            (buf[off] | (buf[off + 1] << 8)) ^ v80) & 0xFFFF
        off += size
    out["headerLen"] = off
    return out


async def oicq_unpad(padded):
    if not padded or len(padded) < 8:
        return None
    if not all(padded[-1 - i] == 0 for i in range(7)):
        return None
    pad_len = padded[0] & 0x07
    s = 3 + pad_len
    e = len(padded) - 7
    return padded[s:e] if s < e else b""


async def decode_packet(packet, key, mask=None):
    data = bytes(packet) if isinstance(packet, bytes) else bytes.fromhex(packet)
    if len(data) < 8:
        return None
    k = key[0]
    v80 = ((k << 8) | k) & 0xFFFF
    crc_ok = (data[1] & 0x7F) == await crc7_buff(0, data[2:])
    candidates: List[Dict[str, Any]] = []
    if mask:
        ru, nr = await layouts_from_mask(mask)
        layouts = [("RUDP", ru), ("nonRUDP", nr)]
    else:
        layouts = [("RUDP", list(p)) for p in itertools.permutations([0, 1, 2, 3, 4])]
        layouts += [("nonRUDP", list(p)) for p in itertools.permutations([0, 1, 3, 4])]
    for kind, layout in layouts:
        f = await try_header_parse(data, layout, k, v80)
        if not f:
            continue
        if f["flags"] > 7 or f["sendOption"] > 7:
            continue
        if f["length"] != len(data) - f["headerLen"]:
            continue
        body = data[f["headerLen"]:f["headerLen"] + f["length"]]
        content = None
        padded = None
        if f["flags"] & 1:
            if len(body) < 8 or len(body) % 8 != 0:
                continue
            padded = await tea_cbc_decrypt(body, key)
            content = await oicq_unpad(padded)
            if content is None:
                continue
        else:
            content = body
        score = (1 if crc_ok else 0) + (1 if content is not None else 0)
        candidates.append({
            "kind": kind, "layout": layout, "headerLen": f["headerLen"],
            "msgKey": data[0], "cmd": f["cmd"], "flags": f["flags"],
            "sendOption": f["sendOption"], "orderId": f.get("orderId"),
            "length": f["length"], "content": content, "crcOk": crc_ok,
            "padded": padded, "score": score, "total": len(data),
        })
    if not candidates:
        return None
    candidates.sort(key=lambda c: c["score"], reverse=True)
    return candidates[0]


async def level_build_match_startup_packets(token, udp_key, match_code, account_id,
                                            block_val, server_ip="", region="BD",
                                            client_version="1.132.6",
                                            client_version_code="2019121229",
                                            access_token=""):
    token = token.strip()
    udp_key_bytes = bytes.fromhex(udp_key)
    match_code_list = [int(ch) for ch in str(match_code).strip()]

    thunder_jwt = token[:660] if len(token) > 660 else token
    sharma_jwt = token[660:] if len(token) > 660 else ""
    enc_thunder = thunder_jwt.encode() if isinstance(thunder_jwt, str) else thunder_jwt
    enc_sharma = sharma_jwt.encode() if isinstance(sharma_jwt, str) else sharma_jwt

    garena420 = await level_has_ssan_zig(len(enc_thunder)) + enc_thunder

    reg = str(region).upper() if region else "BD"
    csoversea_block = bytes.fromhex(
        "ca0163736f7665727365612e7374726f6e67686f6c642e66726565666972656d6f62696c652e636f6d"
        "3b302e302e302e303b33342e3132362e37362e34353b33342e38372e3137372e31343b33342e38372e"
        "3137302e3233303b33352e3138352e3138332e35370000000000000100000000000000000000000001"
        "00000800000100000000000100a8a2d7bebd8d8bdf110200"
    )
    mid = bytes.fromhex("0000000001000102030101") + await level_has_ssan_zig(len(reg)) + reg.encode()
    mid += bytes.fromhex("0001030003000004")
    mid += await level_has_ssan_zig(len(client_version)) + client_version.encode()
    mid += await level_has_ssan_zig(len(client_version_code)) + client_version_code.encode()
    mid += csoversea_block
    clean_ip = server_ip.split(":")[0] if server_ip else "0.0.0.0"
    mid += await level_has_ssan_zig(len(clean_ip)) + clean_ip.encode()
    clean_acc = access_token.strip() if access_token else ""
    if clean_acc:
        mid += await level_has_ssan_zig(len(clean_acc)) + clean_acc.encode()
    mid += await level_has_ssan_zig(len(enc_sharma)) + enc_sharma

    tg_garena420 = (
        await level_uleb_encode(int(account_id)) +
        await level_uleb_encode(int(block_val)) +
        await level_uleb_encode(1) +
        await level_uleb_encode(43) +
        await level_uleb_encode(int(block_val)) +
        await level_uleb_encode(11) +
        mid
    )

    process = await sv_frame(0x5E, match_code_list, 2, 447, 0, 1, garena420, udp_key_bytes)
    loading = await sv_frame(0x5A, match_code_list, 2, 448, 1, 1, tg_garena420, udp_key_bytes)
    return process.hex(), loading.hex()


LEVEL_END_NATURAL = "natural"
LEVEL_END_ABORTED_NETWORK = "aborted_network"
LEVEL_END_ABORTED_SHUTDOWN = "aborted_shutdown"
LEVEL_END_TIMEOUT = "timeout"
LEVEL_END_ERROR = "error"


class NetworkStateGate:

    def __init__(self, uid: str, bot_type: str = "level"):
        self.uid = uid
        self.bot_type = bot_type
        self.down_since: Optional[float] = None
        self.retry_count = 0

    def mark_down(self, reason: str, next_delay: float) -> bool:
        first = self.down_since is None
        if first:
            self.down_since = time.time()
            self.retry_count = 1
            print_warning(f"Network DOWN ({reason}), retry in {next_delay:.1f}s",
                          self.uid, bot_type=self.bot_type)
            return True
        self.retry_count += 1
        return False

    def mark_up(self) -> bool:
        if self.down_since is None:
            return False
        elapsed = time.time() - self.down_since
        count = self.retry_count
        self.down_since = None
        self.retry_count = 0
        print_success(f"Network RECOVERED after {elapsed:.1f}s ({count} retries)",
                      self.uid, bot_type=self.bot_type)
        return True


async def level_play_game(server_ip_port, thunder, sharma, udp_key, match_code,
                          account_id, player_region, client_version, key, iv,
                          match_seq: int, match_id: str, uid_label: str,
                          exp_before: Optional[int],
                          level_before: Optional[int],
                          on_match_complete: Optional[Callable[[Dict[str, Any]], Any]] = None):
    match_start_time = time.time()
    ping_task = None
    sock = None
    ping_stop = asyncio.Event()
    completed_cleanly = False
    end_reason = LEVEL_END_ERROR

    try:
        ip, port = server_ip_port.split(":")
        port = int(port)
        resolved_ip = await resolve_host_cloudflare(ip)

        loop = asyncio.get_event_loop()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        optimize_udp_socket(sock)
        sock.setblocking(False)

        udp_key_bytes = bytes.fromhex(udp_key)
        hello_packet = await build_hello_packet(
            f"{account_id}_2585", udp_key_bytes, match_code)
        await loop.sock_sendto(sock, bytes.fromhex(hello_packet), (resolved_ip, port))

        ack_state = "waiting_for_hello_reply"
        thunder_sent = False
        join_match_received = False
        local_closed = False
        send_lock = asyncio.Lock()

        ping_task = asyncio.create_task(
            keepalive_ping_loop(sock, resolved_ip, port, udp_key_bytes, match_code, ping_stop)
        )
        last_activity = time.time()

        print_match_box(match_seq, match_id, uid_label, server_ip_port,
                        "UDP STARTED", bot_type="level")

        async def send_thunder_sharma():
            nonlocal ack_state, thunder_sent
            if thunder_sent:
                return
            async with send_lock:
                if thunder_sent:
                    return
                try:
                    await loop.sock_sendto(sock, bytes.fromhex(thunder), (resolved_ip, port))
                    thunder_sent = True
                    await asyncio.sleep(0.1)
                    _ru, nr = await layouts_from_mask(match_code)
                    prepare_ack = await build_packet(
                        0x68, nr, 0, 2, None, 1, b"\x01\x00", udp_key_bytes)
                    await loop.sock_sendto(sock, prepare_ack, (resolved_ip, port))
                    await asyncio.sleep(0.2)
                    await loop.sock_sendto(sock, bytes.fromhex(sharma), (resolved_ip, port))
                    ack_state = "thunder_sharma_sent"
                    print_success(f"[MATCH #{match_seq}] Thunder + Sharma sent",
                                  uid_label, bot_type="level")
                except Exception as e:
                    print_error(f"[MATCH #{match_seq}] startup send error: {e}",
                                uid_label, bot_type="level")

        while not local_closed:
            if time.time() - match_start_time > LEVEL_MAX_MATCH_DURATION:
                end_reason = LEVEL_END_TIMEOUT
                break
            try:
                response, server_addr = await asyncio.wait_for(
                    loop.sock_recvfrom(sock, 65535), timeout=1.5
                )
                if response:
                    last_activity = time.time()
                    frame = await decode_packet(response, udp_key_bytes, match_code)
                    if frame:
                        ptype = await classify_packet(frame)

                        if frame["cmd"] in (103, 107):
                            print_success(f"[MATCH #{match_seq}] Completed (cmd {frame['cmd']})",
                                          uid_label, bot_type="level")
                            completed_cleanly = True
                            end_reason = LEVEL_END_NATURAL
                            local_closed = True
                            continue

                        if frame["cmd"] == 101:
                            try:
                                _ru, nr = await layouts_from_mask(match_code)
                                ack_pkt = await build_packet(
                                    0x68, nr, 0, 2, None, 1, b"\x01\x00", udp_key_bytes)
                                await loop.sock_sendto(sock, ack_pkt, server_addr)
                            except Exception:
                                pass
                            continue

                        if ptype in ("ACK", "PING", "HELLO", "JOIN_MATCH"):
                            if ptype == "HELLO" and ack_state == "waiting_for_hello_reply":
                                _t, reply = await reply_for_packet(
                                    frame, udp_key_bytes, match_code, ack_style="short")
                                if reply:
                                    await loop.sock_sendto(sock, reply, server_addr)
                                ack_state = "ack_sent_waiting"
                            elif ptype == "ACK":
                                if ack_state == "waiting_for_hello_reply":
                                    _t, reply = await reply_for_packet(
                                        frame, udp_key_bytes, match_code)
                                    if reply:
                                        await loop.sock_sendto(sock, reply, server_addr)
                                    ack_state = "ready_to_send_thunder"
                                elif ack_state == "ack_sent_waiting":
                                    ack_state = "ready_to_send_thunder"
                                else:
                                    _t, reply = await reply_for_packet(
                                        frame, udp_key_bytes, match_code)
                                    if reply:
                                        await loop.sock_sendto(sock, reply, server_addr)
                            elif ptype == "PING":
                                _t, reply = await reply_for_packet(
                                    frame, udp_key_bytes, match_code)
                                if reply:
                                    await loop.sock_sendto(sock, reply, server_addr)
                            elif ptype == "JOIN_MATCH" and not join_match_received:
                                _t, reply = await reply_for_packet(
                                    frame, udp_key_bytes, match_code)
                                if reply:
                                    await loop.sock_sendto(sock, reply, server_addr)
                                    join_match_received = True
            except asyncio.TimeoutError:
                if ack_state == "ready_to_send_thunder" and not thunder_sent:
                    await send_thunder_sharma()
                elif ack_state == "waiting_for_hello_reply":
                    if (time.time() - last_activity) > LEVEL_MAX_IDLE_BEFORE_HELLO_RESEND:
                        try:
                            pkt = await build_hello_packet(
                                f"{account_id}_2585", udp_key_bytes, match_code)
                            await loop.sock_sendto(sock, bytes.fromhex(pkt),
                                                   (resolved_ip, port))
                        except Exception:
                            pass
                        last_activity = time.time()
                    if (time.time() - match_start_time) > LEVEL_HANDSHAKE_TIMEOUT:
                        print_warning(f"[MATCH #{match_seq}] Handshake timeout",
                                      uid_label, bot_type="level")
                        end_reason = LEVEL_END_TIMEOUT
                        break
                elif ack_state == "thunder_sharma_sent":
                    if (time.time() - last_activity) > LEVEL_MATCH_IDLE_TIMEOUT:
                        print_success(f"[MATCH #{match_seq}] Finished naturally",
                                      uid_label, bot_type="level")
                        completed_cleanly = True
                        end_reason = LEVEL_END_NATURAL
                        break
                continue
            except BlockingIOError:
                await asyncio.sleep(0.05)
            except OSError as e:
                errno = getattr(e, "errno", None)
                if errno in (101, 104, 110, 111, 113):
                    end_reason = LEVEL_END_ABORTED_NETWORK
                    print_warning(f"[MATCH #{match_seq}] Network aborted (errno {errno})",
                                  uid_label, bot_type="level")
                    break
                await asyncio.sleep(0.5)
                continue
            except asyncio.CancelledError:
                end_reason = LEVEL_END_ABORTED_SHUTDOWN
                raise
            except Exception as e:
                end_reason = LEVEL_END_ERROR
                print_error(f"[MATCH #{match_seq}] runtime error: {e}",
                            uid_label, bot_type="level")
                break

            if ack_state == "ready_to_send_thunder" and not thunder_sent:
                await send_thunder_sharma()

        result = {
            "match_id": match_id,
            "match_seq": match_seq,
            "uid": uid_label,
            "end_reason": end_reason,
            "completed_cleanly": completed_cleanly,
            "started_at": match_start_time,
            "ended_at": time.time(),
            "duration_s": round(time.time() - match_start_time, 2),
            "exp_before": exp_before,
            "level_before": level_before,
            "bot_type": "level",
        }
        return result
    except asyncio.CancelledError:
        end_reason = LEVEL_END_ABORTED_SHUTDOWN
        raise
    except Exception as e:
        print_error(f"[MATCH #{match_seq}] outer error: {e}", uid_label, bot_type="level")
        end_reason = LEVEL_END_ERROR
        return {
            "match_id": match_id, "match_seq": match_seq, "uid": uid_label,
            "end_reason": end_reason, "completed_cleanly": False,
            "started_at": match_start_time, "ended_at": time.time(),
            "duration_s": round(time.time() - match_start_time, 2),
            "exp_before": exp_before, "level_before": level_before,
            "bot_type": "level",
        }
    finally:
        ping_stop.set()
        if ping_task:
            ping_task.cancel()
            try:
                await ping_task
            except asyncio.CancelledError:
                pass
        if sock:
            try:
                sock.close()
            except Exception:
                pass
        remaining = await level_dec_match(uid_label)
        total = await level_get_total_match_count()
        print_info(f"[MATCH #{match_seq}] Closed ({end_reason}). "
                   f"UID active: {remaining} | Total: {total}",
                   uid_label, bot_type="level")
        try:
            desired = bot_state.get_desired_state(f"level:{uid_label}")
            if remaining > 0:
                bot_state.update_status(f"level:{uid_label}", "IN_MATCH", remaining)
            elif desired == "paused":
                bot_state.update_status(f"level:{uid_label}", "PAUSED", 0,
                                        reason="paused by user")
            else:
                bot_state.update_status(f"level:{uid_label}", "ONLINE", 0)
        except Exception:
            pass
        if on_match_complete is not None:
            try:
                await on_match_complete({
                    "match_id": match_id, "match_seq": match_seq, "uid": uid_label,
                    "end_reason": end_reason, "completed_cleanly": completed_cleanly,
                    "started_at": match_start_time, "ended_at": time.time(),
                    "duration_s": round(time.time() - match_start_time, 2),
                    "exp_before": exp_before, "level_before": level_before,
                    "bot_type": "level",
                })
            except Exception as e:
                print_error(f"[MATCH #{match_seq}] on_complete error: {e}",
                            uid_label, bot_type="level")


def level_log_task_exception(task: asyncio.Task):
    if task.cancelled():
        return
    exc = task.exception()
    if exc is not None:
        try:
            print_error(f"Background task exception: {exc}", bot_type="level")
        except Exception:
            pass


async def level_functional_lone_wolf(addrs, starter_packet, account_region,
                                     client_version, key, iv, account_id="",
                                     account_data=None, max_reconnects=10):
    reconnects = 0
    ip, port = addrs.split(":")
    play_matches: List[asyncio.Task] = []
    no_response_count = 0
    search_attempts = 0
    last_start_time = 0.0
    uid_str = str(account_id)
    consecutive_parse_failures = 0
    net_gate = NetworkStateGate(uid_str, bot_type="level")
    account_region_effective = (account_data or {}).get("region") or account_region or "BD"

    current_token = starter_packet
    current_key = key
    current_iv = iv
    current_account_data = account_data
    desired_key = f"level:{uid_str}"

    async def on_match_complete(result: Dict[str, Any]):
        try:
            if result.get("completed_cleanly"):
                try:
                    creds = bot_state.account_credentials.get(desired_key)
                    if creds:
                        await refresh_account_profile(creds, bot_type="level")
                except Exception:
                    pass
                fresh = bot_state.accounts.get(desired_key)
                if fresh:
                    result["exp_after"] = fresh.get("current_exp")
                    result["level_after"] = fresh.get("level")
            bot_state.record_match_result(desired_key, result)
        except Exception as e:
            print_error(f"[MATCH #{result.get('match_seq')}] record failed: {e}",
                        uid_str, bot_type="level")

    try:
        while True:
            desired = bot_state.get_desired_state(desired_key)
            if desired == "stopped":
                break

            writer = None
            try:
                if current_account_data:
                    fresh = None
                    if (current_account_data.get("auth_type") == "guest"
                            and current_account_data.get("auth_uid")):
                        fresh = LevelTokenCache.get(str(current_account_data["auth_uid"]),
                                                    TOKEN_CACHE_TTL_LEVEL)
                    elif (current_account_data.get("auth_type") == "token"
                          and current_account_data.get("auth_token")):
                        fresh = LevelTokenCache.get(
                            f"tok_{current_account_data['auth_token'][:20]}",
                            TOKEN_CACHE_TTL_LEVEL)

                    if fresh:
                        current_account_data = fresh
                        current_key = fresh["aes_ak"]
                        current_iv = fresh["iv_i"]
                        current_token = await level_build_tcp_startup_packet(
                            fresh["account_id"], fresh["token"], fresh["server_time"],
                            current_key, current_iv,
                            region=fresh.get("region", account_region_effective),
                            typ="OnLine")
                    else:
                        print_warning(f"[LEVEL] Cache miss for {uid_str}, re-login",
                                      uid_str, bot_type="level")
                        try:
                            if current_account_data.get("auth_uid"):
                                LevelTokenCache.invalidate(str(current_account_data["auth_uid"]))
                            if current_account_data.get("auth_token"):
                                LevelTokenCache.invalidate(
                                    f"tok_{current_account_data['auth_token'][:20]}")
                        except Exception:
                            pass
                        raise ConnectionError("Cache expired, triggering fresh login")

                resolved_ip = await resolve_host_cloudflare(ip)
                reader, writer = await asyncio.open_connection(resolved_ip, int(port))

                raw_sock = writer.get_extra_info("socket")
                if raw_sock:
                    optimize_tcp_socket(raw_sock)

                writer.write(bytes.fromhex(current_token))
                await writer.drain()

                try:
                    init_ka = await level_send_keep_alive(account_region_effective)
                    if init_ka and writer and not writer.is_closing():
                        writer.write(init_ka)
                        await asyncio.wait_for(writer.drain(), timeout=3)
                except Exception:
                    pass

                net_gate.mark_up()
                print_success(
                    f"[LEVEL] TCP Gateway connected for {uid_str} (DNS: {resolved_ip})",
                    uid_str, bot_type="level")
                reconnects = 0
                no_response_count = 0
                last_start_time = 0.0

                async def send_start_match():
                    nonlocal search_attempts, last_start_time
                    search_attempts += 1
                    print_info(
                        f"[LONE WOLF] StartMatch #{search_attempts} region {account_region_effective}",
                        uid_str, bot_type="level")
                    try:
                        await asyncio.sleep(random.uniform(0.3, 0.6))
                        await level_start_game_lone_wolf(
                            account_region_effective, client_version,
                            writer, current_key, current_iv)
                        print_success("[LONE WOLF] StartMatch packet sent",
                                      uid_str, bot_type="level")
                        active = await level_get_match_count(uid_str)
                        try:
                            bot_state.update_status(desired_key, "SEARCHING", active)
                        except Exception:
                            pass
                    except Exception as e:
                        print_error(f"level_start_game_lone_wolf error: {e}",
                                    uid_str, bot_type="level")
                    last_start_time = asyncio.get_running_loop().time()

                await send_start_match()

                while True:
                    desired = bot_state.get_desired_state(desired_key)
                    if desired == "stopped":
                        break

                    play_matches[:] = [m for m in play_matches if not m.done()]
                    active_count = await level_get_match_count(uid_str)
                    try:
                        if desired == "paused":
                            bot_state.update_status(desired_key, "PAUSED", active_count)
                        else:
                            bot_state.update_status(
                                desired_key,
                                "ONLINE" if active_count == 0 else "IN_MATCH",
                                active_count)
                    except Exception:
                        pass

                    now = asyncio.get_running_loop().time()
                    if now - last_start_time >= LEVEL_START_MATCH_INTERVAL:
                        await send_start_match()

                    try:
                        data = await asyncio.wait_for(reader.read(8192),
                                                      timeout=LEVEL_IDLE_READ_TIMEOUT)
                    except asyncio.TimeoutError:
                        no_response_count += 1
                        if no_response_count > LEVEL_IDLE_READ_LIMIT:
                            print_warning(
                                f"[LEVEL] Gateway silent ({uid_str}), reconnecting",
                                uid_str, bot_type="level")
                            raise ConnectionError("Gateway idle timeout")
                        continue

                    if not data:
                        raise ConnectionError("Connection closed by server")

                    hex_data = data.hex()
                    packet_length = len(data)
                    no_response_count = 0

                    if hex_data.startswith("0300") and 10 < packet_length < 30:
                        print_info("Match starting, please wait...",
                                   uid_str, bot_type="level")
                        continue

                    if hex_data.startswith("0300") and packet_length >= 300:
                        print_success("MATCH FOUND! Loading...", uid_str, bot_type="level")
                        try:
                            res = json.loads(await decode_protobuf_async(hex_data[10:]))
                            token = None
                            udp_key = None
                            match_code = None
                            server_ip_port = None
                            match_account_id = None
                            block_val = None

                            if "42" in res and "data" in res["42"]:
                                match_code = res["42"]["data"]
                            if "5" in res and "data" in res["5"]:
                                r5 = res["5"]["data"]
                                server_ip_port = r5.get("2", {}).get("data")
                                udp_key = r5.get("3", {}).get("data")
                                token = r5.get("4", {}).get("data")
                                if "42" in r5:
                                    match_code = r5["42"]["data"]
                            if "1" in res and "data" in res["1"]:
                                match_account_id = res["1"]["data"]
                            if "5" in res and "data" in res["5"]:
                                block_val = res["5"]["data"].get("1", {}).get("data")

                            effective_acc_id = match_account_id or account_id or "BD_BOT"

                            if token and udp_key and match_code and server_ip_port:
                                acc_tok = ""
                                if current_account_data:
                                    acc_tok = current_account_data.get("access_token", "") or ""
                                thunder, sharma = await level_build_match_startup_packets(
                                    token, udp_key, match_code, effective_acc_id, block_val or 0,
                                    server_ip=server_ip_port, region=account_region_effective,
                                    client_version=client_version, access_token=acc_tok)

                                match_seq = await level_next_match_seq(uid_str)
                                match_id = level_new_match_id()
                                active_after_inc = await level_inc_match(uid_str)

                                snapshot = bot_state.accounts.get(desired_key)
                                exp_before = snapshot.get("current_exp") if snapshot else None
                                level_before = snapshot.get("level") if snapshot else None

                                try:
                                    bot_state.record_match_start(desired_key, {
                                        "match_id": match_id,
                                        "match_seq": match_seq,
                                        "started_at": time.time(),
                                        "exp_before": exp_before,
                                        "level_before": level_before,
                                        "server": server_ip_port,
                                    })
                                except Exception:
                                    pass

                                try:
                                    new_match = asyncio.create_task(
                                        level_play_game(
                                            server_ip_port, thunder, sharma, udp_key, match_code,
                                            effective_acc_id, account_region_effective,
                                            client_version,
                                            current_key, current_iv,
                                            match_seq=match_seq,
                                            match_id=match_id,
                                            uid_label=uid_str,
                                            exp_before=exp_before,
                                            level_before=level_before,
                                            on_match_complete=on_match_complete))
                                    new_match.add_done_callback(level_log_task_exception)
                                    play_matches.append(new_match)
                                except Exception:
                                    await level_dec_match(uid_str)
                                    raise

                                total = await level_get_total_match_count()
                                print_info(
                                    f"[LEVEL] UDP task started. "
                                    f"match_id={match_id} seq={match_seq} | "
                                    f"UID active: {active_after_inc} | Total: {total}",
                                    uid_str, bot_type="level")
                                consecutive_parse_failures = 0

                                try:
                                    writer.close()
                                    await writer.wait_closed()
                                except Exception:
                                    pass

                                print_info(
                                    f"[OFFLINE] {LEVEL_NEW_MATCH_DELAY}s offline, "
                                    f"then reload token and new StartMatch",
                                    uid_str, bot_type="level")
                                await asyncio.sleep(LEVEL_NEW_MATCH_DELAY)
                                reconnects = 0
                                break

                            consecutive_parse_failures += 1
                            print_warning(
                                f"[LEVEL] Non-match big packet "
                                f"(#{consecutive_parse_failures}/"
                                f"{LEVEL_MAX_CONSECUTIVE_PARSE_FAILURES}) reconnecting",
                                uid_str, bot_type="level")
                            if consecutive_parse_failures >= LEVEL_MAX_CONSECUTIVE_PARSE_FAILURES:
                                print_error(
                                    f"[LEVEL] {LEVEL_MAX_CONSECUTIVE_PARSE_FAILURES}x "
                                    f"parse failures, invalidating cache",
                                    uid_str, bot_type="level")
                                if current_account_data:
                                    try:
                                        if current_account_data.get("auth_uid"):
                                            LevelTokenCache.invalidate(
                                                str(current_account_data["auth_uid"]))
                                        if current_account_data.get("auth_token"):
                                            LevelTokenCache.invalidate(
                                                f"tok_{current_account_data['auth_token'][:20]}")
                                    except Exception:
                                        pass
                                consecutive_parse_failures = 0
                            try:
                                writer.close()
                                await writer.wait_closed()
                            except Exception:
                                pass
                            await asyncio.sleep(LEVEL_NON_MATCH_RECONNECT_DELAY)
                            break

                        except Exception as e:
                            print_error(f"[LEVEL] Match packet error: {e}",
                                        uid_str, bot_type="level")
                            consecutive_parse_failures += 1
                            if consecutive_parse_failures >= LEVEL_MAX_CONSECUTIVE_PARSE_FAILURES:
                                if current_account_data:
                                    try:
                                        if current_account_data.get("auth_uid"):
                                            LevelTokenCache.invalidate(
                                                str(current_account_data["auth_uid"]))
                                        if current_account_data.get("auth_token"):
                                            LevelTokenCache.invalidate(
                                                f"tok_{current_account_data['auth_token'][:20]}")
                                    except Exception:
                                        pass
                                consecutive_parse_failures = 0
                            try:
                                writer.close()
                                await writer.wait_closed()
                            except Exception:
                                pass
                            await asyncio.sleep(LEVEL_NON_MATCH_RECONNECT_DELAY)
                            break

                    if 30 <= packet_length <= 40:
                        continue

            except asyncio.CancelledError:
                print_warning(
                    f"[LEVEL] Cancelled, marking {len(play_matches)} matches aborted_shutdown",
                    uid_str, bot_type="level")
                for m in play_matches:
                    if not m.done():
                        m.cancel()
                if play_matches:
                    await asyncio.gather(*play_matches, return_exceptions=True)
                play_matches.clear()
                raise
            except Exception as e:
                is_network = isinstance(e, (ConnectionError, OSError)) or "errno" in str(e).lower()
                if is_network:
                    delay = min(2 ** min(reconnects, 5), 30)
                    net_gate.mark_down(type(e).__name__, delay)
                else:
                    print_error(f"[LEVEL] TCP state ({uid_str}): {e}",
                                uid_str, bot_type="level")

                play_matches[:] = [m for m in play_matches if not m.done()]
                if writer:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
                if "Cache expired" in str(e):
                    print_warning(f"[LEVEL] Triggering re-login for {uid_str}",
                                  uid_str, bot_type="level")
                    break
                reconnects += 1
                if reconnects > max_reconnects:
                    print_error("[LEVEL] Max reconnects reached, resetting backoff",
                                uid_str, bot_type="level")
                    reconnects = 0
                    await asyncio.sleep(3)
                    continue
                await asyncio.sleep(min(reconnects, 2))

    except asyncio.CancelledError:
        print_warning(
            f"[LEVEL] Outer cancelled, marking {len(play_matches)} matches aborted_shutdown",
            uid_str, bot_type="level")
        for m in play_matches:
            if not m.done():
                m.cancel()
        if play_matches:
            await asyncio.gather(*play_matches, return_exceptions=True)
        play_matches.clear()
        raise


async def level_informational(addrs, starter_packet, key, iv,
                              region="BD", max_reconnects=3):
    reconnects = 0
    ip, port = addrs.split(":")
    while True:
        writer = None
        ping_task = None
        try:
            resolved_ip = await resolve_host_cloudflare(ip)
            reader, writer = await asyncio.open_connection(resolved_ip, int(port))
            raw_sock = writer.get_extra_info("socket")
            if raw_sock:
                optimize_tcp_socket(raw_sock)
            writer.write(bytes.fromhex(starter_packet))
            await writer.drain()
            reconnects = 0

            async def info_keepalive():
                ka_bytes = await level_send_keep_alive(region)
                first = True
                while True:
                    if first:
                        first = False
                    else:
                        await asyncio.sleep(5)
                    try:
                        if writer and not writer.is_closing():
                            writer.write(ka_bytes)
                            await writer.drain()
                    except Exception:
                        break

            ping_task = asyncio.create_task(info_keepalive())
            ping_task.add_done_callback(level_log_task_exception)

            while True:
                data = await reader.read(8192)
                if not data:
                    raise ConnectionError("Connection closed")
        except asyncio.CancelledError:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            raise
        except Exception:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            reconnects += 1
            if reconnects > max_reconnects:
                await asyncio.sleep(3)
                reconnects = 0
            else:
                await asyncio.sleep(1)


async def level_process_account_uid_pass(uid: str, password: str) -> Optional[Dict[str, Any]]:
    cached = LevelTokenCache.get(uid, TOKEN_CACHE_TTL_LEVEL)
    if cached:
        print_success(f"[LEVEL] CACHE HIT {uid} loaded without login",
                      uid, bot_type="level")
        acc_id = str(cached["account_id"])
        bot_state.register_account(
            uid=f"level:{uid}",
            account_id=acc_id,
            nickname=cached.get("nickname", f"Player_{acc_id}"),
            region=cached.get("region", "BD"),
            level=cached.get("level", 1),
            exp=cached.get("exp", 0),
            likes=cached.get("likes", 0),
        )
        cached["login_uid"] = uid
        cached["bot_type"] = "level"
        register_credentials(cached)
        # Persist access token for guild_info consumers
        if cached.get("access_token") and cached.get("region"):
            LevelTokenCache.store_access_token(
                cached["region"], acc_id, cached["access_token"],
                cached.get("nickname", ""))
        return cached

    print_info(f"[LEVEL] Full login for UID {uid}...", uid, bot_type="level")
    try:
        verconfig = await version_config(region="BD")
        if verconfig is None:
            bot_state.ensure_placeholder(f"level:{uid}", status="ERROR",
                                         status_reason="version config unavailable")
            return None
        release_version, client_version, server_url = verconfig

        token_grant = await get_access_token(uid, password, region="BD")
        if token_grant is None:
            bot_state.ensure_placeholder(f"level:{uid}", status="ERROR",
                                         status_reason="oauth grant failed")
            return None
        open_id, access_token, platform = token_grant

        device_info = get_device_for_account(uid, bot_type="level")

        login_payload = await build_majorlogin_payload(
            open_id, access_token, platform, client_version, device_info,
            bot_type="level", region="BD")
        if login_payload is None:
            bot_state.ensure_placeholder(f"level:{uid}", status="ERROR",
                                         status_reason="payload build failed")
            return None

        majorlogin = await send_majorlogin(login_payload, release_version, server_url)
        if majorlogin is None:
            bot_state.ensure_placeholder(f"level:{uid}", status="ERROR",
                                         status_reason="MajorLogin failed")
            return None

        getlogin = await send_getlogin(
            login_payload, majorlogin.url, majorlogin.token, release_version)
        if getlogin is None:
            bot_state.ensure_placeholder(f"level:{uid}", status="ERROR",
                                         status_reason="GetLoginData failed")
            return None
        res_proto, dict_res = getlogin

        account_data = _build_account_data(
            majorlogin, res_proto, dict_res,
            open_id, access_token, platform,
            release_version, client_version,
            login_payload, auth_type="guest", bot_type="level",
            auth_uid=uid, auth_password=password, login_uid=uid)

        bot_state.register_account(
            uid=f"level:{uid}",
            account_id=str(account_data["account_id"]),
            nickname=account_data["nickname"],
            region=account_data["region"],
            level=account_data["level"],
            exp=account_data["exp"],
            likes=account_data["likes"],
        )
        register_credentials(account_data)
        LevelTokenCache.put(uid, account_data, label="level guest")
        # Persist lightweight token for guild_info
        LevelTokenCache.store_access_token(
            account_data.get("region", "BD"),
            str(account_data["account_id"]),
            access_token,
            account_data.get("nickname", ""))

        print_profile_box(
            uid, account_data["nickname"], account_data["level"],
            account_data["exp"], 0, 0, account_data["likes"], "ONLINE",
            bot_type="level")
        return account_data
    except Exception as e:
        print_error(f"level_process_account_uid_pass error: {e}",
                    uid, bot_type="level")
        bot_state.ensure_placeholder(f"level:{uid}", status="ERROR",
                                     status_reason=str(e)[:120])
        return None


async def level_process_account_token(access_token: str) -> Optional[Dict[str, Any]]:
    cache_key = f"tok_{access_token[:20]}"
    cached = LevelTokenCache.get(cache_key, TOKEN_CACHE_TTL_LEVEL)
    if cached:
        print_success(f"[LEVEL] CACHE HIT token {access_token[:10]}... loaded",
                      bot_type="level")
        acc_id = str(cached["account_id"])
        bot_state.register_account(
            uid=f"level:{cache_key}",
            account_id=acc_id,
            nickname=cached.get("nickname", f"Player_{acc_id}"),
            region=cached.get("region", "BD"),
            level=cached.get("level", 1),
            exp=cached.get("exp", 0),
            likes=cached.get("likes", 0),
        )
        cached["login_uid"] = cache_key
        cached["bot_type"] = "level"
        register_credentials(cached)
        if cached.get("access_token") and cached.get("region"):
            LevelTokenCache.store_access_token(
                cached["region"], acc_id, cached["access_token"],
                cached.get("nickname", ""))
        return cached

    print_info("[LEVEL] Full login with access token...", bot_type="level")
    try:
        verconfig = await version_config(region="BD")
        if verconfig is None:
            bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                         status_reason="version config unavailable")
            return None
        release_version, client_version, server_url = verconfig

        inspect = await inspect_access_token(access_token)
        if inspect is None:
            bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                         status_reason="token inspect failed")
            return None
        open_id = inspect.get("open_id")
        platform = inspect.get("platform", 4)
        if not open_id:
            bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                         status_reason="open_id missing")
            return None

        device_info = get_device_for_account(open_id, bot_type="level")

        login_payload = await build_majorlogin_payload(
            open_id, access_token, str(platform), client_version, device_info,
            bot_type="level", region="BD")
        if not login_payload:
            bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                         status_reason="payload build failed")
            return None

        majorlogin = await send_majorlogin(login_payload, release_version, server_url)
        if majorlogin is None:
            bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                         status_reason="MajorLogin failed")
            return None

        getlogin = await send_getlogin(
            login_payload, majorlogin.url, majorlogin.token, release_version)
        if getlogin is None:
            bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                         status_reason="GetLoginData failed")
            return None

        res_proto, dict_res = getlogin
        account_data = _build_account_data(
            majorlogin, res_proto, dict_res,
            open_id, access_token, platform,
            release_version, client_version,
            login_payload, auth_type="token", bot_type="level",
            auth_token=access_token, login_uid=cache_key)

        bot_state.register_account(
            uid=f"level:{cache_key}",
            account_id=str(account_data["account_id"]),
            nickname=account_data["nickname"],
            region=account_data["region"],
            level=account_data["level"],
            exp=account_data["exp"],
            likes=account_data["likes"],
        )
        register_credentials(account_data)
        LevelTokenCache.put(cache_key, account_data, label="level token")
        LevelTokenCache.store_access_token(
            account_data.get("region", "BD"),
            str(account_data["account_id"]),
            access_token,
            account_data.get("nickname", ""))

        print_profile_box(
            cache_key, account_data["nickname"], account_data["level"],
            account_data["exp"], 0, 0, account_data["likes"], "ONLINE",
            bot_type="level")
        return account_data
    except Exception as e:
        print_error(f"level_process_account_token error: {e}", bot_type="level")
        bot_state.ensure_placeholder(f"level:{cache_key}", status="ERROR",
                                     status_reason=str(e)[:120])
        return None


async def level_run_account_worker(account_data: Dict[str, Any], label: str):
    acc_id = str(account_data["account_id"])
    login_uid = str(account_data.get("login_uid") or label)
    informational_task = None
    exp_task = None
    try:
        reg = account_data.get("region", "BD")
        tcp_packet_online = await level_build_tcp_startup_packet(
            account_data["account_id"], account_data["token"],
            account_data["server_time"], account_data["aes_ak"],
            account_data["iv_i"], region=reg, typ="OnLine")
        tcp_packet_chat = await level_build_tcp_startup_packet(
            account_data["account_id"], account_data["token"],
            account_data["server_time"], account_data["aes_ak"],
            account_data["iv_i"], region=reg, typ="ChaT")

        informational_task = asyncio.create_task(
            level_informational(account_data["informational_addrs"], tcp_packet_chat,
                                account_data["aes_ak"], account_data["iv_i"], region=reg))
        informational_task.add_done_callback(level_log_task_exception)

        async def exp_refresher():
            while True:
                await asyncio.sleep(LEVEL_EXP_REFRESH_INTERVAL)
                fresh = bot_state.account_credentials.get(f"level:{login_uid}")
                if not fresh:
                    fresh = bot_state.account_credentials.get(f"level:{acc_id}")
                if fresh:
                    await refresh_account_profile(fresh, bot_type="level")

        exp_task = asyncio.create_task(exp_refresher())
        exp_task.add_done_callback(level_log_task_exception)

        functional_task = asyncio.create_task(
            level_functional_lone_wolf(
                account_data["functional_addrs"], tcp_packet_online,
                account_data["region"], account_data["client_version"],
                account_data["aes_ak"], account_data["iv_i"],
                account_id=login_uid, account_data=account_data))
        functional_task.add_done_callback(level_log_task_exception)
        await functional_task
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print_error(f"level_run_account_worker error for {label}: {e}",
                    login_uid, bot_type="level")
    finally:
        for t in (informational_task, exp_task):
            if t and not t.done():
                t.cancel()
        for t in (informational_task, exp_task):
            if t:
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass
        try:
            desired = bot_state.get_desired_state(f"level:{login_uid}")
            if desired == "paused":
                bot_state.update_status(f"level:{login_uid}", "PAUSED", 0,
                                        reason="paused by user")
            elif desired == "stopped":
                bot_state.update_status(f"level:{login_uid}", "OFFLINE", 0,
                                        reason="stopped by user")
            else:
                bot_state.update_status(f"level:{login_uid}", "OFFLINE", 0)
        except Exception:
            pass


async def level_account_loop_guest(uid: str, password: str):
    while True:
        desired = bot_state.get_desired_state(f"level:{uid}")
        if desired == "stopped":
            print_info(f"[LEVEL] UID {uid} is stopped, exiting worker",
                       uid, bot_type="level")
            break

        try:
            print_info(f"[LEVEL] Starting guest login {uid}...", uid, bot_type="level")
            try:
                bot_state.update_status(f"level:{uid}", "CONNECTING")
            except Exception:
                pass
            account_data = await level_process_account_uid_pass(uid, password)
            if not account_data:
                print_error(f"[LEVEL] Login failed {uid}, retry in 15s",
                            uid, bot_type="level")
                try:
                    bot_state.update_status(f"level:{uid}", "ERROR",
                                            reason="login failed")
                except Exception:
                    pass
                await asyncio.sleep(15)
                continue
            await level_run_account_worker(account_data, uid)
            print_warning(f"[LEVEL] Session finished {uid}, reconnect in 3s",
                          uid, bot_type="level")
            await asyncio.sleep(3)
        except asyncio.CancelledError:
            desired = bot_state.get_desired_state(f"level:{uid}")
            if desired == "paused":
                print_warning(f"[LEVEL] Worker {uid} paused", uid, bot_type="level")
                try:
                    bot_state.update_status(f"level:{uid}", "PAUSED", 0,
                                            reason="paused by user")
                except Exception:
                    pass
            else:
                print_warning(f"[LEVEL] Worker {uid} stopped", uid, bot_type="level")
                try:
                    bot_state.update_status(f"level:{uid}", "OFFLINE", 0)
                except Exception:
                    pass
            break
        except Exception as e:
            print_error(f"[LEVEL] Error {uid}: {e}. Retry in 10s",
                        uid, bot_type="level")
            await asyncio.sleep(10)


async def level_account_loop_token(token: str):
    token_label = token[:10]
    cache_key = f"tok_{token[:20]}"
    while True:
        desired = bot_state.get_desired_state(f"level:{cache_key}")
        if desired == "stopped":
            print_info(f"[LEVEL] Token {token_label}... is stopped, exiting worker",
                       bot_type="level")
            break

        try:
            print_info("[LEVEL] Starting token login...", bot_type="level")
            account_data = await level_process_account_token(token)
            if not account_data:
                print_error("[LEVEL] Login failed for token, retry in 15s",
                            bot_type="level")
                await asyncio.sleep(15)
                continue
            await level_run_account_worker(account_data, account_data["login_uid"])
            print_warning("[LEVEL] Token session finished, reconnect in 3s",
                          bot_type="level")
            await asyncio.sleep(3)
        except asyncio.CancelledError:
            desired = bot_state.get_desired_state(f"level:{cache_key}")
            if desired == "paused":
                print_warning(f"[LEVEL] Worker for token {token_label} paused",
                              bot_type="level")
                try:
                    bot_state.update_status(f"level:{cache_key}", "PAUSED", 0,
                                            reason="paused by user")
                except Exception:
                    pass
            else:
                print_warning(f"[LEVEL] Worker for token {token_label} stopped",
                              bot_type="level")
                try:
                    bot_state.update_status(f"level:{cache_key}", "OFFLINE", 0)
                except Exception:
                    pass
            break
        except Exception as e:
            print_error(f"[LEVEL] Token error: {e}. Retry in 10s", bot_type="level")
            await asyncio.sleep(10)
def _ensure_bot_state_compat():
    bs = bot_state
    if not hasattr(bs, "level_match_counters"):
        bs.level_match_counters = {}
    if not hasattr(bs, "level_match_seq_counters"):
        bs.level_match_seq_counters = {}
    if not hasattr(bs, "level_match_lock"):
        bs.level_match_lock = asyncio.Lock()
    if not hasattr(bs, "guild_match_counters"):
        bs.guild_match_counters = {}
    if not hasattr(bs, "guild_match_lock"):
        bs.guild_match_lock = asyncio.Lock()
    if not hasattr(bs, "account_workers"):
        bs.account_workers = {}
    if not hasattr(bs, "account_credentials"):
        bs.account_credentials = {}
    if not hasattr(bs, "desired_state"):
        bs.desired_state = {}
    if not hasattr(bs, "refresh_callbacks"):
        bs.refresh_callbacks = {}
    if not hasattr(bs, "set_desired_state"):
        def _set_desired(uid, state):
            bs.desired_state[str(uid)] = str(state)
        bs.set_desired_state = _set_desired
    if not hasattr(bs, "get_desired_state"):
        def _get_desired(uid):
            return bs.desired_state.get(str(uid), "running")
        bs.get_desired_state = _get_desired
    if not hasattr(bs, "ensure_placeholder"):
        def _ensure_placeholder(uid, account_id="", nickname="", region="",
                                status="INITIALIZING", status_reason=None):
            key = str(uid)
            existing = bs.accounts.get(key)
            if existing is not None:
                if account_id:
                    existing["account_id"] = str(account_id)
                if nickname:
                    existing["nickname"] = nickname
                if region:
                    existing["region"] = region
                if str(existing.get("status", "")).upper() not in (
                        "ONLINE", "SEARCHING", "IN_MATCH"):
                    existing["status"] = status
                    existing["status_reason"] = status_reason
                return existing
            now_str = time.strftime("%Y-%m-%dT%H:%M:%S")
            acc = {
                "login_uid": key,
                "account_id": str(account_id or key),
                "nickname": nickname or f"Player_{key[:6]}",
                "region": region or "BD",
                "level": 1,
                "current_exp": 0,
                "initial_exp": 0,
                "gained_session": 0,
                "gained_today": 0,
                "gained_lifetime": 0,
                "likes": 0,
                "status": status,
                "status_reason": status_reason,
                "matches": {"total": 0, "natural": 0, "aborted": 0, "active": 0},
                "last_match": None,
                "recent_matches": [],
                "exp_history": [],
                "started_at": now_str,
                "last_active_at": now_str,
                "last_updated": now_str,
                "exp_per_hour_short": None,
                "exp_per_hour_long": None,
            }
            bs.accounts[key] = acc
            return acc
        bs.ensure_placeholder = _ensure_placeholder
    if not hasattr(bs, "record_match_start"):
        def _record_match_start(uid, meta):
            key = str(uid)
            acc = bs.accounts.get(key)
            if acc:
                acc.setdefault("matches", {}).setdefault("active", 0)
                acc["matches"]["active"] = int(acc["matches"]["active"]) + 1
        bs.record_match_start = _record_match_start
    if not hasattr(bs, "record_match_result"):
        def _record_match_result(uid, result):
            key = str(uid)
            acc = bs.accounts.get(key)
            if not acc:
                return
            m = acc.setdefault("matches",
                               {"total": 0, "natural": 0, "aborted": 0, "active": 0})
            m["active"] = max(0, int(m.get("active", 0)) - 1)
            m["total"] = int(m.get("total", 0)) + 1
            if result.get("end_reason") == "natural":
                m["natural"] = int(m.get("natural", 0)) + 1
            else:
                m["aborted"] = int(m.get("aborted", 0)) + 1
            acc["last_match"] = result
            acc["last_updated"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        bs.record_match_result = _record_match_result
    if not hasattr(bs, "flush_all"):
        bs.flush_all = lambda: None


_ensure_bot_state_compat()


TokenCache = LevelTokenCache


def _guild_match_counters() -> Dict[str, int]:
    return bot_state.guild_match_counters


async def guild_inc_match(uid: str) -> int:
    async with bot_state.guild_match_lock:
        counters = _guild_match_counters()
        counters[uid] = counters.get(uid, 0) + 1
        return counters[uid]


async def guild_dec_match(uid: str) -> int:
    async with bot_state.guild_match_lock:
        counters = _guild_match_counters()
        if uid in counters and counters[uid] > 0:
            counters[uid] -= 1
        return counters.get(uid, 0)


async def guild_get_match_count(uid: str) -> int:
    async with bot_state.guild_match_lock:
        return _guild_match_counters().get(uid, 0)


async def guild_get_total_match_count() -> int:
    async with bot_state.guild_match_lock:
        return sum(_guild_match_counters().values())


_guild_team_state: Dict[str, Any] = {
    "peers": {},
    "leader_uid": None,
    "team_code": None,
    "pk_code": None,
    "members": set(),
    "members_lock": asyncio.Lock(),
    "lock": asyncio.Lock(),
}


async def guild_team_member_join(uid: str) -> int:
    uid = str(uid)
    async with _guild_team_state["members_lock"]:
        before = len(_guild_team_state["members"])
        _guild_team_state["members"].add(uid)
        after = len(_guild_team_state["members"])
    if after != before:
        print_success(f"[GUILD] Member joined ({after}/{TEAM_SIZE}) {uid}",
                      uid, bot_type="guild")
    return after


async def guild_team_member_leave(uid: str) -> None:
    async with _guild_team_state["members_lock"]:
        _guild_team_state["members"].discard(str(uid))


async def guild_team_member_count() -> int:
    async with _guild_team_state["members_lock"]:
        return len(_guild_team_state["members"])


async def guild_team_member_reset(keep_leader: bool = True) -> None:
    async with _guild_team_state["members_lock"]:
        _guild_team_state["members"].clear()
        if keep_leader and _guild_team_state["leader_uid"]:
            _guild_team_state["members"].add(_guild_team_state["leader_uid"])


def guild_bypass_jitter(base: float, spread: float = 0.35) -> float:
    if not (SAFE_PLAY_MODE and BYPASS_TIMING_JITTER):
        return base
    return max(0.05, base + random.uniform(-spread, spread))


def guild_bypass_packet_jitter(base: float, spread_ratio: float = 0.35) -> float:
    if not (SAFE_PLAY_MODE and BYPASS_PACKET_JITTER):
        return base
    return max(0.1, base + random.uniform(-base * spread_ratio, base * spread_ratio))


def guild_bypass_hello_delay() -> float:
    if not (SAFE_PLAY_MODE and BYPASS_HELLO_DELAY):
        return 0.0
    return random.uniform(0.05, 0.45)


def guild_bypass_ka_jitter(base: float = 5.0) -> float:
    if not (SAFE_PLAY_MODE and BYPASS_KA_JITTER):
        return base
    return max(3.0, base + random.uniform(-0.8, 1.2))


def guild_bypass_human_reconnect_delay(attempt: int) -> float:
    if not (SAFE_PLAY_MODE and BYPASS_TIMING_JITTER):
        return min(attempt * 0.5, 2.0)
    return max(0.05, min(attempt * 0.5, 2.0) + random.uniform(-0.4, 0.7))


def guild_pb_varint(field_num: int, value: int) -> bytes:
    return _encode_varint((field_num << 3) | 0) + _encode_varint(value)


def guild_pb_length(field_num: int, value) -> bytes:
    encoded = value.encode("utf-8") if isinstance(value, str) else bytes(value)
    return _encode_varint((field_num << 3) | 2) + _encode_varint(len(encoded)) + encoded


def guild_create_proto(fields: Dict[Any, Any]) -> bytes:
    packet = bytearray()
    for field, value in fields.items():
        if isinstance(field, str):
            try:
                field = int(field)
            except Exception:
                continue
        if isinstance(value, dict):
            packet.extend(guild_pb_length(field, guild_create_proto(value)))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    packet.extend(guild_pb_length(field, guild_create_proto(item)))
                elif isinstance(item, str):
                    packet.extend(guild_pb_length(field, item))
                elif isinstance(item, (bytes, bytearray)):
                    packet.extend(guild_pb_length(field, bytes(item)))
                elif isinstance(item, bool):
                    packet.extend(guild_pb_varint(field, 1 if item else 0))
                elif isinstance(item, int):
                    packet.extend(guild_pb_varint(field, item))
        elif isinstance(value, bool):
            packet.extend(guild_pb_varint(field, 1 if value else 0))
        elif isinstance(value, int):
            packet.extend(guild_pb_varint(field, value))
        elif isinstance(value, str):
            packet.extend(guild_pb_length(field, value))
        elif isinstance(value, (bytes, bytearray)):
            packet.extend(guild_pb_length(field, bytes(value)))
    return bytes(packet)


def guild_create_packet(plain_hex: str, prefix: str, key: bytes, iv: bytes) -> bytes:
    if isinstance(key, str):
        key = bytes.fromhex(key) if len(key) == 32 else key.encode()
    if isinstance(iv, str):
        iv = bytes.fromhex(iv) if len(iv) == 32 else iv.encode()
    encrypted_hex = AES.new(key, AES.MODE_CBC, iv).encrypt(
        pad(bytes.fromhex(plain_hex), 16)).hex()
    length = len(encrypted_hex) // 2
    hexlen = hex(length)[2:]
    if len(hexlen) % 2 != 0:
        hexlen = "0" + hexlen
    padding = 12 - len(prefix) - len(hexlen)
    if padding < 0:
        padding = 0
    return bytes.fromhex(prefix + ("0" * padding) + hexlen + encrypted_hex)


def guild_create_team(key: bytes, iv: bytes, game_version: str = "1.132.9") -> bytes:
    fields = {
        1: 1,
        2: {
            2: bytes.fromhex("01"),
            3: 1,
            4: 3,
            5: "en",
            8: {1: "IDC3", 2: 123, 3: "ID"},
            9: 1,
            10: bytes.fromhex("01090a0b1219202729"),
            11: 2,
            13: 1,
            14: {
                1: ("08FBA33B4BABE2790205390333330000009700050092005F72697EB2134DCBB2467625"
                    "142201040e38e848dc0e748c3f6aa04d81000000ff1113090dcacfa16d"),
                2: 478,
                3: "7e585d55",
                4: "y[Z]",
                6: 12,
                7: "15686677735a7506101c",
                8: str(game_version),
                9: 3,
                10: 1,
                11: "03626253513637754174",
            },
            19: 329,
            21: bytes.fromhex("374f521955"),
            24: {1: 21},
            27: "a_6534489873065906362",
        },
    }
    return guild_create_packet(guild_create_proto(fields).hex(), "0515", key, iv)


def guild_team_fresh(account_id: int, key: bytes, iv: bytes) -> bytes:
    return guild_create_packet(
        guild_create_proto({1: 72, 2: {1: int(account_id)}}).hex(), "0515", key, iv)


def guild_invite_player_in_team(target_uid: int, key: bytes, iv: bytes,
                                region: str = "ID") -> bytes:
    fields = {1: 2, 2: {1: int(target_uid), 2: region, 4: 1}}
    return guild_create_packet(guild_create_proto(fields).hex(), "0515", key, iv)


def guild_accept_team_invite(target_uid: int, group_id: str,
                             key: bytes, iv: bytes) -> bytes:
    fields = {
        1: 4,
        2: {
            1: int(target_uid),
            3: int(target_uid),
            4: bytes.fromhex("0107090a0b120f19202729"),
            8: 1,
            9: {
                1: ("08FBA33B0522052002041B0222220007000C00010004000547E265AE1080779546762514"
                    "110104076fa2e8770e748c3f6a68ed75000000ff08080500cacfa16d"),
                2: 235,
                3: {14: 80, 11: 86},
                4: "{Y\\R",
                6: 13,
                7: {2: 4},
                8: "1.132.9",
                9: 2,
                10: 1,
                11: "0362625351",
            },
            10: str(group_id),
            11: {"1": "IDC3", "2": 107, "3": "ID"},
            13: "en",
            16: "374f5219",
            20: {1: 21},
            23: "a_6534489873065906362",
            24: "https://dl-sg-production.freefiremobile.com/",
            27: {1: 2, 2: 4},
        },
    }
    return guild_create_packet(guild_create_proto(fields).hex(), "0515", key, iv)


def guild_start_match_team(account_id: int, key: bytes, iv: bytes,
                           region: str = "ID") -> bytes:
    fields = {1: 9, 2: {1: int(account_id), 7: {1: "IDC3", 2: 410, 3: region}}}
    return guild_create_packet(guild_create_proto(fields).hex(), "0515", key, iv)


def guild_ready_for_game(uid: int, key: bytes, iv: bytes) -> bytes:
    return guild_create_packet(
        guild_create_proto({1: 15, 2: {1: uid, 2: 1}}).hex(), "0519", key, iv)


async def guild_build_tcp_startup_packet(account_id, token, server_time, key, iv,
                                         region="ID", typ="OnLine"):
    uid_hex = f"{int(account_id):016x}"
    ts_hex = f"{int(server_time):08x}"
    enc = (await aes_encrypt(token.encode(), key, iv)).hex()
    enc_len = f"{len(enc) // 2:08x}"
    reg = str(region).upper() if region else "ID"
    if typ == "OnLine":
        pfx = "7119" if reg == "ID" else ("7114" if reg == "IND" else "7115")
        return f"{pfx}{uid_hex}{ts_hex}00000000{enc_len}{enc}"
    pfx = "9219" if reg == "ID" else ("9214" if reg == "IND" else "9215")
    return f"{pfx}{uid_hex}{ts_hex}{enc_len}{enc}"


async def guild_send_keep_alive(region="ID"):
    try:
        reg = str(region).upper() if region else "ID"
        return bytes.fromhex("0219" if reg == "ID" else ("0214" if reg == "IND" else "0215"))
    except Exception:
        return bytes.fromhex("0219")


GUILD_BR_HEX = (
    "080112800a0a010110013a110a044944433110aa011a064555524f50453a100a044944433210311a064555524f5045"
    "40014a0801090a0b1219202758016291090a80013038384638324246303241393637363730323031303130303030"
    "30303030303030303031363030303130303135303030323232463937454545304630303030303034363736323531"
    "34303030303030303030303030303030303030303030303030303030303030303030303030306666303030303030"
    "3030636163666131366410241afb02735d5e571400024a775d45414d1a041b1c001f11010449715f4243481a001e"
    "1d071c1703004b1a4066785c524570735c51486775421b5c5a4c07504042685a63610816054e19025e7519600147"
    "7c015165406370195f5547404e4550640103020f1304064863754268676c755f65576e40467e5f0a417a4701026d"
    "675d6e73670b1108495a4c6a0b78470b740065645e525a057258425f584a447d4e6759440c11044e7c596d7f4b62"
    "5f7d04055a47505c4e1d6b5b4107447d7201057d7f0f14084e430457674f7e517d72015172415d027473577c4d61"
    "5f79535256780911030f4d5e027a797f614165067806505d53777750475e75064257076500460817014e741e7e50"
    "78487e7a7c465e7669767153497064605a7376677773550d160148037e18675966787f4c42607a645f577e7b44"
    "1b460776026b18685d0b110205490060020f70676175654674706671797f41067346677c4e06585e780f15074c57"
    "047b40517075415f6364027259674b5b0166407f7340600407770a22047a5d5c52300b3a0a167305067162727516"
    "134208312e3133302e3232480350015ae90403626253513635686e556f4e36416456324b796f566c636f47777648"
    "4f624e56526c4d727073504b4f43654177616848494176795556497273743752737149734a7a786b324752526837"
    "7a2f637664626d504f6a73552f79626d38547a4c69586d2f474351696d494b53486833447955726f39515152756c"
    "34545350626d6d624b7949565937545671577059455372323646572f59624578507338514f706d317372785455736c"
    "30796a434144444d4f34616a654b615753366361496c554b4963797a494e396d52516f715277687939797257476d"
    "337a644345337a6a61436f492f5a585233656f65365a42647a64677654636b6b665733356e4d4c6a6a56507256"
    "4b6433523172756174394e50514150724a5546627859696c4c5a3859707336654d5447666b6649793574666a526c"
    "314d4648706b51774c6373374439656378566c41636f374e664f6d2b30654756466c443474447870677138553359"
    "5973587645384842502f70666c767a737138316a32524f4d7857437556445442492f684735625462773166456e42"
    "49725162762b636144775147696f74554e316d4c4b77734379456f4766706746614251457645672b736a764c4c78"
    "704743334c304a5344532f74526169504354553344374e6249306547516651622f5a466f4c36455630775a324d6f"
    "583932414c572f5049752f56634663584e70596b356f7966326151416a536971486a2f363276354843644f525551"
    "303578754e6171795251625653704654303137655237675255636b4966366c6f447476342b514e4a4670766d7475"
    "7077707774396a5a5974437a4b56743657726d6e36785837706658456251555434684f3758a201050803108703a2"
    "01050804108103a20105080510c001a20105081d10cc01a2010408161078a20105080e10af01a201020815"
)


async def guild_start_game_battle_royale(region, client_version, writer, key, iv):
    packet = bytes.fromhex(GUILD_BR_HEX)
    try:
        proto = CguFF_pb2.StartMatch()
        proto.ParseFromString(packet)
        if hasattr(proto.main, "region_list") and len(proto.main.region_list) > 0:
            proto.main.region_list[0].region = region
            if len(proto.main.region_list) > 1:
                proto.main.region_list[1].region = region
        if hasattr(proto.main, "client_version"):
            proto.main.client_version.remote_version = client_version
        packet = proto.SerializeToString()
    except Exception:
        pass
    enc = (await aes_encrypt(packet, key, iv)).hex()
    plen = len(enc) // 2
    hl = hex(plen)[2:]
    hl = hl if len(hl) > 1 else "0" + hl
    reg = str(region).upper() if region else "BD"
    pfx = "031500" if reg == "ID" else ("031400" if reg == "IND" else "031500")
    final = pfx + "0" * (6 - len(hl)) + hl + enc
    writer.write(bytes.fromhex(final))
    await writer.drain()
    print_info(f"[GUILD] BR search sent ({plen}B) region={reg}", bot_type="guild")


async def guild_zigzag_encode_signed(n: int) -> bytes:
    try:
        n = int(n)
    except Exception:
        n = 0
    zz = (n << 1) ^ (n >> 63)
    if zz < 0:
        zz = -zz
    out = bytearray()
    while True:
        b = zz & 0x7F
        zz >>= 7
        if zz:
            b |= 0x80
        out.append(b)
        if not zz:
            break
    return bytes(out)


async def guild_has_ssan_zig(n: int) -> bytes:
    z = (n << 1) & 0xFFFFFFFFFFFFFFFF
    out = bytearray()
    while z >= 0x80:
        out.append((z & 0x7F) | 0x80)
        z >>= 7
    out.append(z)
    return bytes(out)


async def guild_uleb_encode(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            break
    return bytes(out)


async def guild_build_match_startup_packets(token, udp_key, match_code, account_id,
                                            block_val, server_ip="", region="ID",
                                            client_version="1.132.6",
                                            client_version_code="2019121229",
                                            access_token="",
                                            mode_id=BR_MODE_ID, map_id=BR_MAP_ID):
    token = token.strip()
    udp_key_bytes = bytes.fromhex(udp_key)
    match_code_list = [int(ch) for ch in str(match_code).strip()]
    thunder_jwt = token[:660] if len(token) > 660 else token
    sharma_jwt = token[660:] if len(token) > 660 else ""
    enc_thunder = thunder_jwt.encode() if isinstance(thunder_jwt, str) else thunder_jwt
    enc_sharma = sharma_jwt.encode() if isinstance(sharma_jwt, str) else sharma_jwt
    garena420 = await guild_has_ssan_zig(len(enc_thunder)) + enc_thunder
    reg = str(region).upper() if region else "ID"
    csoversea_block = bytes.fromhex(
        "ca0163736f7665727365612e7374726f6e67686f6c642e66726565666972656d6f62696c652e636f6d"
        "3b302e302e302e303b33342e3132362e37362e34353b33342e38372e3137372e31343b33342e38372e"
        "3137302e3233303b33352e3138352e3138332e35370000000000000100000000000000000000000001"
        "00000800000100000000000100a8a2d7bebd8d8bdf110200")
    mid = bytes.fromhex("0000000001000102030101") + await guild_has_ssan_zig(len(reg)) + reg.encode()
    mid += bytes.fromhex("0001030003000004")
    mid += await guild_has_ssan_zig(len(client_version)) + client_version.encode()
    mid += await guild_has_ssan_zig(len(client_version_code)) + client_version_code.encode()
    mid += csoversea_block
    clean_ip = server_ip.split(":")[0] if server_ip else "0.0.0.0"
    mid += await guild_has_ssan_zig(len(clean_ip)) + clean_ip.encode()
    if access_token:
        clean_acc = access_token.strip()
        mid += await guild_has_ssan_zig(len(clean_acc)) + clean_acc.encode()
    mid += await guild_has_ssan_zig(len(enc_sharma)) + enc_sharma
    tg = (
        await guild_uleb_encode(int(account_id)) +
        await guild_uleb_encode(int(block_val)) +
        await guild_uleb_encode(1) +
        await guild_uleb_encode(int(mode_id)) +
        await guild_uleb_encode(int(block_val)) +
        await guild_uleb_encode(int(map_id)) +
        mid
    )
    process = await sv_frame(0x5E, match_code_list, 2, 447, 0, 1, garena420, udp_key_bytes)
    loading = await sv_frame(0x5A, match_code_list, 2, 448, 1, 1, tg, udp_key_bytes)
    return process.hex(), loading.hex()


async def guild_build_movement_packet_2001(key_bytes, msg_key, player_state, x, y, z,
                                           tick, counter, move_state, account_uid,
                                           room_code, phase="arena"):
    if phase == "game":
        tail = (b"\x00" * 7 + b"\x93\xca\xd5\xf9\x0b" + b"\x8e\xfe\xfc\xf7\x0b"
                + b"\xf4\xe0\xfe\xf7\x03" + b"\x00\x00")
    else:
        tail = (b"\x00" * 7 + b"\xbd\xb6\xe1\xf3\x03" + b"\x00"
                + b"\xc4\xb6\xe1\xfb\x0b" + b"\x00\x00")
    body = bytearray()
    body += await guild_uleb_encode(int(account_uid))
    body += await guild_uleb_encode(int(player_state))
    body += await guild_zigzag_encode_signed(int(x))
    body += await guild_zigzag_encode_signed(int(y))
    body += await guild_zigzag_encode_signed(int(z))
    body += b"\x00"
    body += await guild_uleb_encode(int(move_state))
    body += tail
    body += await guild_uleb_encode(int(tick))
    body += b"\x00\x00\x00"
    body += await guild_uleb_encode(int(counter))
    body = bytes(body)
    k = key_bytes[0]
    v80 = ((k << 8) | k) & 0xFFFF
    h = bytearray()
    h.append(msg_key & 0xFF)
    h.append(0x00)
    h.append(0x00 ^ k)
    h += ((2001 ^ v80) & 0xFFFF).to_bytes(2, "little")
    h += ((len(body) ^ v80) & 0xFFFF).to_bytes(2, "little")
    h.append(0x00 ^ k)
    h[1] = (await crc7_buff(0, bytes(h[2:]) + body)) & 0x7F
    return bytes(h) + body


class GuildMovementTracker:

    PLAYER_STATE = {"idle": 0, "walk": 1, "run": 2, "sprint": 3,
                    "jump": 4, "crouch": 5, "prone": 6}

    def __init__(self, pattern="circle", radius=180):
        self.pattern = pattern
        self.radius = int(radius)
        self.tick = 0
        self.counter = 0
        self.angle = random.uniform(0, 6.2832)
        self.speed_multiplier = 1.0
        self.dir_flip = 1
        self._next_speed_roll = time.time()
        self.state = "walk"
        self.state_start = time.time()
        self.state_duration = random.uniform(2.0, 4.0)
        self._roll_new_speed()

    def _roll_new_speed(self):
        try:
            lo, hi = float(MOVEMENT_SPEED_MIN), float(MOVEMENT_SPEED_MAX)
            if hi < lo:
                lo, hi = hi, lo
            self.speed_multiplier = round(random.uniform(lo, hi), 2)
        except Exception:
            self.speed_multiplier = 1.0
        self._next_speed_roll = time.time() + MOVEMENT_UPDATE_SPEED_EVERY

    def _pick_next_state(self):
        r = random.random()
        ci = MOVEMENT_STATE_IDLE_CHANCE
        cw = ci + MOVEMENT_STATE_WALK_CHANCE
        cr = cw + MOVEMENT_STATE_RUN_CHANCE
        cs = cr + MOVEMENT_STATE_SPRINT_CHANCE
        cj = cs + MOVEMENT_STATE_JUMP_CHANCE
        cc = cj + MOVEMENT_STATE_CROUCH_CHANCE
        if r < ci:
            return "idle", random.uniform(0.6, 1.6)
        if r < cw:
            return "walk", random.uniform(1.6, 3.0)
        if r < cr:
            return "run", random.uniform(2.0, 4.0)
        if r < cs:
            return "sprint", random.uniform(1.2, 2.5)
        if r < cj:
            return "jump", random.uniform(0.35, 0.65)
        if r < cc:
            return "crouch", random.uniform(1.2, 2.5)
        return "prone", random.uniform(1.5, 3.5)

    def _generate_movement(self):
        p = (self.pattern or "circle").lower()
        x = y = z = 0
        ms = 0
        if p == "circle":
            self.angle += 0.35 * self.dir_flip
            if self.angle > 6.2832:
                self.angle -= 6.2832
            elif self.angle < 0:
                self.angle += 6.2832
            x = int(self.radius * random.uniform(0.9, 1.1)
                    * (1.0 if self.angle % 3.14 < 1.57 else -1.0))
            y = int(self.radius * random.uniform(0.4, 0.6))
            z = int(self.radius * random.uniform(0.9, 1.1)
                    * (1.0 if self.angle % 6.28 < 3.14 else -1.0))
            ms = 0x0F
        else:
            x = random.randint(-self.radius, self.radius)
            y = random.randint(-40, 40)
            z = random.randint(-self.radius, self.radius)
            ms = random.choice([0x01, 0x02, 0x04, 0x08, 0x0F])
        return x, y, z, ms

    def next(self):
        now = time.time()
        if now >= self._next_speed_roll:
            self._roll_new_speed()
        if now - self.state_start > self.state_duration:
            old = self.state
            self.state, self.state_duration = self._pick_next_state()
            self.state_start = now
            if old != self.state:
                print_info(f"[MOVE] {old} → {self.state} ({self.state_duration:.2f}s)",
                           bot_type="guild")
        self.tick = (self.tick + 1) & 0xFFFFFFFF
        self.counter = (self.counter + 1) & 0xFFFFFFFF
        ps = self.PLAYER_STATE.get(self.state, 1)
        if self.state in ("idle", "crouch", "prone"):
            x = y = z = 0
            move_state = 0
        else:
            x, y, z, move_state = self._generate_movement()
        return ps, x, y, z, move_state, self.tick, self.counter, self.speed_multiplier, self.state


async def guild_movement_worker(sock, ip, port, udp_key_bytes, match_code,
                                account_id, stop_event, match_index):
    loop = asyncio.get_event_loop()
    addr = (ip, port)
    tracker = GuildMovementTracker(pattern=MOVEMENT_PATTERN, radius=MOVEMENT_RADIUS)
    sent = 0
    try:
        await asyncio.sleep(guild_bypass_jitter(3.0, 0.5))
        while not stop_event.is_set():
            try:
                ps, x, y, z, ms, tick, cnt, sm, st = tracker.next()
                pkt = await guild_build_movement_packet_2001(
                    udp_key_bytes, 0x6B, ps, x, y, z, tick, cnt, ms,
                    account_id, match_code, phase="arena")
                await loop.sock_sendto(sock, pkt, addr)
                sent += 1
                if sent % 30 == 0:
                    print_info(f"[MOVE] #{match_index} sent={sent} {st}({ps}) rate={sm}x",
                               bot_type="guild")
                base = MOVEMENT_TICK_MS / 1000.0
                try:
                    smx = max(0.7, min(float(sm), 1.6))
                except Exception:
                    smx = 1.0
                wait = max(0.10, min(base / smx, 0.40))
                wait = guild_bypass_packet_jitter(wait, 0.20)
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=wait)
                    break
                except asyncio.TimeoutError:
                    pass
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(0.5)
    except asyncio.CancelledError:
        pass
    finally:
        print_info(f"[MOVE] #{match_index} stopped sent={sent}", bot_type="guild")


async def guild_send_anti_afk_fire(sock, addr, udp_key_bytes, match_code, account_id):
    try:
        _ru, nr = await layouts_from_mask(match_code)
        try:
            pid = int(account_id)
        except Exception:
            pid = 0
        ts = int(time.time() * 1000) & 0xFFFFFFFF
        wid = random.choice([101, 102, 103, 201, 202])
        fire = struct.pack("<IIHB", pid & 0xFFFFFFFF, ts, wid, 1)
        fp = await build_packet(0x68, nr, 0, 104, None, 0, fire,
                                udp_key_bytes, encrypted=False)
        loop = asyncio.get_event_loop()
        await loop.sock_sendto(sock, fp, addr)
        await asyncio.sleep(guild_bypass_jitter(random.uniform(0.15, 0.30), 0.05))
        stop = struct.pack("<IIHB", pid & 0xFFFFFFFF, ts + 200, wid, 0)
        sp = await build_packet(0x68, nr, 0, 105, None, 0, stop,
                                udp_key_bytes, encrypted=False)
        await loop.sock_sendto(sock, sp, addr)
        return True
    except Exception:
        return False


async def guild_anti_afk_worker(sock, ip, port, udp_key_bytes, match_code,
                                account_id, stop_event, match_index):
    addr = (ip, port)
    fires = 0
    try:
        await asyncio.sleep(guild_bypass_jitter(2.5, 0.5))
        while not stop_event.is_set():
            try:
                if await guild_send_anti_afk_fire(sock, addr, udp_key_bytes,
                                                  match_code, account_id):
                    fires += 1
                w = random.uniform(ANTI_AFK_MIN_INTERVAL, ANTI_AFK_MAX_INTERVAL)
                w = guild_bypass_packet_jitter(w, 0.25)
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=w)
                    break
                except asyncio.TimeoutError:
                    pass
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(1.0)
    except asyncio.CancelledError:
        pass
    finally:
        if fires > 0:
            print_info(f"[AFK] #{match_index} fires={fires}", bot_type="guild")


class SquadMatchSync:
    """Coordinates squad bots so a full BR match plays out to the natural end.

    Every bot registers as 'active' when the match begins. When its own
    match ends (cmd 103/107 or idle timeout) the bot marks itself dead;
    each bot then waits until every tracked squad member has also
    finished before returning to the lobby.
    """

    def __init__(self):
        self.lock = asyncio.Lock()
        self.active_squad_uids: set = set()
        self.dead_squad_uids: set = set()
        self.all_dead_event = asyncio.Event()

    async def reset_match(self, uids):
        async with self.lock:
            self.active_squad_uids = set(str(u) for u in uids)
            self.dead_squad_uids.clear()
            self.all_dead_event.clear()
            print_info(
                f"[SQUAD SYNC] Match started with "
                f"{len(self.active_squad_uids)} active bot(s)",
                bot_type="guild")

    async def mark_bot_dead(self, uid: str):
        async with self.lock:
            uid = str(uid)
            if uid not in self.active_squad_uids:
                return
            self.dead_squad_uids.add(uid)
            alive_left = len(self.active_squad_uids) - len(self.dead_squad_uids)
            print_warning(
                f"[SQUAD SYNC] Bot {uid} finished match. "
                f"Alive bots remaining: {alive_left}",
                uid, bot_type="guild")
            if len(self.dead_squad_uids) >= len(self.active_squad_uids):
                print_success(
                    "[SQUAD SYNC] All squad bots finished match. "
                    "Exiting game together.",
                    bot_type="guild")
                self.all_dead_event.set()

    async def wait_for_all_dead(self, timeout: float = GUILD_SQUAD_DEATH_WAIT_TIMEOUT):
        try:
            await asyncio.wait_for(self.all_dead_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            print_warning(
                "[SQUAD SYNC] Timeout while waiting for remaining bots. "
                "Backing out now.",
                bot_type="guild")


squad_sync = SquadMatchSync()


async def guild_play_game(server_ip_port, thunder, sharma, udp_key, match_code,
                          account_id, player_region, client_version, key, iv,
                          match_index, on_match_complete=None):
    t0 = time.time()
    ping_task = anti_task = move_task = None
    sock = None
    ping_stop = asyncio.Event()
    anti_stop = asyncio.Event()
    move_stop = asyncio.Event()
    uid_str = str(account_id)
    completed = False
    try:
        ip, port = server_ip_port.split(":")
        port = int(port)
        rip = await resolve_host_cloudflare(ip)
        loop = asyncio.get_event_loop()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(("0.0.0.0", 0))
        except Exception:
            pass
        optimize_udp_socket(sock)
        sock.setblocking(False)
        udp_key_bytes = bytes.fromhex(udp_key)
        await asyncio.sleep(guild_bypass_hello_delay())
        hello = await build_hello_packet(f"{account_id}_2585", udp_key_bytes, match_code)
        await loop.sock_sendto(sock, bytes.fromhex(hello), (rip, port))
        ack_state = "waiting_for_hello_reply"
        thunder_sent = False
        join_match_rcv = False
        local_closed = False
        send_lock = asyncio.Lock()
        anti_started = False
        ping_task = asyncio.create_task(
            keepalive_ping_loop(sock, rip, port, udp_key_bytes, match_code, ping_stop))
        last_activity = time.time()
        print_match_box(match_index, "?", uid_str, server_ip_port,
                        "UDP STARTED", bot_type="guild")

        async def start_workers():
            nonlocal anti_task, move_task, anti_started
            if anti_started:
                return
            anti_started = True
            anti_task = asyncio.create_task(
                guild_anti_afk_worker(sock, rip, port, udp_key_bytes, match_code,
                                      account_id, anti_stop, match_index))
            print_success(f"[AFK] Worker #{match_index} active", bot_type="guild")
            if ENABLE_SPEED_MOVEMENT:
                move_task = asyncio.create_task(
                    guild_movement_worker(sock, rip, port, udp_key_bytes, match_code,
                                          account_id, move_stop, match_index))
                print_success(f"[MOVE] Worker #{match_index} | {MOVEMENT_PATTERN}",
                              bot_type="guild")

        async def send_startup():
            nonlocal ack_state, thunder_sent
            if thunder_sent:
                return
            async with send_lock:
                if thunder_sent:
                    return
                try:
                    await loop.sock_sendto(sock, bytes.fromhex(thunder), (rip, port))
                    thunder_sent = True
                    await asyncio.sleep(guild_bypass_jitter(0.1, 0.05))
                    _ru, nr = await layouts_from_mask(match_code)
                    ack = await build_packet(0x68, nr, 0, 2, None, 1,
                                             b"\x01\x00", udp_key_bytes)
                    await loop.sock_sendto(sock, ack, (rip, port))
                    await asyncio.sleep(guild_bypass_jitter(0.2, 0.05))
                    await loop.sock_sendto(sock, bytes.fromhex(sharma), (rip, port))
                    ack_state = "thunder_sharma_sent"
                    print_success(f"[MATCH #{match_index}] Startup delivered",
                                  bot_type="guild")
                    await start_workers()
                except Exception as e:
                    print_error(f"[MATCH #{match_index}] startup: {e}",
                                bot_type="guild")

        while not local_closed:
            if time.time() - t0 > GUILD_MAX_MATCH_DURATION:
                break
            try:
                resp, saddr = await asyncio.wait_for(
                    loop.sock_recvfrom(sock, 65535), timeout=1.5)
                if resp:
                    last_activity = time.time()
                    frame = await decode_packet(resp, udp_key_bytes, match_code)
                    if frame:
                        pt = await classify_packet(frame)
                        if frame["cmd"] in (103, 107):
                            print_success(
                                f"[MATCH #{match_index}] END cmd={frame['cmd']} "
                                f"for UID {uid_str}",
                                bot_type="guild")
                            completed = True
                            await squad_sync.mark_bot_dead(uid_str)
                            local_closed = True
                            continue
                        if frame["cmd"] == 101:
                            try:
                                _ru, nr = await layouts_from_mask(match_code)
                                a = await build_packet(0x68, nr, 0, 2, None, 1,
                                                       b"\x01\x00", udp_key_bytes)
                                await loop.sock_sendto(sock, a, saddr)
                            except Exception:
                                pass
                            continue
                        if pt in ("ACK", "PING", "HELLO", "JOIN_MATCH"):
                            if pt == "HELLO" and ack_state == "waiting_for_hello_reply":
                                _t, r = await reply_for_packet(
                                    frame, udp_key_bytes, match_code, ack_style="short")
                                if r:
                                    await loop.sock_sendto(sock, r, saddr)
                                ack_state = "ack_sent_waiting"
                            elif pt == "ACK":
                                if ack_state == "waiting_for_hello_reply":
                                    _t, r = await reply_for_packet(
                                        frame, udp_key_bytes, match_code)
                                    if r:
                                        await loop.sock_sendto(sock, r, saddr)
                                    ack_state = "ready_to_send_thunder"
                                elif ack_state == "ack_sent_waiting":
                                    ack_state = "ready_to_send_thunder"
                                else:
                                    _t, r = await reply_for_packet(
                                        frame, udp_key_bytes, match_code)
                                    if r:
                                        await loop.sock_sendto(sock, r, saddr)
                            elif pt == "PING":
                                _t, r = await reply_for_packet(
                                    frame, udp_key_bytes, match_code)
                                if r:
                                    await loop.sock_sendto(sock, r, saddr)
                            elif pt == "JOIN_MATCH" and not join_match_rcv:
                                _t, r = await reply_for_packet(
                                    frame, udp_key_bytes, match_code)
                                if r:
                                    await loop.sock_sendto(sock, r, saddr)
                                    join_match_rcv = True
            except asyncio.TimeoutError:
                if ack_state == "ready_to_send_thunder" and not thunder_sent:
                    await send_startup()
                elif ack_state == "waiting_for_hello_reply":
                    if (time.time() - last_activity) > 7.0:
                        try:
                            hp = await build_hello_packet(
                                f"{account_id}_2585", udp_key_bytes, match_code)
                            await loop.sock_sendto(sock, bytes.fromhex(hp), (rip, port))
                        except Exception:
                            pass
                        last_activity = time.time()
                    if (time.time() - t0) > 25.0:
                        print_warning(f"[MATCH #{match_index}] Handshake timeout",
                                      bot_type="guild")
                        await squad_sync.mark_bot_dead(uid_str)
                        break
                elif ack_state == "thunder_sharma_sent":
                    if (time.time() - last_activity) > GUILD_MATCH_IDLE_TIMEOUT:
                        print_success(
                            f"[MATCH #{match_index}] Finished naturally/idle "
                            f"for UID {uid_str}",
                            bot_type="guild")
                        completed = True
                        await squad_sync.mark_bot_dead(uid_str)
                        break
                continue
            except BlockingIOError:
                await asyncio.sleep(0.05)
            except OSError:
                await asyncio.sleep(0.5)
                continue
            except Exception:
                await asyncio.sleep(0.5)
                continue
            if ack_state == "ready_to_send_thunder" and not thunder_sent:
                try:
                    await send_startup()
                except Exception:
                    pass

        print_info(
            f"[MATCH #{match_index}] Bot {uid_str} waiting for the rest of "
            f"the squad to finish...",
            bot_type="guild")
        await squad_sync.wait_for_all_dead()
        print_success(
            f"[MATCH #{match_index}] Bot {uid_str} returning to lobby after "
            f"full squad completion.",
            bot_type="guild")
        return f"guild match #{match_index} finished"
    except asyncio.CancelledError:
        try:
            await squad_sync.mark_bot_dead(uid_str)
        except Exception:
            pass
        raise
    except Exception as e:
        print_error(f"[MATCH #{match_index}] guild error: {e}", bot_type="guild")
        try:
            await squad_sync.mark_bot_dead(uid_str)
        except Exception:
            pass
        return f"guild match #{match_index} error"
    finally:
        if completed:
            try:
                bot_state.increment_match(f"guild:{uid_str}")
            except Exception:
                pass
            if on_match_complete:
                try:
                    asyncio.create_task(on_match_complete())
                except Exception:
                    pass
        anti_stop.set()
        move_stop.set()
        for t in (anti_task, move_task):
            if t:
                try:
                    await asyncio.wait_for(t, timeout=2.0)
                except Exception:
                    t.cancel()
                    try:
                        await t
                    except Exception:
                        pass
        ping_stop.set()
        if ping_task:
            ping_task.cancel()
            try:
                await ping_task
            except asyncio.CancelledError:
                pass
        if sock:
            try:
                sock.close()
            except Exception:
                pass
        rem = await guild_dec_match(uid_str)
        total = await guild_get_total_match_count()
        print_info(f"[MATCH #{match_index}] Closed. UID:{rem} Total:{total}",
                   bot_type="guild")
        try:
            bot_state.update_status(f"guild:{uid_str}",
                                    "IN_MATCH" if rem > 0 else "ONLINE", rem)
        except Exception:
            pass


async def guild_process_social_packet(raw_bytes: bytes,
                                      account_data: Dict[str, Any],
                                      tag: str = "MAIN"):
    try:
        hex_data = raw_bytes.hex()
        candidates: List[Tuple[int, Dict[str, Any]]] = []
        if len(raw_bytes) >= 6:
            plen = raw_bytes[4]
            if 0 < plen <= (len(raw_bytes) - 5):
                try:
                    inner = bytes(raw_bytes[5:5 + plen])
                    d0 = decode_protobuf_dict_safe(inner) or wrap_manual_decode(inner)
                    if d0:
                        candidates.append((5, d0))
                except Exception:
                    pass
        for off in (5, 6, 10, 8, 12, 4, 0):
            if off >= len(hex_data):
                continue
            try:
                inner = bytes.fromhex(hex_data[off:])
            except Exception:
                continue
            decoded = decode_protobuf_dict_safe(inner) or wrap_manual_decode(inner)
            if decoded:
                candidates.append((off, decoded))
        if not candidates:
            return
        candidates.sort(key=lambda x: len(x[1]) if isinstance(x[1], dict) else 0,
                        reverse=True)
        _best_off, decoded = candidates[0]

        def _v(c, k):
            if not isinstance(c, dict):
                return None
            v = c.get(k) if k in c else c.get(str(k))
            if isinstance(v, dict) and "data" in v:
                return v["data"]
            return v

        f5w = decoded.get("5") or decoded.get(5) if isinstance(decoded, dict) else None
        f5 = f5w["data"] if isinstance(f5w, dict) and "data" in f5w else f5w
        target = None
        if isinstance(f5, dict):
            for fk in (1, 2, 3, 4, 6):
                c = _v(f5, fk)
                if c and str(c).isdigit() and 6 <= len(str(c)) <= 15:
                    target = str(c)
                    break
        if not target:
            return
        own = str(account_data.get("account_id", "")) if account_data else ""
        if own and target == own:
            return
        if not _accept_friend_request or not account_data:
            return
        jwt = account_data.get("token")
        srv = account_data.get("server_url")
        rel = account_data.get("release_version")
        own_id = account_data.get("account_id")
        if not (jwt and srv and rel and own_id):
            return
        url = f"{srv.rstrip('/')}/ConfirmFriendRequest"
        fields = {"1": int(target), "2": int(own_id)}
        try:
            payload = bytes.fromhex(encrypt_api_hex(guild_create_proto(fields).hex()))
            hdrs = {
                "authorization": f"Bearer {jwt}",
                "host": srv.replace("https://", "").replace("http://", "").split("/")[0],
                "x-ga": "v1 1",
                "content-type": "application/x-www-form-urlencoded",
                "accept-encoding": "deflate, gzip",
                "releaseversion": f"{rel}",
                "user-agent": "UnityPlayer/2022.3.47f1",
                "accept": "*/*",
                "x-unity-version": "2022.3.47f1",
            }
            async with httpx.AsyncClient(verify=False, timeout=8.0) as s:
                r = await s.post(url, headers=hdrs, content=payload)
                if r.status_code == 200 and len(r.content) > 0:
                    print_success(f"[FRIEND-{tag}] accepted {target}", bot_type="guild")
        except Exception:
            pass
    except Exception:
        pass


async def guild_handle_team_invite(hex_data: str, pl: int, uid_str: str,
                                   current_account_data: Dict[str, Any],
                                   current_key: bytes, current_iv: bytes,
                                   writer):
    try:
        if DEBUG_TEAM_PACKETS:
            print_info(f"[TEAM-IN {uid_str}] len={pl} hex={hex_data[:80]}",
                       uid_str, bot_type="guild")
        candidates: List[Tuple[int, str, Dict[str, Any]]] = []
        for off in (10, 8, 6, 12, 14, 4, 16, 0, 20, 2):
            if off >= len(hex_data) or len(hex_data) - off < 4:
                continue
            try:
                inner = bytes.fromhex(hex_data[off:])
            except Exception:
                continue
            dec = decode_protobuf_dict_safe(inner)
            if dec and isinstance(dec, dict) and len(dec) > 0:
                candidates.append((off, "parser", dec))
                continue
            alt = _decode_proto_manual(inner)
            if alt and len(alt) > 0:
                candidates.append((off, "manual",
                                   {str(k): {"data": v} for k, v in alt.items()}))
        if not candidates:
            return False
        candidates.sort(key=lambda x: len(x[2]) if isinstance(x[2], dict) else 0,
                        reverse=True)
        _best_off, _decoder, dec = candidates[0]

        def _unwrap(d, keys):
            if not isinstance(d, dict):
                return None
            for k in keys:
                v = d.get(k) if k in d else d.get(str(k))
                if isinstance(v, dict) and "data" in v:
                    return v["data"]
                if isinstance(v, dict):
                    return v
            return None

        target_dict = None
        for kp in (("5",), ("4",), ("6",), ("2",), ("1",)):
            u = _unwrap(dec, kp)
            if isinstance(u, dict) and len(u) >= 3:
                target_dict = u
                break
        if target_dict is None:
            target_dict = dec

        def _g(d, k):
            if not isinstance(d, dict):
                return None
            v = d.get(k) if k in d else d.get(str(k))
            if isinstance(v, dict) and "data" in v:
                return v["data"]
            if isinstance(v, dict):
                for kk in ("1", "2", "3", "4", "5", "6", "7", "8"):
                    vv = v.get(kk) if kk in v else v.get(int(kk))
                    if isinstance(vv, dict) and "data" in vv:
                        return vv["data"]
            return v

        group_id = None
        for k in list(target_dict.keys()):
            c = _g(target_dict, k)
            if isinstance(c, str) and 20 <= len(c) <= 40:
                group_id = c
                break
        if not group_id:
            for k in list(dec.keys()):
                c = _g(dec, k)
                if isinstance(c, str) and 20 <= len(c) <= 40:
                    group_id = c
                    break

        own_acc = str(current_account_data.get("account_id")) if current_account_data else None
        inviter = None
        all_fields = list(target_dict.keys()) + list(dec.keys())
        for k in all_fields:
            c = _g(target_dict, k) or _g(dec, k)
            if c and str(c).isdigit() and 6 <= len(str(c)) <= 15:
                if str(c) != uid_str and str(c) != own_acc:
                    inviter = str(c)
                    break

        tc = None
        for k in all_fields:
            c = _g(target_dict, k) or _g(dec, k)
            if c and str(c).isdigit() and len(str(c)) == 7:
                tc = str(c)
                break
        if tc:
            async with _guild_team_state["lock"]:
                _guild_team_state["team_code"] = tc

        is_member = (_guild_team_state["leader_uid"] != uid_str)
        if inviter and group_id and is_member:
            async with _guild_team_state["members_lock"]:
                already = uid_str in _guild_team_state["members"]
            if already:
                return True
            print_success(f"[TEAM-IN {uid_str}] accepting invite from {inviter}",
                          uid_str, bot_type="guild")
            accepted = False
            for attempt in range(3):
                try:
                    acc = guild_accept_team_invite(int(inviter), group_id,
                                                   current_key, current_iv)
                    if writer and not writer.is_closing():
                        writer.write(acc)
                        await writer.drain()
                        accepted = True
                        break
                except Exception as e:
                    print_warning(f"[TEAM-IN {uid_str}] accept attempt "
                                  f"#{attempt + 1} failed: {e}",
                                  uid_str, bot_type="guild")
                await asyncio.sleep(0.8)
            if accepted:
                await guild_team_member_join(uid_str)
            return True
        return False
    except Exception as e:
        print_warning(f"[TEAM-IN {uid_str}] error: {e}", uid_str, bot_type="guild")
        return False


async def guild_ping_worker(account_id, token, release_version, region="ID"):
    if not ENABLE_HTTP_PING:
        return
    uid_str = str(account_id)
    ok_count = 0
    fails = 0
    try:
        await asyncio.sleep(5.0 + random.uniform(0, 2.0))
        while True:
            try:
                acc = int(uid_str)
            except Exception:
                acc = 0
            try:
                now_ms = int(time.time() * 1000)
                payload = struct.pack("<Q", acc & 0xFFFFFFFFFFFFFFFF) + struct.pack(
                    "<Q", now_ms & 0xFFFFFFFFFFFFFFFF)
                req_id = secrets.token_urlsafe(18)[:22]
                hdrs = {
                    "accept": "*/*",
                    "accept-encoding": "deflate, gzip",
                    "authorization": f"Bearer {token}",
                    "content-type": "application/x-www-form-urlencoded",
                    "releaseversion": release_version,
                    "user-agent": "UnityPlayer/2018.4.12f1",
                    "x-ga": "v1 1",
                    "x-ga-sv": str(int(time.time())),
                    "x-railway-edge": "sin1",
                    "x-railway-request-id": req_id,
                    "x-real-ip": PING_REAL_IP,
                    "x-request-start": str(now_ms),
                    "x-unity-version": "2018.4.12f1",
                }
                r = await http_client.post(PING_URL, headers=hdrs, content=payload,
                                           timeout=PING_TIMEOUT)
                ok = r.status_code == 200
            except Exception:
                ok = False
            if ok:
                ok_count += 1
                fails = 0
                if ok_count % 10 == 0:
                    print_info(f"[PING] {uid_str} OK total={ok_count}",
                               uid_str, bot_type="guild")
            else:
                fails += 1
                if fails <= 3:
                    print_warning(f"[PING] {uid_str} fail #{fails}",
                                  uid_str, bot_type="guild")
            await asyncio.sleep(max(5.0, PING_INTERVAL + random.uniform(-3.0, 3.0)))
    except asyncio.CancelledError:
        pass
    finally:
        print_info(f"[PING] Stopped {uid_str} OK={ok_count}", uid_str, bot_type="guild")


async def guild_informational(addrs, starter_packet, key, iv, region="ID", max_reconnects=3):
    reconnects = 0
    ip, port = addrs.split(":")
    while True:
        writer = None
        ping_task = None
        try:
            rip = await resolve_host_cloudflare(ip)
            reader, writer = await asyncio.open_connection(rip, int(port))
            rs = writer.get_extra_info("socket")
            if rs:
                optimize_tcp_socket(rs)
            writer.write(bytes.fromhex(starter_packet))
            await writer.drain()
            reconnects = 0
            try:
                ka = await guild_send_keep_alive(region)
                if ka and not writer.is_closing():
                    writer.write(ka)
                    await asyncio.wait_for(writer.drain(), timeout=3)
            except Exception:
                pass

            async def info_ka():
                ka_bytes = await guild_send_keep_alive(region)
                while True:
                    await asyncio.sleep(guild_bypass_ka_jitter(5.0))
                    try:
                        if writer and not writer.is_closing():
                            writer.write(ka_bytes)
                            await writer.drain()
                    except Exception:
                        break

            ping_task = asyncio.create_task(info_ka())
            while True:
                data = await reader.read(8192)
                if not data:
                    raise ConnectionError("closed")
        except asyncio.CancelledError:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            raise
        except Exception:
            if ping_task:
                ping_task.cancel()
            if writer:
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
            reconnects += 1
            if reconnects > max_reconnects:
                await asyncio.sleep(3)
                reconnects = 0
            else:
                await asyncio.sleep(1)


async def guild_functional_battle_royale(addrs, starter_packet, account_region,
                                         client_version, key, iv, account_id="",
                                         account_data=None, account_level=2,
                                         max_reconnects=10):
    reconnects = 0
    ip, port = addrs.split(":")
    play_matches: List[asyncio.Task] = []
    no_response_count = 0
    search_attempts = 0
    last_start_time = 0.0
    uid_str = str(account_id)
    current_level = int(account_level or 2)
    consecutive_parse_failures = 0
    current_token = starter_packet
    current_key = key
    current_iv = iv
    current_account_data = account_data
    reconnect_count_total = 0
    region_index = 0
    current_search_region = GUILD_REGION_ROTATION_LIST[0]
    writer_ref = {"w": None}
    team_active = {"flag": True}
    desired_key = f"guild:{uid_str}"

    async def trigger_post_match_refresh():
        await asyncio.sleep(GUILD_EXP_REFRESH_AFTER_MATCH_DELAY)
        try:
            cd = bot_state.account_credentials.get(desired_key)
            if cd:
                await refresh_account_profile(cd, bot_type="guild")
        except Exception:
            pass

    async def team_coordinator():
        """Runs on the leader bot.

        Behaviour:
          * Wait up to TEAM_PEER_WAIT_TIMEOUT for peers to come online.
          * If SMART_MODE is on, first wait SMART_WAIT_MIN..MAX; if by
            then we have the full squad, we build a team; if not, the
            leader falls back to a solo BR search.
          * When a team has been created, keep inviting peers on a
            cycle until the team fills or the invite window expires.
          * Keep ready+start loop running so new matches keep starting.
        """
        try:
            peers_ready_deadline = time.time() + TEAM_PEER_WAIT_TIMEOUT

            # ── Smart wait: give peers a short head start ──────────
            smart_deadline = time.time() + random.uniform(SMART_WAIT_MIN,
                                                          SMART_WAIT_MAX) \
                if SMART_MODE_ENABLED else time.time()
            while time.time() < smart_deadline:
                async with _guild_team_state["lock"]:
                    n = len(_guild_team_state["peers"])
                if n >= TEAM_SIZE:
                    break
                if bot_state.is_paused(desired_key):
                    return
                await asyncio.sleep(0.5)

            async with _guild_team_state["lock"]:
                n = len(_guild_team_state["peers"])
                is_leader = (_guild_team_state["leader_uid"] == uid_str)
                peers_snapshot = dict(_guild_team_state["peers"])

            if not is_leader:
                return

            # ── Solo fallback when squad never assembled ───────────
            if n < TEAM_SIZE:
                print_warning(
                    f"[GUILD] Only {n}/{TEAM_SIZE} peers online after smart wait "
                    f"— starting solo BR search",
                    uid_str, bot_type="guild")
                while team_active["flag"]:
                    if bot_state.is_paused(desired_key):
                        return
                    try:
                        active = await guild_get_match_count(uid_str)
                        if active > 0:
                            await asyncio.sleep(3.0)
                            continue
                        await guild_start_game_battle_royale(
                            current_search_region, client_version,
                            writer_ref["w"], current_key, current_iv)
                        try:
                            bot_state.update_status(desired_key, "SEARCHING", 0)
                        except Exception:
                            pass
                    except Exception as e:
                        print_warning(f"[GUILD] solo search err: {e}",
                                      uid_str, bot_type="guild")
                    try:
                        await asyncio.wait_for(asyncio.sleep(GUILD_START_MATCH_INTERVAL),
                                               timeout=GUILD_START_MATCH_INTERVAL + 0.5)
                    except asyncio.TimeoutError:
                        pass
                return

            # ── Full squad path ────────────────────────────────────
            print_success(f"[GUILD] All {n} peers online — creating team",
                          uid_str, bot_type="guild")
            await asyncio.sleep(TEAM_READY_DELAY)

            async with _guild_team_state["lock"]:
                _guild_team_state["team_code"] = None
                _guild_team_state["pk_code"] = None

            own_id_num = current_account_data.get("account_id") if current_account_data else 0
            if not own_id_num:
                try:
                    own_id_num = int(uid_str)
                except Exception:
                    own_id_num = 0

            try:
                pkt = guild_create_team(current_key, current_iv, client_version)
                if writer_ref["w"] and not writer_ref["w"].is_closing():
                    writer_ref["w"].write(pkt)
                    await writer_ref["w"].drain()
                    await guild_team_member_reset(keep_leader=False)
                    await guild_team_member_join(uid_str)
            except Exception as e:
                print_error(f"[GUILD] create_team: {e}", uid_str, bot_type="guild")

            await asyncio.sleep(TEAM_CREATE_WAIT)

            peer_uids: List[int] = []
            for peer_uid, info in peers_snapshot.items():
                if peer_uid == uid_str:
                    continue
                pa = None
                try:
                    pa = info["data"].get("account_id")
                except Exception:
                    pass
                if not pa:
                    pa = peer_uid
                try:
                    peer_uids.append(int(pa))
                except Exception:
                    pass

            heartbeat_stop = asyncio.Event()

            async def heartbeat_loop():
                while not heartbeat_stop.is_set():
                    try:
                        if writer_ref["w"] and not writer_ref["w"].is_closing():
                            pkt = guild_team_fresh(int(own_id_num), current_key, current_iv)
                            writer_ref["w"].write(pkt)
                            await writer_ref["w"].drain()
                    except Exception:
                        pass
                    try:
                        await asyncio.wait_for(heartbeat_stop.wait(),
                                               timeout=TEAM_HEARTBEAT_INTERVAL)
                    except asyncio.TimeoutError:
                        pass

            hb_task = asyncio.create_task(heartbeat_loop())

            invite_start = time.time()
            cycle = 0
            while time.time() - invite_start < TEAM_INVITE_MAX_TIME:
                if not team_active["flag"]:
                    break
                if bot_state.is_paused(desired_key):
                    break
                cnt = await guild_team_member_count()
                if cnt >= TEAM_SIZE:
                    print_success(f"[GUILD] Team full {cnt}/{TEAM_SIZE}",
                                  uid_str, bot_type="guild")
                    break
                cycle += 1
                for tuid in peer_uids:
                    async with _guild_team_state["members_lock"]:
                        joined = str(tuid) in _guild_team_state["members"]
                    if joined:
                        continue
                    try:
                        inv = guild_invite_player_in_team(
                            tuid, current_key, current_iv, region=account_region)
                        if writer_ref["w"] and not writer_ref["w"].is_closing():
                            writer_ref["w"].write(inv)
                            await writer_ref["w"].drain()
                    except Exception:
                        pass
                    await asyncio.sleep(0.5)
                try:
                    await asyncio.wait_for(heartbeat_stop.wait(),
                                           timeout=TEAM_INVITE_CYCLE_WAIT)
                except asyncio.TimeoutError:
                    pass

            final_cnt = await guild_team_member_count()
            heartbeat_stop.set()
            try:
                hb_task.cancel()
                await hb_task
            except Exception:
                pass

            if final_cnt < TEAM_SIZE:
                print_error(
                    f"[GUILD] Only {final_cnt}/{TEAM_SIZE} joined — "
                    f"falling back to solo BR search",
                    uid_str, bot_type="guild")
                while team_active["flag"]:
                    if bot_state.is_paused(desired_key):
                        return
                    try:
                        active = await guild_get_match_count(uid_str)
                        if active > 0:
                            await asyncio.sleep(3.0)
                            continue
                        await guild_start_game_battle_royale(
                            current_search_region, client_version,
                            writer_ref["w"], current_key, current_iv)
                    except Exception:
                        pass
                    try:
                        await asyncio.wait_for(asyncio.sleep(GUILD_START_MATCH_INTERVAL),
                                               timeout=GUILD_START_MATCH_INTERVAL + 0.5)
                    except asyncio.TimeoutError:
                        pass
                return

            await asyncio.sleep(TEAM_FINAL_WAIT)

            # ── Team ready: ready → 1s → start-match loop ──────────
            while team_active["flag"]:
                try:
                    if bot_state.is_paused(desired_key):
                        break
                    active_matches = await guild_get_match_count(uid_str)
                    if active_matches > 0:
                        await asyncio.sleep(2.0)
                        continue
                    async with _guild_team_state["lock"]:
                        if _guild_team_state["leader_uid"] != uid_str:
                            break
                    oid = (current_account_data.get("account_id", own_id_num)
                           if current_account_data else own_id_num)
                    try:
                        rdy = guild_ready_for_game(int(oid), current_key, current_iv)
                        if writer_ref["w"] and not writer_ref["w"].is_closing():
                            writer_ref["w"].write(rdy)
                            await writer_ref["w"].drain()
                    except Exception:
                        pass
                    await asyncio.sleep(1.0)
                    sm = guild_start_match_team(int(oid), current_key, current_iv,
                                                region=account_region)
                    if writer_ref["w"] and not writer_ref["w"].is_closing():
                        writer_ref["w"].write(sm)
                        await writer_ref["w"].drain()
                except Exception:
                    pass
                try:
                    await asyncio.wait_for(asyncio.sleep(5.0), timeout=5.5)
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print_error(f"[GUILD] team_coordinator: {e}", uid_str, bot_type="guild")
            traceback.print_exc()

    async def member_match_trigger():
        try:
            await asyncio.sleep(TEAM_READY_DELAY + TEAM_MEMBER_START_DELAY)
            async with _guild_team_state["lock"]:
                if _guild_team_state["leader_uid"] == uid_str:
                    return
            my_id = (current_account_data.get("account_id", uid_str)
                     if current_account_data else uid_str)
            while team_active["flag"]:
                try:
                    if bot_state.is_paused(desired_key):
                        break
                    active_matches = await guild_get_match_count(uid_str)
                    if active_matches > 0:
                        await asyncio.sleep(2.0)
                        continue
                    if writer_ref["w"] and not writer_ref["w"].is_closing():
                        try:
                            rdy = guild_ready_for_game(int(my_id), current_key, current_iv)
                            writer_ref["w"].write(rdy)
                            await writer_ref["w"].drain()
                        except Exception:
                            pass
                        await asyncio.sleep(1.0)
                        sm = guild_start_match_team(int(my_id), current_key, current_iv,
                                                    region=account_region)
                        writer_ref["w"].write(sm)
                        await writer_ref["w"].drain()
                except Exception:
                    pass
                try:
                    await asyncio.wait_for(asyncio.sleep(5.0), timeout=5.5)
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            raise
        except Exception:
            pass

    try:
        while True:
            writer = None
            gateway_ping_task = None
            team_coord_task = None
            member_trigger_task = None
            try:
                if current_account_data:
                    fresh = None
                    if (current_account_data.get("auth_type") == "guest"
                            and current_account_data.get("auth_uid")):
                        fresh = TokenCache.get(str(current_account_data["auth_uid"]),
                                               TOKEN_CACHE_TTL_GUILD)
                    elif (current_account_data.get("auth_type") == "token"
                          and current_account_data.get("auth_token")):
                        fresh = TokenCache.get(
                            f"tok_{current_account_data['auth_token'][:20]}",
                            TOKEN_CACHE_TTL_GUILD)
                    if fresh:
                        current_account_data = fresh
                        current_key = fresh["aes_ak"]
                        current_iv = fresh["iv_i"]
                        current_token = await guild_build_tcp_startup_packet(
                            fresh["account_id"], fresh["token"], fresh["server_time"],
                            current_key, current_iv,
                            region=fresh.get("region", account_region), typ="OnLine")
                        try:
                            lv = int(fresh.get("level", current_level) or current_level)
                            if lv != current_level:
                                current_level = lv
                        except Exception:
                            pass
                    else:
                        try:
                            if current_account_data.get("auth_uid"):
                                TokenCache.invalidate(str(current_account_data["auth_uid"]))
                            if current_account_data.get("auth_token"):
                                TokenCache.invalidate(
                                    f"tok_{current_account_data['auth_token'][:20]}")
                        except Exception:
                            pass
                        raise ConnectionError("Cache expired")

                try:
                    if desired_key in bot_state.accounts:
                        ll = int(bot_state.accounts[desired_key].get("level", current_level)
                                 or current_level)
                        if ll != current_level:
                            current_level = ll
                except Exception:
                    pass

                rip = await resolve_host_cloudflare(ip)
                reader, writer = await asyncio.open_connection(rip, int(port))
                writer_ref["w"] = writer
                raw_sock = writer.get_extra_info("socket")
                if raw_sock:
                    optimize_tcp_socket(raw_sock)
                await asyncio.sleep(guild_bypass_hello_delay())
                writer.write(bytes.fromhex(current_token))
                await writer.drain()
                try:
                    ka = await guild_send_keep_alive(account_region)
                    if ka and not writer.is_closing():
                        writer.write(ka)
                        await asyncio.wait_for(writer.drain(), timeout=3)
                except Exception:
                    pass

                async def gateway_keepalive():
                    ka_bytes = await guild_send_keep_alive(account_region)
                    while True:
                        await asyncio.sleep(guild_bypass_ka_jitter(5.0))
                        try:
                            if writer and not writer.is_closing():
                                writer.write(ka_bytes)
                                await writer.drain()
                        except Exception:
                            break

                gateway_ping_task = asyncio.create_task(gateway_keepalive())

                connection_start_time = asyncio.get_running_loop().time()
                last_watchdog_check = connection_start_time
                search_attempts = 0
                if (reconnect_count_total > 0
                        and (reconnect_count_total % GUILD_REGION_ROTATE_EVERY_N == 0)):
                    region_index = (region_index + 1) % len(GUILD_REGION_ROTATION_LIST)
                    current_search_region = GUILD_REGION_ROTATION_LIST[region_index]
                    print_warning(f"[GUILD] Region rotated to {current_search_region}",
                                  uid_str, bot_type="guild")
                else:
                    current_search_region = GUILD_REGION_ROTATION_LIST[region_index]

                print_success(
                    f"[GUILD] TCP connected {uid_str} "
                    f"(DNS:{rip} Level:{current_level} Region:{current_search_region})",
                    uid_str, bot_type="guild")
                reconnects = 0
                no_response_count = 0
                last_start_time = 0.0

                async with _guild_team_state["lock"]:
                    _guild_team_state["peers"][uid_str] = {
                        "writer": writer,
                        "data": current_account_data,
                        "key": current_key,
                        "iv": current_iv,
                    }
                    if (_guild_team_state["leader_uid"] is None
                            or _guild_team_state["leader_uid"] not in
                            _guild_team_state["peers"]):
                        _guild_team_state["leader_uid"] = uid_str
                        print_success(f"[GUILD] {uid_str} is leader",
                                      uid_str, bot_type="guild")

                if TEAM_MODE:
                    team_coord_task = asyncio.create_task(team_coordinator())
                    member_trigger_task = asyncio.create_task(member_match_trigger())
                else:
                    await guild_start_game_battle_royale(
                        current_search_region, client_version, writer,
                        current_key, current_iv)

                while True:
                    play_matches[:] = [m for m in play_matches if not m.done()]
                    active = await guild_get_match_count(uid_str)
                    try:
                        bot_state.update_status(
                            desired_key,
                            "ONLINE" if active == 0 else "IN_MATCH", active)
                    except Exception:
                        pass

                    now = asyncio.get_running_loop().time()
                    if now - last_watchdog_check >= GUILD_MATCH_WATCHDOG_CHECK:
                        last_watchdog_check = now
                        sd = now - connection_start_time
                        if sd > 30:
                            print_warning(
                                f"[GUILD] {uid_str} searching {int(sd)}s "
                                f"attempts={search_attempts}",
                                uid_str, bot_type="guild")
                        if sd > GUILD_MATCH_SEARCH_TIMEOUT and not GUILD_SEARCH_FOREVER:
                            raise ConnectionError("Search watchdog")
                        if GUILD_SEARCH_FOREVER:
                            connection_start_time = now

                    try:
                        data = await asyncio.wait_for(reader.read(8192), timeout=0.5)
                    except asyncio.TimeoutError:
                        no_response_count += 1
                        if TEAM_MODE:
                            if no_response_count > TEAM_IDLE_ITERS_TEAM:
                                raise ConnectionError("Team idle timeout")
                        else:
                            if no_response_count > 80:
                                raise ConnectionError("Idle timeout")
                        continue

                    if not data:
                        raise ConnectionError("closed")

                    hex_data = data.hex()
                    pl = len(data)
                    no_response_count = 0

                    if (DEBUG_TEAM_PACKETS
                            and not hex_data.startswith("0300")
                            and not hex_data.startswith("0600")):
                        print_info(f"[GUILD-IN {uid_str}] len={pl} prefix={hex_data[:24]}",
                                   uid_str, bot_type="guild")

                    if hex_data.startswith("0600") and pl > 20:
                        await guild_process_social_packet(
                            data, current_account_data, tag="MAIN")
                        continue

                    if hex_data.startswith("05") and pl > 10:
                        await guild_handle_team_invite(
                            hex_data, pl, uid_str, current_account_data,
                            current_key, current_iv, writer)
                        continue

                    if hex_data.startswith("0300") and 10 < pl < 30:
                        continue

                    if hex_data.startswith("0300") and pl >= 300:
                        print_colored("=" * 60, Colors.GREEN)
                        print_colored("GUILD MATCH FOUND! Loading...", Colors.GREEN)
                        print_colored("=" * 60, Colors.GREEN)

                        for tk in (team_coord_task, member_trigger_task):
                            if tk and not tk.done():
                                tk.cancel()
                                try:
                                    await tk
                                except asyncio.CancelledError:
                                    pass
                        team_coord_task = None
                        member_trigger_task = None
                        team_active["flag"] = False

                        try:
                            res = json.loads(await decode_protobuf_async(hex_data[10:]))
                            token = udp_key = match_code = server_ip_port = None
                            match_account_id = block_val = None
                            if "42" in res and "data" in res["42"]:
                                match_code = res["42"]["data"]
                            if "5" in res and "data" in res["5"]:
                                r5 = res["5"]["data"]
                                server_ip_port = r5.get("2", {}).get("data")
                                udp_key = r5.get("3", {}).get("data")
                                token = r5.get("4", {}).get("data")
                                if "42" in r5:
                                    match_code = r5["42"]["data"]
                            if "1" in res and "data" in res["1"]:
                                match_account_id = res["1"]["data"]
                            if "5" in res and "data" in res["5"]:
                                block_val = res["5"]["data"].get("1", {}).get("data")

                            effective = match_account_id or account_id or "BD_BOT"

                            if token and udp_key and match_code and server_ip_port:
                                async with _guild_team_state["lock"]:
                                    all_peers = list(_guild_team_state["peers"].keys())
                                if all_peers:
                                    await squad_sync.reset_match(all_peers)

                                try:
                                    async with _guild_team_state["lock"]:
                                        _guild_team_state["pk_code"] = str(match_code)
                                        _guild_team_state["team_code"] = str(match_code)
                                    print_colored(
                                        f"[GUILD] Room Code: {match_code}",
                                        Colors.MAGENTA)
                                    print_colored(
                                        f"[GUILD] Server: {server_ip_port}",
                                        Colors.MAGENTA)
                                except Exception:
                                    pass

                                acc_tok = (current_account_data.get("access_token", "")
                                           if current_account_data else "")
                                mid, mp = BR_MODE_ID, BR_MAP_ID
                                thunder, sharma = await guild_build_match_startup_packets(
                                    token, udp_key, match_code, effective, block_val or 0,
                                    server_ip=server_ip_port, region=account_region,
                                    client_version=client_version,
                                    access_token=acc_tok, mode_id=mid, map_id=mp)
                                match_index = await guild_inc_match(uid_str)
                                total = await guild_get_total_match_count()
                                print_colored(
                                    f"[GUILD] MATCH #{match_index} → {server_ip_port}",
                                    Colors.CYAN)

                                new_match = asyncio.create_task(guild_play_game(
                                    server_ip_port, thunder, sharma, udp_key, match_code,
                                    effective, current_search_region, client_version,
                                    current_key, current_iv,
                                    match_index=match_index,
                                    on_match_complete=trigger_post_match_refresh))
                                play_matches.append(new_match)
                                consecutive_parse_failures = 0

                                async def drain_gateway():
                                    while not new_match.done():
                                        try:
                                            dg = await asyncio.wait_for(
                                                reader.read(4096), timeout=1.0)
                                            if not dg:
                                                break
                                            gh = dg.hex()
                                            if gh.startswith("0600") and len(dg) > 20:
                                                await guild_process_social_packet(
                                                    dg, current_account_data,
                                                    tag="DRAIN")
                                        except asyncio.TimeoutError:
                                            continue
                                        except Exception:
                                            break

                                drain_task = asyncio.create_task(drain_gateway())
                                try:
                                    await new_match
                                except Exception as e:
                                    print_error(f"[GUILD] match #{match_index}: {e}",
                                                bot_type="guild")
                                finally:
                                    drain_task.cancel()
                                    try:
                                        await drain_task
                                    except asyncio.CancelledError:
                                        pass

                                play_matches[:] = [m for m in play_matches
                                                   if not m.done()]

                                async with _guild_team_state["lock"]:
                                    _guild_team_state["peers"].pop(uid_str, None)
                                    if _guild_team_state["leader_uid"] == uid_str:
                                        _guild_team_state["leader_uid"] = None
                                    _guild_team_state["pk_code"] = None
                                await guild_team_member_leave(uid_str)
                                team_active["flag"] = True
                                try:
                                    writer.close()
                                    await writer.wait_closed()
                                except Exception:
                                    pass
                                await asyncio.sleep(GUILD_NEW_MATCH_DELAY)
                                reconnect_count_total += 1
                                break
                            else:
                                consecutive_parse_failures += 1
                                if (consecutive_parse_failures
                                        >= GUILD_MAX_CONSECUTIVE_PARSE_FAILURES):
                                    consecutive_parse_failures = 0
                                try:
                                    writer.close()
                                    await writer.wait_closed()
                                except Exception:
                                    pass
                                await asyncio.sleep(GUILD_NON_MATCH_RECONNECT_DELAY)
                                break
                        except Exception as e:
                            print_error(f"[GUILD] Match parse error: {e}",
                                        uid_str, bot_type="guild")
                            consecutive_parse_failures += 1
                            try:
                                writer.close()
                                await writer.wait_closed()
                            except Exception:
                                pass
                            await asyncio.sleep(GUILD_NON_MATCH_RECONNECT_DELAY)
                            break

                    if 30 <= pl <= 40:
                        continue

            except asyncio.CancelledError:
                for m in play_matches:
                    if not m.done():
                        m.cancel()
                if play_matches:
                    await asyncio.gather(*play_matches, return_exceptions=True)
                play_matches.clear()
                if gateway_ping_task:
                    gateway_ping_task.cancel()
                async with _guild_team_state["lock"]:
                    _guild_team_state["peers"].pop(uid_str, None)
                    if _guild_team_state["leader_uid"] == uid_str:
                        _guild_team_state["leader_uid"] = None
                await guild_team_member_leave(uid_str)
                raise
            except Exception as e:
                if gateway_ping_task:
                    gateway_ping_task.cancel()
                print_error(f"[GUILD] TCP state {uid_str}: {e}",
                            uid_str, bot_type="guild")
                play_matches[:] = [m for m in play_matches if not m.done()]
                if writer:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
                if "Cache expired" in str(e):
                    break
                reconnect_count_total += 1
                reconnects += 1
                if reconnects > max_reconnects:
                    reconnects = 0
                    await asyncio.sleep(3)
                    continue
                await asyncio.sleep(guild_bypass_human_reconnect_delay(reconnects))
            finally:
                team_active["flag"] = False
                for tk in (team_coord_task, member_trigger_task):
                    if tk and not tk.done():
                        tk.cancel()
                        try:
                            await tk
                        except (asyncio.CancelledError, Exception):
                            pass
                if gateway_ping_task:
                    gateway_ping_task.cancel()
                if writer:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except Exception:
                        pass
                async with _guild_team_state["lock"]:
                    _guild_team_state["peers"].pop(uid_str, None)
                    if _guild_team_state["leader_uid"] == uid_str:
                        _guild_team_state["leader_uid"] = None
                await guild_team_member_leave(uid_str)
                team_active["flag"] = True
    except asyncio.CancelledError:
        for m in play_matches:
            if not m.done():
                m.cancel()
        if play_matches:
            await asyncio.gather(*play_matches, return_exceptions=True)
        play_matches.clear()
        raise


async def guild_process_account_uid_pass(uid: str,
                                         password: str) -> Optional[Dict[str, Any]]:
    cached = TokenCache.get(uid, TOKEN_CACHE_TTL_GUILD)
    if cached:
        print_success(f"[GUILD] CACHE HIT {uid}", uid, bot_type="guild")
        acc_id = str(cached["account_id"])
        bot_state.register_account(
            uid=f"guild:{uid}",
            account_id=acc_id,
            nickname=cached.get("nickname", f"Player_{acc_id}"),
            region=cached.get("region", "ID"),
            level=cached.get("level", 1),
            exp=cached.get("exp", 0),
            likes=cached.get("likes", 0),
        )
        cached["login_uid"] = uid
        cached["bot_type"] = "guild"
        register_credentials(cached)
        if cached.get("access_token") and cached.get("region"):
            LevelTokenCache.store_access_token(
                cached["region"], acc_id, cached["access_token"],
                cached.get("nickname", ""))
        return cached

    print_info(f"[GUILD] Full login for UID {uid}...", uid, bot_type="guild")
    try:
        verconfig = await version_config(region="ID")
        if not verconfig:
            return None
        release_version, client_version, server_url = verconfig

        token_grant = await get_access_token(uid, password, region="ID")
        if not token_grant:
            return None
        open_id, access_token, platform = token_grant

        device_info = get_device_for_account(uid, bot_type="guild")

        login_payload = await build_majorlogin_payload(
            open_id, access_token, platform, client_version, device_info,
            bot_type="guild", region="ID")
        if not login_payload:
            return None

        majorlogin = await send_majorlogin(login_payload, release_version, server_url)
        if majorlogin is None:
            return None

        getlogin = await send_getlogin(
            login_payload, majorlogin.url, majorlogin.token, release_version)
        if getlogin is None:
            return None
        res_proto, dict_res = getlogin

        account_data = _build_account_data(
            majorlogin, res_proto, dict_res,
            open_id, access_token, platform,
            release_version, client_version,
            login_payload, auth_type="guest", bot_type="guild",
            auth_uid=uid, auth_password=password, login_uid=uid)

        bot_state.register_account(
            uid=f"guild:{uid}",
            account_id=str(account_data["account_id"]),
            nickname=account_data["nickname"],
            region=account_data["region"],
            level=account_data["level"],
            exp=account_data["exp"],
            likes=account_data["likes"],
        )
        register_credentials(account_data)
        TokenCache.put(uid, account_data, label="guild guest")
        LevelTokenCache.store_access_token(
            account_data.get("region", "ID"),
            str(account_data["account_id"]),
            access_token,
            account_data.get("nickname", ""))

        print_profile_box(
            uid, account_data["nickname"], account_data["level"],
            account_data["exp"], 0, 0, account_data["likes"], "ONLINE",
            bot_type="guild")
        return account_data
    except Exception as e:
        print_error(f"guild_process_account_uid_pass error: {e}",
                    uid, bot_type="guild")
        traceback.print_exc()
        return None


async def guild_process_account_token(access_token: str) -> Optional[Dict[str, Any]]:
    cache_key = f"tok_{access_token[:20]}"
    cached = TokenCache.get(cache_key, TOKEN_CACHE_TTL_GUILD)
    if cached:
        print_success(f"[GUILD] CACHE HIT token {access_token[:10]}...",
                      bot_type="guild")
        acc_id = str(cached["account_id"])
        bot_state.register_account(
            uid=f"guild:{cache_key}",
            account_id=acc_id,
            nickname=cached.get("nickname", f"Player_{acc_id}"),
            region=cached.get("region", "ID"),
            level=cached.get("level", 1),
            exp=cached.get("exp", 0),
            likes=cached.get("likes", 0),
        )
        cached["login_uid"] = cache_key
        cached["bot_type"] = "guild"
        register_credentials(cached)
        if cached.get("access_token") and cached.get("region"):
            LevelTokenCache.store_access_token(
                cached["region"], acc_id, cached["access_token"],
                cached.get("nickname", ""))
        return cached

    print_info("[GUILD] Full login with access token...", bot_type="guild")
    try:
        verconfig = await version_config(region="ID")
        if not verconfig:
            return None
        release_version, client_version, server_url = verconfig

        inspect = await inspect_access_token(access_token)
        if inspect is None:
            return None
        open_id = inspect.get("open_id")
        platform = inspect.get("platform", 4)
        if not open_id:
            return None

        device_info = get_device_for_account(open_id, bot_type="guild")

        login_payload = await build_majorlogin_payload(
            open_id, access_token, str(platform), client_version, device_info,
            bot_type="guild", region="ID")
        if not login_payload:
            return None

        majorlogin = await send_majorlogin(login_payload, release_version, server_url)
        if majorlogin is None:
            return None

        getlogin = await send_getlogin(
            login_payload, majorlogin.url, majorlogin.token, release_version)
        if getlogin is None:
            return None
        res_proto, dict_res = getlogin

        account_data = _build_account_data(
            majorlogin, res_proto, dict_res,
            open_id, access_token, platform,
            release_version, client_version,
            login_payload, auth_type="token", bot_type="guild",
            auth_token=access_token, login_uid=cache_key)

        bot_state.register_account(
            uid=f"guild:{cache_key}",
            account_id=str(account_data["account_id"]),
            nickname=account_data["nickname"],
            region=account_data["region"],
            level=account_data["level"],
            exp=account_data["exp"],
            likes=account_data["likes"],
        )
        register_credentials(account_data)
        TokenCache.put(cache_key, account_data, label="guild token")
        LevelTokenCache.store_access_token(
            account_data.get("region", "ID"),
            str(account_data["account_id"]),
            access_token,
            account_data.get("nickname", ""))

        print_profile_box(
            cache_key, account_data["nickname"], account_data["level"],
            account_data["exp"], 0, 0, account_data["likes"], "ONLINE",
            bot_type="guild")
        return account_data
    except Exception as e:
        print_error(f"guild_process_account_token error: {e}", bot_type="guild")
        return None


async def guild_run_account_worker(account_data: Dict[str, Any], label: str):
    acc_id = str(account_data["account_id"])
    login_uid = str(account_data.get("login_uid") or label)
    info_task = None
    exp_task = None
    ping_task = None
    try:
        reg = account_data.get("region", "ID")
        tcp_online = await guild_build_tcp_startup_packet(
            account_data["account_id"], account_data["token"],
            account_data["server_time"], account_data["aes_ak"],
            account_data["iv_i"], region=reg, typ="OnLine")
        tcp_chat = await guild_build_tcp_startup_packet(
            account_data["account_id"], account_data["token"],
            account_data["server_time"], account_data["aes_ak"],
            account_data["iv_i"], region=reg, typ="ChaT")

        info_task = asyncio.create_task(
            guild_informational(account_data["informational_addrs"], tcp_chat,
                                account_data["aes_ak"], account_data["iv_i"],
                                region=reg))

        if ENABLE_HTTP_PING:
            ping_task = asyncio.create_task(
                guild_ping_worker(acc_id, account_data["token"],
                                  account_data["release_version"], region=reg))
            print_success(f"[PING] Started {acc_id}", acc_id, bot_type="guild")

        async def exp_refresher():
            try:
                f = bot_state.account_credentials.get(f"guild:{login_uid}")
                if f:
                    await refresh_account_profile(f, bot_type="guild")
            except Exception:
                pass
            while True:
                await asyncio.sleep(GUILD_EXP_REFRESH_INTERVAL
                                    + random.uniform(-3.0, 3.0))
                try:
                    f = bot_state.account_credentials.get(f"guild:{login_uid}")
                    if f:
                        await refresh_account_profile(f, bot_type="guild")
                except Exception:
                    pass

        exp_task = asyncio.create_task(exp_refresher())

        await guild_functional_battle_royale(
            account_data["functional_addrs"], tcp_online,
            account_data["region"], account_data["client_version"],
            account_data["aes_ak"], account_data["iv_i"],
            account_id=login_uid, account_data=account_data,
            account_level=int(account_data.get("level", 2) or 2))
    except asyncio.CancelledError:
        raise
    except Exception as e:
        print_error(f"guild_run_account_worker {label}: {e}",
                    login_uid, bot_type="guild")
    finally:
        for t in (info_task, exp_task, ping_task):
            if t and not t.done():
                t.cancel()
        for t in (info_task, exp_task, ping_task):
            if t:
                try:
                    await t
                except Exception:
                    pass
        try:
            desired = bot_state.get_desired_state(f"guild:{login_uid}")
            if desired == "paused":
                bot_state.update_status(f"guild:{login_uid}", "PAUSED", 0,
                                        reason="paused by user")
            elif desired == "stopped":
                bot_state.update_status(f"guild:{login_uid}", "OFFLINE", 0,
                                        reason="stopped by user")
            else:
                bot_state.update_status(f"guild:{login_uid}", "OFFLINE", 0)
        except Exception:
            pass


async def guild_account_loop_guest(uid: str, password: str):
    while True:
        desired = bot_state.get_desired_state(f"guild:{uid}")
        if desired == "stopped":
            print_info(f"[GUILD] UID {uid} stopped, exiting", uid, bot_type="guild")
            break
        try:
            print_info(f"[GUILD] Starting guest login {uid}...", uid, bot_type="guild")
            try:
                bot_state.update_status(f"guild:{uid}", "CONNECTING")
            except Exception:
                pass
            account_data = await guild_process_account_uid_pass(uid, password)
            if not account_data:
                print_error(f"[GUILD] Login failed {uid}, retry in 15s",
                            uid, bot_type="guild")
                try:
                    bot_state.update_status(f"guild:{uid}", "ERROR",
                                            reason="login failed")
                except Exception:
                    pass
                await asyncio.sleep(15)
                continue
            await guild_run_account_worker(account_data, uid)
            print_warning(f"[GUILD] Session ended {uid}, reconnect in 3s",
                          uid, bot_type="guild")
            await asyncio.sleep(3)
        except asyncio.CancelledError:
            desired = bot_state.get_desired_state(f"guild:{uid}")
            if desired == "paused":
                print_warning(f"[GUILD] Worker {uid} paused", uid, bot_type="guild")
                try:
                    bot_state.update_status(f"guild:{uid}", "PAUSED", 0,
                                            reason="paused by user")
                except Exception:
                    pass
            else:
                print_warning(f"[GUILD] Worker {uid} stopped", uid, bot_type="guild")
                try:
                    bot_state.update_status(f"guild:{uid}", "OFFLINE", 0)
                except Exception:
                    pass
            break
        except Exception as e:
            print_error(f"[GUILD] Error {uid}: {e}. Retry in 10s",
                        uid, bot_type="guild")
            await asyncio.sleep(10)


async def guild_account_loop_token(token: str):
    label = token[:10]
    cache_key = f"tok_{token[:20]}"
    while True:
        desired = bot_state.get_desired_state(f"guild:{cache_key}")
        if desired == "stopped":
            print_info(f"[GUILD] Token {label}... stopped, exiting",
                       bot_type="guild")
            break
        try:
            print_info("[GUILD] Starting token login...", bot_type="guild")
            account_data = await guild_process_account_token(token)
            if not account_data:
                print_error("[GUILD] Login failed for token, retry in 15s",
                            bot_type="guild")
                await asyncio.sleep(15)
                continue
            acc_id = str(account_data["account_id"])
            await guild_run_account_worker(account_data, acc_id)
            await asyncio.sleep(3)
        except asyncio.CancelledError:
            desired = bot_state.get_desired_state(f"guild:{cache_key}")
            if desired == "paused":
                print_warning(f"[GUILD] Token {label} paused", bot_type="guild")
                try:
                    bot_state.update_status(f"guild:{cache_key}", "PAUSED", 0,
                                            reason="paused by user")
                except Exception:
                    pass
            else:
                print_warning(f"[GUILD] Token {label} stopped", bot_type="guild")
                try:
                    bot_state.update_status(f"guild:{cache_key}", "OFFLINE", 0)
                except Exception:
                    pass
            break
        except Exception as e:
            print_error(f"[GUILD] Token error: {e}. Retry in 10s",
                        bot_type="guild")
            await asyncio.sleep(10)


def load_accounts() -> List[Dict[str, Any]]:
    accounts: List[Dict[str, Any]] = []
    try:
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("accounts file root must be a JSON list")

        seen_level_uids: set = set()
        seen_level_tokens: set = set()
        seen_guild_uids: set = set()
        seen_guild_tokens: set = set()

        for item in data:
            if not isinstance(item, dict):
                print_warning("Skipping malformed account entry", bot_type="common")
                continue

            bot_type = str(item.get("bot_type", "level")).strip().lower()
            if bot_type not in ("level", "guild"):
                bot_type = "level"

            token_value = item.get("token")
            uid_value = item.get("uid")
            password_value = item.get("password")

            has_token = isinstance(token_value, str) and bool(token_value.strip())
            has_creds = (
                isinstance(uid_value, (str, int))
                and bool(str(uid_value).strip())
                and isinstance(password_value, str)
                and bool(password_value.strip())
            )

            if has_token:
                tok = str(token_value).strip()
                if bot_type == "guild":
                    if tok in seen_guild_tokens:
                        print_warning("Skipping duplicate guild token",
                                      bot_type="common")
                        continue
                    seen_guild_tokens.add(tok)
                    accounts.append({"token": tok, "bot_type": "guild"})
                else:
                    if tok in seen_level_tokens:
                        print_warning("Skipping duplicate level token",
                                      bot_type="common")
                        continue
                    seen_level_tokens.add(tok)
                    accounts.append({"token": tok, "bot_type": "level"})
            elif has_creds:
                uid = str(uid_value).strip()
                pwd = str(password_value).strip()
                if bot_type == "guild":
                    if uid in seen_guild_uids:
                        print_warning(f"Skipping duplicate guild UID {uid}",
                                      bot_type="common")
                        continue
                    seen_guild_uids.add(uid)
                    accounts.append({"uid": uid, "password": pwd, "bot_type": "guild"})
                else:
                    if uid in seen_level_uids:
                        print_warning(f"Skipping duplicate level UID {uid}",
                                      bot_type="common")
                        continue
                    seen_level_uids.add(uid)
                    accounts.append({"uid": uid, "password": pwd, "bot_type": "level"})
            else:
                print_warning("Skipping entry without valid credentials",
                              bot_type="common")
    except FileNotFoundError:
        pass
    except (OSError, json.JSONDecodeError, ValueError) as e:
        print_error(f"Could not load {ACCOUNTS_FILE}: {e}", bot_type="common")

    return accounts


_ACCOUNTS_FILE_MTIME: float = 0.0


def _accounts_file_mtime() -> float:
    try:
        return os.path.getmtime(ACCOUNTS_FILE)
    except Exception:
        return 0.0


async def _accounts_watcher(on_added, on_removed, interval: float = 5.0):
    global _ACCOUNTS_FILE_MTIME
    _ACCOUNTS_FILE_MTIME = _accounts_file_mtime()

    known_level_uids: set = set()
    known_level_tokens: set = set()
    known_guild_uids: set = set()
    known_guild_tokens: set = set()

    initial = load_accounts()
    for acc in initial:
        bt = acc.get("bot_type", "level")
        if acc.get("token"):
            if bt == "guild":
                known_guild_tokens.add(acc["token"])
            else:
                known_level_tokens.add(acc["token"])
        elif acc.get("uid"):
            uid = str(acc["uid"])
            if bt == "guild":
                known_guild_uids.add(uid)
            else:
                known_level_uids.add(uid)

    while True:
        try:
            await asyncio.sleep(interval)
            current_mtime = _accounts_file_mtime()
            if current_mtime == _ACCOUNTS_FILE_MTIME:
                continue
            _ACCOUNTS_FILE_MTIME = current_mtime

            current = load_accounts()
            cur_level_uids = {str(a["uid"]) for a in current
                              if a.get("uid") and a.get("bot_type") == "level"}
            cur_level_tokens = {a["token"] for a in current
                                if a.get("token") and a.get("bot_type") == "level"}
            cur_guild_uids = {str(a["uid"]) for a in current
                              if a.get("uid") and a.get("bot_type") == "guild"}
            cur_guild_tokens = {a["token"] for a in current
                                if a.get("token") and a.get("bot_type") == "guild"}

            for acc in current:
                bt = acc.get("bot_type", "level")
                if acc.get("token"):
                    tok = acc["token"]
                    if bt == "guild":
                        if tok not in known_guild_tokens:
                            known_guild_tokens.add(tok)
                            try:
                                await on_added({"token": tok, "bot_type": "guild"})
                            except Exception as e:
                                print_error(f"Watcher add guild token: {e}",
                                            bot_type="common")
                    else:
                        if tok not in known_level_tokens:
                            known_level_tokens.add(tok)
                            try:
                                await on_added({"token": tok, "bot_type": "level"})
                            except Exception as e:
                                print_error(f"Watcher add level token: {e}",
                                            bot_type="common")
                elif acc.get("uid"):
                    uid = str(acc["uid"])
                    if bt == "guild":
                        if uid not in known_guild_uids:
                            known_guild_uids.add(uid)
                            try:
                                await on_added({"uid": uid,
                                                "password": acc["password"],
                                                "bot_type": "guild"})
                            except Exception as e:
                                print_error(f"Watcher add guild UID: {e}",
                                            bot_type="common")
                    else:
                        if uid not in known_level_uids:
                            known_level_uids.add(uid)
                            try:
                                await on_added({"uid": uid,
                                                "password": acc["password"],
                                                "bot_type": "level"})
                            except Exception as e:
                                print_error(f"Watcher add level UID: {e}",
                                            bot_type="common")

            for uid in list(known_level_uids):
                if uid not in cur_level_uids:
                    known_level_uids.discard(uid)
                    try:
                        await on_removed({"uid": uid, "bot_type": "level"})
                    except Exception:
                        pass
            for tok in list(known_level_tokens):
                if tok not in cur_level_tokens:
                    known_level_tokens.discard(tok)
                    try:
                        await on_removed({"token": tok, "bot_type": "level"})
                    except Exception:
                        pass
            for uid in list(known_guild_uids):
                if uid not in cur_guild_uids:
                    known_guild_uids.discard(uid)
                    try:
                        await on_removed({"uid": uid, "bot_type": "guild"})
                    except Exception:
                        pass
            for tok in list(known_guild_tokens):
                if tok not in cur_guild_tokens:
                    known_guild_tokens.discard(tok)
                    try:
                        await on_removed({"token": tok, "bot_type": "guild"})
                    except Exception:
                        pass

        except asyncio.CancelledError:
            raise
        except Exception as e:
            print_error(f"accounts watcher loop: {e}", bot_type="common")


async def on_account_added_handler(data: Dict[str, Any], restart: bool = False):
    if not isinstance(data, dict):
        print_warning("Invalid account-added payload", bot_type="common")
        return

    bot_type = str(data.get("bot_type", "level")).strip().lower()
    if bot_type not in ("level", "guild"):
        bot_type = "level"

    if data.get("token"):
        token_value = str(data["token"]).strip()
        if not token_value:
            return
        token_key = f"tok_{token_value[:20]}"
        worker_key = f"{bot_type}:{token_key}"
        prev = bot_state.account_workers.get(worker_key)
        if prev and not prev.done():
            if not restart:
                print_warning(f"Worker {worker_key} already running, keeping",
                              bot_type=bot_type)
                return
            bot_state.set_desired_state(worker_key, "stopped")
            prev.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(prev), timeout=2.0)
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                pass
            bot_state.account_workers.pop(worker_key, None)

        bot_state.ensure_placeholder(worker_key, status="INITIALIZING",
                                     status_reason="queued for login")
        bot_state.set_desired_state(worker_key, "running")
        if bot_type == "guild":
            task = asyncio.create_task(
                guild_account_loop_token(token_value),
                name=f"guild-token-{token_key}")
        else:
            task = asyncio.create_task(
                level_account_loop_token(token_value),
                name=f"level-token-{token_key}")
        task.add_done_callback(_log_any_task_exception)
        bot_state.account_workers[worker_key] = task
    elif data.get("uid") and data.get("password"):
        uid = str(data["uid"]).strip()
        password = str(data["password"]).strip()
        if not uid or not password:
            return
        worker_key = f"{bot_type}:{uid}"
        prev = bot_state.account_workers.get(worker_key)
        if prev and not prev.done():
            if not restart:
                print_warning(f"Worker {worker_key} already running, keeping",
                              bot_type=bot_type)
                return
            bot_state.set_desired_state(worker_key, "stopped")
            prev.cancel()
            try:
                await asyncio.wait_for(asyncio.shield(prev), timeout=2.0)
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                pass
            bot_state.account_workers.pop(worker_key, None)

        bot_state.ensure_placeholder(worker_key, status="INITIALIZING",
                                     status_reason="queued for login")
        bot_state.set_desired_state(worker_key, "running")
        if bot_type == "guild":
            task = asyncio.create_task(
                guild_account_loop_guest(uid, password),
                name=f"guild-{uid}")
        else:
            task = asyncio.create_task(
                level_account_loop_guest(uid, password),
                name=f"level-{uid}")
        task.add_done_callback(_log_any_task_exception)
        bot_state.account_workers[worker_key] = task


async def on_account_removed_handler(data: Dict[str, Any]):
    if not isinstance(data, dict):
        return
    bot_type = str(data.get("bot_type", "level")).strip().lower()
    if bot_type not in ("level", "guild"):
        bot_type = "level"

    if data.get("uid"):
        uid = str(data["uid"]).strip()
        worker_key = f"{bot_type}:{uid}"
        task = bot_state.account_workers.pop(worker_key, None)
        if task and not task.done():
            task.cancel()
        bot_state.accounts.pop(worker_key, None)
        bot_state.account_credentials.pop(worker_key, None)
        bot_state.desired_state.pop(worker_key, None)
        if bot_type == "level":
            level_cleanup_match_counters(uid)
        else:
            bot_state.guild_match_counters.pop(uid, None)
    elif data.get("token"):
        token_value = str(data["token"]).strip()
        token_key = f"tok_{token_value[:20]}"
        worker_key = f"{bot_type}:{token_key}"
        task = bot_state.account_workers.pop(worker_key, None)
        if task and not task.done():
            task.cancel()
        bot_state.accounts.pop(worker_key, None)
        bot_state.account_credentials.pop(worker_key, None)
        bot_state.desired_state.pop(worker_key, None)


async def on_refresh_account_handler(uid):
    uid_str = str(uid)
    if uid_str.startswith("level:"):
        await refresh_account_profile(uid_str, bot_type="level")
    elif uid_str.startswith("guild:"):
        await refresh_account_profile(uid_str, bot_type="guild")
    else:
        await refresh_account_profile(uid_str, bot_type="level")
        await refresh_account_profile(uid_str, bot_type="guild")


def _log_any_task_exception(task: asyncio.Task):
    if task.cancelled():
        return
    exc = task.exception()
    if exc is not None:
        try:
            print_error(f"Background task exception: {exc}", bot_type="common")
        except Exception:
            pass


async def _start_accounts_throttled(accounts: List[Dict[str, Any]]) -> None:
    if not accounts:
        return

    level_accounts = [a for a in accounts if a.get("bot_type") == "level"]
    guild_accounts = [a for a in accounts if a.get("bot_type") == "guild"]

    sem = asyncio.Semaphore(max(1, STARTUP_LOGIN_CONCURRENCY))

    async def start_one(account: Dict[str, Any], delay: float):
        await asyncio.sleep(delay)
        async with sem:
            try:
                await on_account_added_handler(account)
            except Exception as e:
                ident = account.get("uid") or account.get("token", "?")[:16]
                print_error(f"Startup login failed for {ident}: {e}",
                            bot_type=account.get("bot_type", "level"))

    tasks: List[asyncio.Task] = []
    for index, acc in enumerate(level_accounts):
        task = asyncio.create_task(start_one(acc, index * STARTUP_LOGIN_DELAY))
        task.add_done_callback(_log_any_task_exception)
        tasks.append(task)

    for index, acc in enumerate(guild_accounts):
        task = asyncio.create_task(start_one(acc, index * STARTUP_LOGIN_DELAY))
        task.add_done_callback(_log_any_task_exception)
        tasks.append(task)

    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


def _load_squads() -> List[Dict[str, Any]]:
    if not os.path.exists(SQUADS_FILE):
        return []
    try:
        with open(SQUADS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [s for s in data if isinstance(s, dict)]
    except Exception:
        pass
    return []


def _save_squads(squads: List[Dict[str, Any]]) -> None:
    try:
        tmp = SQUADS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(squads, f, indent=2, ensure_ascii=False)
        os.replace(tmp, SQUADS_FILE)
    except Exception as e:
        print_warning(f"Squads save failed: {e}", bot_type="guild")


def _assign_squads(guild_accounts: List[Dict[str, Any]]) -> None:
    if not guild_accounts:
        return
    existing = _load_squads()
    assigned_uids = set()
    for sq in existing:
        for member in sq.get("members", []):
            if member:
                assigned_uids.add(str(member))

    pending = []
    for acc in guild_accounts:
        ident = str(acc.get("uid") or f"tok_{acc['token'][:20]}")
        if ident not in assigned_uids:
            pending.append(ident)

    if not pending:
        return

    squads = list(existing)
    if not squads:
        squads.append({"name": "Squad A", "members": []})

    for ident in pending:
        placed = False
        for sq in squads:
            members = sq.get("members", [])
            while len(members) < TEAM_SIZE:
                members.append(None)
            if None in members:
                members[members.index(None)] = ident
                sq["members"] = members
                placed = True
                break
        if not placed:
            squads.append({"name": f"Squad {chr(65 + len(squads))}",
                           "members": [ident]})

    for sq in squads:
        members = sq.get("members", [])
        while len(members) < TEAM_SIZE:
            members.append(None)
        sq["members"] = members

    _save_squads(squads)
    print_success(f"Assigned {len(pending)} guild account(s) to squads",
                  bot_type="guild")


def _print_dual_summary(level_accounts: List[Dict[str, Any]],
                        guild_accounts: List[Dict[str, Any]]) -> None:
    inv = Box("ACCOUNT INVENTORY", C.VIOLET)
    inv.blank()
    inv.item("Level Bot accounts", str(len(level_accounts)))
    inv.item("Guild Bot accounts", str(len(guild_accounts)))
    inv.item("Total", str(len(level_accounts) + len(guild_accounts)))
    inv.item("Database", os.path.basename(ACCOUNTS_FILE))
    inv.item("Startup Concurrency", str(STARTUP_LOGIN_CONCURRENCY))
    inv.item("Startup Stagger", f"{STARTUP_LOGIN_DELAY}s")
    inv.heavy()
    inv.footer()
    inv.print()

    if level_accounts:
        print_info(f"Level Bot · {len(level_accounts)} account(s)",
                   bot_type="level")
        for index, account in enumerate(level_accounts, 1):
            runtime_key = None
            if account.get("uid"):
                runtime_key = f"level:{account['uid']}"
            elif account.get("token"):
                runtime_key = f"level:tok_{account['token'][:20]}"
            runtime = bot_state.accounts.get(runtime_key, {}) if runtime_key else {}
            print_account_box(index, account, runtime)

    if guild_accounts:
        print_info(f"Guild Bot · {len(guild_accounts)} account(s)",
                   bot_type="guild")
        for index, account in enumerate(guild_accounts, 1):
            runtime_key = None
            if account.get("uid"):
                runtime_key = f"guild:{account['uid']}"
            elif account.get("token"):
                runtime_key = f"guild:tok_{account['token'][:20]}"
            runtime = bot_state.accounts.get(runtime_key, {}) if runtime_key else {}
            print_account_box(index, account, runtime)

        squads = _load_squads()
        if squads:
            sq_box = Box("SQUAD LAYOUT", C.BMAGENTA)
            sq_box.blank()
            for sq in squads:
                members = sq.get("members", [])
                filled = [m for m in members if m]
                sq_box.item(sq.get("name", "Squad"),
                            f"{len(filled)}/{TEAM_SIZE} · "
                            f"{', '.join(str(m) for m in filled[:3])}"
                            f"{' …' if len(filled) > 3 else ''}")
            sq_box.heavy()
            sq_box.footer()
            sq_box.print()


# ═══════════════════════════ AUTO-RESTART SUPERVISOR ═══════════════════════════
async def _auto_restart_watchdog(stop_event: asyncio.Event):
    """Fire `stop_event` after AUTO_RESTART_INTERVAL seconds."""
    if not AUTO_RESTART_ENABLED:
        return
    try:
        await asyncio.wait_for(stop_event.wait(), timeout=AUTO_RESTART_INTERVAL)
    except asyncio.TimeoutError:
        print_warning(
            f"[AUTO-RESTART] {int(AUTO_RESTART_INTERVAL)}s elapsed — "
            f"restarting the whole program now",
            bot_type="common")
        stop_event.set()


async def main():
    print_banner()

    try:
        await start_web_dashboard(host=WEB_HOST, port=WEB_PORT)
        print_success(f"Dashboard live at http://{WEB_HOST}:{WEB_PORT}",
                      bot_type="common")
    except Exception as e:
        print_error(f"Could not start web dashboard: {e}", bot_type="common")

    bot_state.refresh_callbacks["on_account_added"] = on_account_added_handler
    bot_state.refresh_callbacks["on_account_removed"] = on_account_removed_handler
    bot_state.refresh_callbacks["on_refresh_account"] = on_refresh_account_handler

    watcher_task = None
    restart_event = asyncio.Event()
    restart_task = None

    try:
        accounts = load_accounts()
        level_accounts = [a for a in accounts if a.get("bot_type") == "level"]
        guild_accounts = [a for a in accounts if a.get("bot_type") == "guild"]

        if guild_accounts:
            _assign_squads(guild_accounts)

        _print_dual_summary(level_accounts, guild_accounts)

        if not accounts:
            print_warning(f"No accounts found in {ACCOUNTS_FILE}. "
                          f"Add accounts from the dashboard.", bot_type="common")

        await _start_accounts_throttled(accounts)

        watcher_task = asyncio.create_task(
            _accounts_watcher(on_account_added_handler, on_account_removed_handler,
                              interval=5.0))
        watcher_task.add_done_callback(_log_any_task_exception)

        if AUTO_RESTART_ENABLED:
            restart_task = asyncio.create_task(_auto_restart_watchdog(restart_event))
            restart_task.add_done_callback(_log_any_task_exception)

        while True:
            await asyncio.sleep(1)
            if restart_event.is_set():
                break

    except asyncio.CancelledError:
        raise
    finally:
        print_warning("[STOP] Shutting down all workers...", bot_type="common")

        if watcher_task and not watcher_task.done():
            watcher_task.cancel()
            try:
                await watcher_task
            except asyncio.CancelledError:
                pass

        if restart_task and not restart_task.done():
            restart_task.cancel()
            try:
                await restart_task
            except asyncio.CancelledError:
                pass

        workers = list({id(t): t for t in bot_state.account_workers.values()}.values())
        for task in workers:
            if not task.done():
                task.cancel()
        if workers:
            await asyncio.gather(*workers, return_exceptions=True)
        bot_state.account_workers.clear()

        try:
            bot_state.flush_all()
        except Exception:
            pass

        try:
            await http_client.aclose()
        except Exception as e:
            print_warning(f"HTTP client cleanup: {e}", bot_type="common")

        print_success("All workers stopped, HTTP client closed.",
                      bot_type="common")


def _exec_self():
    """Replace the current Python process with a fresh one.

    Used by the auto-restart mechanism so the entire program (imports,
    asyncio loop, sockets, workers) is fully re-initialised, not just
    re-entered. Works on Windows and POSIX.
    """
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    try:
        os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception as e:
        print_error(f"execv failed ({e}); falling back to subprocess restart",
                    bot_type="common")
        try:
            import subprocess
            subprocess.Popen([sys.executable] + sys.argv)
            os._exit(0)
        except Exception as e2:
            print_error(f"subprocess restart also failed: {e2}",
                        bot_type="common")
            os._exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
        if AUTO_RESTART_ENABLED:
            print_warning("[AUTO-RESTART] Restarting process now...",
                          bot_type="common")
            _exec_self()
    except KeyboardInterrupt:
        print_warning("\nProgram stopped by user.", bot_type="common")