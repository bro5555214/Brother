from __future__ import annotations

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

try:
    from google.protobuf import runtime_version as _runtime_version
except ImportError:
    _runtime_version = None


try:
    if _runtime_version is not None:
        _runtime_version.ValidateProtobufRuntimeVersion(
            _runtime_version.Domain.PUBLIC,
            4,
            25,
            0,
            "",
            "thunderFF.proto",
        )
except Exception:
    
    pass


_sym_db = _symbol_database.Default()

_SERIALIZED_PROTO = (
    b'\n\x0fthunderFF.proto\"\x87\x0b\n\rMajorLoginReq\x12\x12\n\n'
    b'event_time\x18\x03 \x01(\t\x12\x11\n\tgame_name\x18\x04 \x01(\t\x12'
    b'\x13\n\x0bplatform_id\x18\x05 \x01(\x05\x12\x16\n\x0e\x63lient_version'
    b'\x18\x07 \x01(\t\x12\x17\n\x0fsystem_software\x18\x08 \x01(\t\x12\x17'
    b'\n\x0fsystem_hardware\x18\t \x01(\t\x12\x18\n\x10telecom_operator'
    b'\x18\n \x01(\t\x12\x14\n\x0cnetwork_type\x18\x0b \x01(\t\x12\x14\n'
    b'\x0cscreen_width\x18\x0c \x01(\r\x12\x15\n\rscreen_height\x18\r \x01'
    b'(\r\x12\x12\n\nscreen_dpi\x18\x0e \x01(\t\x12\x19\n\x11processor_'
    b'details\x18\x0f \x01(\t\x12\x0e\n\x06memory\x18\x10 \x01(\r\x12\x14'
    b'\n\x0cgpu_renderer\x18\x11 \x01(\t\x12\x13\n\x0bgpu_version\x18\x12 '
    b'\x01(\t\x12\x18\n\x10unique_device_id\x18\x13 \x01(\t\x12\x11\n\t'
    b'client_ip\x18\x14 \x01(\t\x12\x10\n\x08language\x18\x15 \x01(\t\x12'
    b'\x0f\n\x07open_id\x18\x16 \x01(\t\x12\x14\n\x0copen_id_type\x18\x17 '
    b'\x01(\t\x12\x13\n\x0b\x64\x65vice_type\x18\x18 \x01(\t\x12\x31\n\x10'
    b'memory_available\x18\x19 \x01(\x0b\x32\x17.MajorLoginGameSecurity\x12'
    b'\x14\n\x0c\x61\x63\x63\x65ss_token\x18\x1d \x01(\t\x12\x17\n\x0f'
    b'platform_sdk_id\x18\x1e \x01(\x05\x12\x1a\n\x12network_operator_a\x18'
    b') \x01(\t\x12\x16\n\x0enetwork_type_a\x18* \x01(\t\x12\x1c\n\x14'
    b'client_using_version\x18\x39 \x01(\t\x12\x1e\n\x16\x65xternal_storage_'
    b'total\x18< \x01(\x05\x12\"\n\x1a\x65xternal_storage_available\x18= \x01'
    b'(\x05\x12\x1e\n\x16internal_storage_total\x18> \x01(\x05\x12\"\n\x1a'
    b'internal_storage_available\x18? \x01(\x05\x12#\n\x1bgame_disk_storage_'
    b'available\x18@ \x01(\x05\x12\x1f\n\x17game_disk_storage_total\x18\x41 '
    b'\x01(\x05\x12%\n\x1d\x65xternal_sdcard_avail_storage\x18\x42 \x01(\x05'
    b'\x12%\n\x1d\x65xternal_sdcard_total_storage\x18\x43 \x01(\x05\x12\x10\n'
    b'\x08login_by\x18I \x01(\x05\x12\x14\n\x0clibrary_path\x18J \x01(\t\x12'
    b'\x12\n\nreg_avatar\x18L \x01(\x05\x12\x15\n\rlibrary_token\x18M \x01'
    b'(\t\x12\x14\n\x0c\x63hannel_type\x18N \x01(\x05\x12\x10\n\x08\x63pu_'
    b'type\x18O \x01(\x05\x12\x18\n\x10\x63pu_architecture\x18Q \x01(\t\x12'
    b'\x1b\n\x13\x63lient_version_code\x18S \x01(\t\x12\x14\n\x0cgraphics_api'
    b'\x18V \x01(\t\x12\x1d\n\x15supported_astc_bitset\x18W \x01(\r\x12\x1a'
    b'\n\x12login_open_id_type\x18X \x01(\x05\x12\x18\n\x10\x61nalytics_'
    b'detail\x18Y \x01(\x0c\x12\x14\n\x0cloading_time\x18\\ \x01(\r\x12\x17'
    b'\n\x0frelease_channel\x18] \x01(\t\x12\x12\n\nextra_info\x18^ \x01'
    b'(\t\x12 \n\x18\x61ndroid_engine_init_flag\x18_ \x01(\r\x12\x0f\n\x07'
    b'if_push\x18\x61 \x01(\x05\x12\x0e\n\x06is_vpn\x18\x62 \x01(\x05\x12'
    b'\x1c\n\x14origin_platform_type\x18\x63 \x01(\t\x12\x1d\n\x15primary_'
    b'platform_type\x18\x64 \x01(\t\"?\n\x16MajorLoginGameSecurity\x12\x0f\n'
    b'\x07version\x18\x06 \x01(\x05\x12\x14\n\x0chidden_value\x18\x08 \x01'
    b'(\x04\"\x82\x01\n\rMajorLoginRes\x12\x12\n\naccount_id\x18\x01 \x01'
    b'(\x04\x12\x0e\n\x06region\x18\x02 \x01(\t\x12\r\n\x05token\x18\x08 '
    b'\x01(\t\x12\x0b\n\x03url\x18\n \x01(\t\x12\x13\n\x0bserver_time\x18'
    b'\x15 \x01(\x04\x12\x0e\n\x06\x61\x65s_ak\x18\x16 \x01(\x0c\x12\x0c\n'
    b'\x04iv_i\x18\x17 \x01(\x0c\"Z\n\x0fGetLoginDataRes\x12\x10\n\x08nick'
    b'name\x18\x04 \x01(\t\x12\x18\n\x10\x66unctional_addrs\x18\x0e \x01'
    b'(\t\x12\x1b\n\x13informational_addrs\x18  \x01(\t\"\xe0\x01\n\nStart'
    b'Match\x12!\n\x04main\x18\x02 \x01(\x0b\x32\x13.StartMatch.nested1\x1a'
    b'\xae\x01\n\x07nested1\x12\x30\n\x0bregion_list\x18\x07 \x03(\x0b\x32'
    b'\x1b.StartMatch.nested1.nested2\x12\x33\n\x0e\x63lient_version\x18\x0c'
    b' \x01(\x0b\x32\x1b.StartMatch.nested1.nested3\x1a\x19\n\x07nested2\x12'
    b'\x0e\n\x06region\x18\x03 \x01(\t\x1a!\n\x07nested3\x12\x16\n\x0eremote_'
    b'version\x18\x08 \x01(\tb\x06proto3'
)


try:
    DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(_SERIALIZED_PROTO)
except Exception:
    
    try:
        DESCRIPTOR = _descriptor_pool.Default().FindFileByName("thunderFF.proto")
    except Exception as exc:
        raise ImportError(
            "thunderFF_pb2: could not register 'thunderFF.proto' into the "
            "default descriptor pool and the file is not already present. "
            "This usually means another incompatible module claimed the "
            "same filename."
        ) from exc


_globals = globals()
try:
    _builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
except Exception:
    pass
try:
    _builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "thunderFF_pb2", _globals)
except Exception:
    pass


if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _offsets = {
        "_MAJORLOGINREQ":                        (20,   1435),
        "_MAJORLOGINGAMESECURITY":               (1437, 1500),
        "_MAJORLOGINRES":                        (1503, 1633),
        "_GETLOGINDATARES":                      (1635, 1725),
        "_STARTMATCH":                           (1728, 1952),
        "_STARTMATCH_NESTED1":                   (1778, 1952),
        "_STARTMATCH_NESTED1_NESTED2":           (1892, 1917),
        "_STARTMATCH_NESTED1_NESTED3":           (1919, 1952),
    }
    for _sym, (_start, _end) in _offsets.items():
        try:
            _globals[_sym]._serialized_start = _start
            _globals[_sym]._serialized_end = _end
        except (KeyError, AttributeError):
            pass


for _msg_name in (
    "MajorLoginReq",
    "MajorLoginGameSecurity",
    "MajorLoginRes",
    "GetLoginDataRes",
    "StartMatch",
):
    _cls = _globals.get(_msg_name)
    if _cls is not None:
        try:
            _sym_db.RegisterMessage(_cls)
        except Exception:
            pass


__all__ = [
    "MajorLoginReq",
    "MajorLoginGameSecurity",
    "MajorLoginRes",
    "GetLoginDataRes",
    "StartMatch",
    "DESCRIPTOR",
]


if __name__ == "__main__":
    print("📦 EXONIDE PRO — thunderFF_pb2.py (master)")
    print(f"   Protobuf runtime : {_descriptor.__name__}")
    print(f"   File             : {DESCRIPTOR.name}")
    print(f"   Package          : {DESCRIPTOR.package or '(none)'}")
    print()

    req = MajorLoginReq()
    req.event_time = "2026-01-01 12:00:00"
    req.game_name = "free fire"
    req.platform_id = 1
    req.open_id = "f1359c183329925e1051ee90154464b5"
    req.open_id_type = "4"
    req.access_token = "test_access_token"
    req.client_version = "1.132.10"
    req.client_version_code = "2019121229"
    req.login_open_id_type = 4
    req.supported_astc_bitset = 3071
    req.graphics_api = "OpenGLES2"
    req.telecom_operator = "Telkomsel"
    req.network_type = "CarrierDataNetwork"
    req.open_id_type = "4"
    req.device_type = "Handheld"
    req.system_hardware = "Handheld"
    req.unique_device_id = "Google|test-device-uuid"
    req.client_ip = "182.5.135.225"
    req.language = "en"
    req.memory = 5653
    req.screen_width = 1639
    req.screen_height = 720
    req.screen_dpi = "320"
    req.processor_details = "ARM64 FP ASIMD AES | 2000 | 8"
    req.gpu_renderer = "Mali-G52 MC2"
    req.gpu_version = "OpenGL ES 3.2 v1.r49p1-03bet0"
    raw = req.SerializeToString()
    assert len(raw) > 0
    req2 = MajorLoginReq()
    req2.ParseFromString(raw)
    assert req2.open_id == req.open_id
    assert req2.game_name == req.game_name
    assert req2.client_version == "1.132.10"
    assert req2.login_open_id_type == 4
    assert req2.supported_astc_bitset == 3071
    assert req2.telecom_operator == "Telkomsel"
    assert req2.open_id_type == "4"
    print(f"   ✅ MajorLoginReq          OK ({len(raw)} bytes)")

    sec = MajorLoginGameSecurity()
    sec.version = 1
    sec.hidden_value = 1234567890
    raw = sec.SerializeToString()
    sec2 = MajorLoginGameSecurity()
    sec2.ParseFromString(raw)
    assert sec2.version == 1
    assert sec2.hidden_value == 1234567890
    print(f"   ✅ MajorLoginGameSecurity OK ({len(raw)} bytes)")

    req3 = MajorLoginReq()
    req3.memory_available.version = 1
    req3.memory_available.hidden_value = 999
    raw = req3.SerializeToString()
    req4 = MajorLoginReq()
    req4.ParseFromString(raw)
    assert req4.memory_available.version == 1
    assert req4.memory_available.hidden_value == 999
    print(f"   ✅ nested security field  OK ({len(raw)} bytes)")

    res = MajorLoginRes()
    res.account_id = 16684478389
    res.region = "BD"
    res.token = "eyJhbGciOiJIUzI1NiIs..."
    res.url = "https://clientbp.ppmainecoonghj.com"
    res.server_time = 1792045541
    res.aes_ak = b"\xcc\x4f\xcf\x82"
    res.iv_i = b"\xfd\x77\xbc\x8c"
    raw = res.SerializeToString()
    res2 = MajorLoginRes()
    res2.ParseFromString(raw)
    assert res2.account_id == 16684478389
    assert res2.region == "BD"
    assert res2.token == res.token
    assert res2.url == res.url
    assert res2.server_time == 1792045541
    assert res2.aes_ak == res.aes_ak
    assert res2.iv_i == res.iv_i
    print(f"   ✅ MajorLoginRes          OK ({len(raw)} bytes)")

    gld = GetLoginDataRes()
    gld.nickname = "Test Player"
    gld.functional_addrs = "202.81.106.11:39699"
    gld.informational_addrs = "202.81.106.96:39801"
    raw = gld.SerializeToString()
    gld2 = GetLoginDataRes()
    gld2.ParseFromString(raw)
    assert gld2.nickname == "Test Player"
    assert gld2.functional_addrs == "202.81.106.11:39699"
    assert gld2.informational_addrs == "202.81.106.96:39801"
    print(f"   ✅ GetLoginDataRes        OK ({len(raw)} bytes)")

    sm = StartMatch()
    r1 = sm.main.region_list.add()
    r1.region = "BD"
    r2 = sm.main.region_list.add()
    r2.region = "IND"
    sm.main.client_version.remote_version = "1.132.10"
    raw = sm.SerializeToString()
    sm2 = StartMatch()
    sm2.ParseFromString(raw)
    assert len(sm2.main.region_list) == 2
    assert sm2.main.region_list[0].region == "BD"
    assert sm2.main.region_list[1].region == "IND"
    assert sm2.main.client_version.remote_version == "1.132.10"
    print(f"   ✅ StartMatch             OK ({len(raw)} bytes)")

    for _m in ("MajorLoginReq", "MajorLoginRes", "GetLoginDataRes", "StartMatch"):
        _cls = globals().get(_m)
        assert _cls is not None and hasattr(_cls, "DESCRIPTOR"), _m
        assert _cls.DESCRIPTOR.file.name == "thunderFF.proto"
    print("   ✅ All message classes belong to thunderFF.proto")

    try:
        import RbcFF_pb2
        same = getattr(RbcFF_pb2, "MajorLoginReq", None) is MajorLoginReq
        print(f"   ✅ RbcFF_pb2 alias shares the same MajorLoginReq: {same}")
    except ImportError:
        print("   ℹ RbcFF_pb2 not present — alias check skipped")

    print()
    print("   ✅ All message round-trips passed.")
    print()
    print("   Exported symbols:")
    for _name in __all__:
        _obj = globals().get(_name)
        if _obj is not None and hasattr(_obj, "DESCRIPTOR"):
            print(f"     • {_name}")