from __future__ import annotations

import os
import sys

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_THIS_DIR)
for _p in (_THIS_DIR, _PARENT_DIR):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)


from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

try:
    from google.protobuf import runtime_version as _runtime_version
except ImportError:
    _runtime_version = None


try:
    if _runtime_version is not None:
        _runtime_version.ValidateProtobufRuntimeVersion(
            _runtime_version.Domain.PUBLIC,
            4, 25, 0, "",
            "reqClan.proto",
        )
except Exception:
    pass


_sym_db = _symbol_database.Default()


_SERIALIZED_PROTO = (
    b'\n\rreqClan.proto\"\x1c\n\tMyMessage\x12\x0f\n\x07\x66ield_1\x18\x01 \x01(\x03'
    b'b\x06proto3'
)

try:
    DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(_SERIALIZED_PROTO)
except Exception:
    
    try:
        DESCRIPTOR = _descriptor_pool.Default().FindFileByName("reqClan.proto")
    except Exception as exc:
        raise ImportError(
            "ReqCLan_pb2: cannot register 'reqClan.proto' into the "
            "default descriptor pool and the file is not already "
            "present. Another incompatible module may have claimed "
            "the same filename."
        ) from exc


_globals = globals()
try:
    _builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
except Exception:
    pass
try:
    _builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "ReqCLan_pb2", _globals)
except Exception:
    pass


if not _descriptor._USE_C_DESCRIPTORS:
    try:
        DESCRIPTOR._loaded_options = None
    except Exception:
        pass
    try:
        _globals["_MYMESSAGE"]._serialized_start = 17
        _globals["_MYMESSAGE"]._serialized_end = 45
    except (KeyError, AttributeError):
        pass


_cls = _globals.get("MyMessage")
if _cls is not None:
    try:
        _sym_db.RegisterMessage(_cls)
    except Exception:
        pass


_self = sys.modules.get(__name__)
if _self is not None:
    sys.modules.setdefault("ReqCLan_pb2", _self)
    sys.modules.setdefault("reqClan_pb2", _self)


__all__ = ["MyMessage", "DESCRIPTOR"]


if __name__ == "__main__":
    print("📦 EXONIDE PRO — ReqCLan_pb2.py")
    print(f"   Protobuf runtime : {_descriptor.__name__}")
    print(f"   DESCRIPTOR       : {DESCRIPTOR.name}")
    print()

    m = MyMessage()
    m.field_1 = 1234567890
    raw = m.SerializeToString()
    assert len(raw) > 0
    m2 = MyMessage()
    m2.ParseFromString(raw)
    assert m2.field_1 == 1234567890
    print(f"   ✅ MyMessage         OK ({len(raw)} bytes)")

    m3 = MyMessage()
    m3.field_1 = -42
    raw = m3.SerializeToString()
    m4 = MyMessage()
    m4.ParseFromString(raw)
    assert m4.field_1 == -42
    print(f"   ✅ MyMessage int64   OK (negative, {len(raw)} bytes)")

    for _val in (0, 1, -1, 2**31 - 1, -2**31, 2**63 - 1, -2**63):
        _m = MyMessage()
        _m.field_1 = _val
        _b = _m.SerializeToString()
        _m2 = MyMessage()
        _m2.ParseFromString(_b)
        assert _m2.field_1 == _val, f"round-trip failed for {_val}"
    print("   ✅ int64 boundaries  OK (0, ±1, ±2^31, ±2^63)")

    fd = MyMessage.DESCRIPTOR.fields_by_name.get("field_1")
    assert fd is not None
    assert fd.number == 1
    assert fd.type == _descriptor.FieldDescriptor.TYPE_INT64
    print(f"   ✅ field_1 metadata  OK (number={fd.number}, type=int64)")

    try:
        import pb2 as _pb2_pkg
        if getattr(_pb2_pkg, "ReqCLan_pb2", None) is sys.modules.get(__name__):
            print("   ✅ pb2 package re-exports this module")
        else:
            print("   ℹ pb2 package did not re-export — optional module")
    except ImportError:
        print("   ℹ pb2 package not importable — standalone run")

    print()
    print("   ✅ All self-tests passed.")