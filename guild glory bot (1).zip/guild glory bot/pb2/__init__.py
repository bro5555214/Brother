from __future__ import annotations

import importlib
import os
import sys
from types import ModuleType
from typing import Dict, List, Optional


_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

_PARENT_DIR = os.path.dirname(_THIS_DIR)
if _PARENT_DIR not in sys.path:
    sys.path.insert(0, _PARENT_DIR)


_CANONICAL_CANDIDATES = (
    "thunderFF_pb2",
    "RbcFF_pb2",
    "RbcTeam_pb2",
    "CguFF_pb2",
    "StartMatch_pb2",
)

_OPTIONAL_MODULES = (
    "ReqCLan_pb2",
    "data_pb2",
    "uid_generator_pb2",
    "GetWishListItems_pb2",
)


_loaded: Dict[str, ModuleType] = {}
_missing: List[str] = []
_aliased: Dict[str, str] = {}
_canonical: Optional[ModuleType] = None
_canonical_name: Optional[str] = None


def _try_import(name: str) -> Optional[ModuleType]:
    
    existing = sys.modules.get(name)
    if existing is not None and isinstance(existing, ModuleType):
        return existing
    try:
        return importlib.import_module(name)
    except Exception:
        return None


for _name in _CANONICAL_CANDIDATES:
    _mod = _try_import(_name)
    if _mod is not None:
        _canonical = _mod
        _canonical_name = _name
        _loaded[_name] = _mod
        break


if _canonical is not None:
    for _alias in _CANONICAL_CANDIDATES:
        if _alias in _loaded:
            continue
        
        try:
            sys.modules.setdefault(_alias, _canonical)
            globals()[_alias] = _canonical
            _loaded[_alias] = _canonical
            _aliased[_alias] = _canonical_name or _alias
        except Exception:
            pass
else:
    for _name in _CANONICAL_CANDIDATES:
        _missing.append(_name)


for _name in _OPTIONAL_MODULES:
    _mod = _try_import(_name)
    if _mod is not None:
        _loaded[_name] = _mod
        globals()[_name] = _mod
    else:
        _missing.append(_name)


thunderFF_pb2       = _loaded.get("thunderFF_pb2")
RbcFF_pb2           = _loaded.get("RbcFF_pb2")
RbcTeam_pb2         = _loaded.get("RbcTeam_pb2")
CguFF_pb2           = _loaded.get("CguFF_pb2")
StartMatch_pb2      = _loaded.get("StartMatch_pb2")
ReqCLan_pb2         = _loaded.get("ReqCLan_pb2")
data_pb2            = _loaded.get("data_pb2")
uid_generator_pb2   = _loaded.get("uid_generator_pb2")
GetWishListItems_pb2 = _loaded.get("GetWishListItems_pb2")


def canonical_module() -> Optional[ModuleType]:
    return _canonical


def canonical_name() -> Optional[str]:
    return _canonical_name


def loaded_modules() -> List[str]:
    return sorted(_loaded.keys())


def missing_modules() -> List[str]:
    return sorted(set(_missing))


def aliased_modules() -> Dict[str, str]:
    return dict(_aliased)


def diagnose() -> str:
    lines = [
        "── pb2 package diagnostics ─────────────────────────────",
        f"  directory  : {_THIS_DIR}",
        f"  parent     : {_PARENT_DIR}",
        f"  canonical  : {_canonical_name or '(none)'}",
        f"  loaded     : {', '.join(loaded_modules()) or '(none)'}",
        f"  aliased    : "
        + (", ".join(f"{a}→{r}" for a, r in _aliased.items()) or "(none)"),
        f"  missing    : {', '.join(missing_modules()) or '(none)'}",
        "────────────────────────────────────────────────────────",
    ]
    return "\n".join(lines)


__all__ = [
    
    "thunderFF_pb2",
    "RbcFF_pb2",
    "RbcTeam_pb2",
    "CguFF_pb2",
    "StartMatch_pb2",
    "ReqCLan_pb2",
    "data_pb2",
    "uid_generator_pb2",
    "GetWishListItems_pb2",
    "canonical_module",
    "canonical_name",
    "loaded_modules",
    "missing_modules",
    "aliased_modules",
    "diagnose",
]


# ── CLI self-test ─────────────────────────────────────────────────
if __name__ == "__main__":
    print(diagnose())

    # Sanity check: if a canonical module was found, the fallback
    # chain used by app.py must resolve to the same object.
    if _canonical is not None:
        for _name in _CANONICAL_CANDIDATES:
            _mod = sys.modules.get(_name)
            assert _mod is _canonical, (
                f"alias mismatch for {_name}: "
                f"expected {_canonical!r}, got {_mod!r}"
            )
        print(f"  ✅ canonical alias chain OK ({_canonical_name})")
    else:
        print("  ⚠  no canonical protobuf module found — "
              "place thunderFF_pb2.py (or RbcFF_pb2.py / RbcTeam_pb2.py / "
              "CguFF_pb2.py / StartMatch_pb2.py) in this folder.")