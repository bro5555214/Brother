from __future__ import annotations

import os
import sys
from types import ModuleType
from typing import Optional


_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_THIS_DIR)
for _p in (_THIS_DIR, _PARENT_DIR):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)


from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

try:
    from google.protobuf import runtime_version as _runtime_version
except ImportError:
    _runtime_version = None


try:
    if _runtime_version is not None:
        _runtime_version.ValidateProtobufRuntimeVersion(
            _runtime_version.Domain.PUBLIC,
            4, 25, 0, "",
            "thunderFF.proto",
        )
except Exception:
    pass


_canonical: Optional[ModuleType] = None
_canonical_source: str = ""

for _name in ("thunderFF_pb2", "RbcFF_pb2"):
    try:
        _m = __import__(_name)
        if hasattr(_m, "MajorLoginRes") and hasattr(_m, "DESCRIPTOR"):
            _canonical = _m
            _canonical_source = _name
            break
    except Exception:
        continue


if _canonical is None:
    for _name in ("CguFF_pb2", "StartMatch_pb2"):
        _m = sys.modules.get(_name)
        if isinstance(_m, ModuleType) and hasattr(_m, "MajorLoginRes"):
            _canonical = _m
            _canonical_source = f"sys.modules[{_name!r}]"
            break


if _canonical is None:
    _SERIALIZED_PROTO = (
        b'\n\x0fthunderFF.proto\"\x87\x0b\n\rMajorLoginReq\x12\x12\n\n'
        b'event_time\x18\x03 \x01(\t\x12\x11\n\tgame_name\x18\x04 \x01(\t\x12'
        b'\x13\n\x0bplatform_id\x18\x05 \x01(\x05\x12\x16\n\x0e\x63lient_version'
        b'\x18\x07 \x01(\t\x12\x17\n\x0fsystem_software\x18\x08 \x01(\t\x12\x17'
        b'\n\x0fsystem_hardware\x18\t \x01(\t\x12\x18\n\x10telecom_operator'
        b'\x18\n \x01(\t\x12\x14\n\x0cnetwork_type\x18\x0b \x01(\t\x12\x14\n'
        b'\x0cscreen_width\x18\x0c \x01(\r\x12\x15\n\rscreen_height\x18\r \x01'
        b'(\r\x12\x12\n\nscreen_dpi\x18\x0e \x01(\t\x12\x19\n\x11processor_'
        b'details\x18\x0f \x01(\t\x12\x0e\n\x06memory\x18\x10 \x01(\r\x12\x14'
        b'\n\x0cgpu_renderer\x18\x11 \x01(\t\x12\x13\n\x0bgpu_version\x18\x12 '
        b'\x01(\t\x12\x18\n\x10unique_device_id\x18\x13 \x01(\t\x12\x11\n\t'
        b'client_ip\x18\x14 \x01(\t\x12\x10\n\x08language\x18\x15 \x01(\t\x12'
        b'\x0f\n\x07open_id\x18\x16 \x01(\t\x12\x14\n\x0copen_id_type\x18\x17 '
        b'\x01(\t\x12\x13\n\x0b\x64\x65vice_type\x18\x18 \x01(\t\x12\x31\n\x10'
        b'memory_available\x18\x19 \x01(\x0b\x32\x17.MajorLoginGameSecurity\x12'
        b'\x14\n\x0c\x61\x63\x63\x65ss_token\x18\x1d \x01(\t\x12\x17\n\x0f'
        b'platform_sdk_id\x18\x1e \x01(\x05\x12\x1a\n\x12network_operator_a\x18'
        b') \x01(\t\x12\x16\n\x0enetwork_type_a\x18* \x01(\t\x12\x1c\n\x14'
        b'client_using_version\x18\x39 \x01(\t\x12\x1e\n\x16\x65xternal_storage_'
        b'total\x18< \x01(\x05\x12\"\n\x1a\x65xternal_storage_available\x18= \x01'
        b'(\x05\x12\x1e\n\x16internal_storage_total\x18> \x01(\x05\x12\"\n\x1a'
        b'internal_storage_available\x18? \x01(\x05\x12#\n\x1bgame_disk_storage_'
        b'available\x18@ \x01(\x05\x12\x1f\n\x17game_disk_storage_total\x18\x41 '
        b'\x01(\x05\x12%\n\x1d\x65xternal_sdcard_avail_storage\x18\x42 \x01(\x05'
        b'\x12%\n\x1d\x65xternal_sdcard_total_storage\x18\x43 \x01(\x05\x12\x10\n'
        b'\x08login_by\x18I \x01(\x05\x12\x14\n\x0clibrary_path\x18J \x01(\t\x12'
        b'\x12\n\nreg_avatar\x18L \x01(\x05\x12\x15\n\rlibrary_token\x18M \x01'
        b'(\t\x12\x14\n\x0c\x63hannel_type\x18N \x01(\x05\x12\x10\n\x08\x63pu_'
        b'type\x18O \x01(\x05\x12\x18\n\x10\x63pu_architecture\x18Q \x01(\t\x12'
        b'\x1b\n\x13\x63lient_version_code\x18S \x01(\t\x12\x14\n\x0cgraphics_api'
        b'\x18V \x01(\t\x12\x1d\n\x15supported_astc_bitset\x18W \x01(\r\x12\x1a'
        b'\n\x12login_open_id_type\x18X \x01(\x05\x12\x18\n\x10\x61nalytics_'
        b'detail\x18Y \x01(\x0c\x12\x14\n\x0cloading_time\x18\\ \x01(\r\x12\x17'
        b'\n\x0frelease_channel\x18] \x01(\t\x12\x12\n\nextra_info\x18^ \x01'
        b'(\t\x12 \n\x18\x61ndroid_engine_init_flag\x18_ \x01(\r\x12\x0f\n\x07'
        b'if_push\x18\x61 \x01(\x05\x12\x0e\n\x06is_vpn\x18\x62 \x01(\x05\x12'
        b'\x1c\n\x14origin_platform_type\x18\x63 \x01(\t\x12\x1d\n\x15primary_'
        b'platform_type\x18\x64 \x01(\t\"?\n\x16MajorLoginGameSecurity\x12\x0f\n'
        b'\x07version\x18\x06 \x01(\x05\x12\x14\n\x0chidden_value\x18\x08 \x01'
        b'(\x04\"\x82\x01\n\rMajorLoginRes\x12\x12\n\naccount_id\x18\x01 \x01'
        b'(\x04\x12\x0e\n\x06region\x18\x02 \x01(\t\x12\r\n\x05token\x18\x08 '
        b'\x01(\t\x12\x0b\n\x03url\x18\n \x01(\t\x12\x13\n\x0bserver_time\x18'
        b'\x15 \x01(\x04\x12\x0e\n\x06\x61\x65s_ak\x18\x16 \x01(\x0c\x12\x0c\n'
        b'\x04iv_i\x18\x17 \x01(\x0c\"Z\n\x0fGetLoginDataRes\x12\x10\n\x08nick'
        b'name\x18\x04 \x01(\t\x12\x18\n\x10\x66unctional_addrs\x18\x0e \x01'
        b'(\t\x12\x1b\n\x13informational_addrs\x18  \x01(\t\"\xe0\x01\n\nStart'
        b'Match\x12!\n\x04main\x18\x02 \x01(\x0b\x32\x13.StartMatch.nested1\x1a'
        b'\xae\x01\n\x07nested1\x12\x30\n\x0bregion_list\x18\x07 \x03(\x0b\x32'
        b'\x1b.StartMatch.nested1.nested2\x12\x33\n\x0e\x63lient_version\x18\x0c'
        b' \x01(\x0b\x32\x1b.StartMatch.nested1.nested3\x1a\x19\n\x07nested2\x12'
        b'\x0e\n\x06region\x18\x03 \x01(\t\x1a!\n\x07nested3\x12\x16\n\x0eremote_'
        b'version\x18\x08 \x01(\tb\x06proto3'
    )

    try:
        DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(_SERIALIZED_PROTO)
    except Exception:
        try:
            DESCRIPTOR = _descriptor_pool.Default().FindFileByName("thunderFF.proto")
        except Exception as exc:
            raise ImportError(
                "RbcTeam_pb2: cannot register 'thunderFF.proto' into the "
                "default descriptor pool, and no sibling module could be "
                "loaded as a fallback. Ensure the protobuf runtime is "
                "intact."
            ) from exc

    _g = globals()
    try:
        _builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _g)
    except Exception:
        pass
    try:
        _builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "RbcTeam_pb2", _g)
    except Exception:
        pass

    if not _descriptor._USE_C_DESCRIPTORS:
        try:
            DESCRIPTOR._loaded_options = None
        except Exception:
            pass
        _off = {
            "_MAJORLOGINREQ":              (20,   1435),
            "_MAJORLOGINGAMESECURITY":     (1437, 1500),
            "_MAJORLOGINRES":              (1503, 1633),
            "_GETLOGINDATARES":            (1635, 1725),
            "_STARTMATCH":                 (1728, 1952),
            "_STARTMATCH_NESTED1":         (1778, 1952),
            "_STARTMATCH_NESTED1_NESTED2": (1892, 1917),
            "_STARTMATCH_NESTED1_NESTED3": (1919, 1952),
        }
        for _sym, (_a, _b) in _off.items():
            try:
                _g[_sym]._serialized_start = _a
                _g[_sym]._serialized_end = _b
            except (KeyError, AttributeError):
                pass

    _sym_db = _symbol_database.Default()
    for _name in ("MajorLoginReq", "MajorLoginGameSecurity",
                  "MajorLoginRes", "GetLoginDataRes", "StartMatch"):
        _cls = _g.get(_name)
        if _cls is not None:
            try:
                _sym_db.RegisterMessage(_cls)
            except Exception:
                pass


if _canonical is not None:
    DESCRIPTOR               = _canonical.DESCRIPTOR
    MajorLoginReq            = _canonical.MajorLoginReq
    MajorLoginGameSecurity   = _canonical.MajorLoginGameSecurity
    MajorLoginRes            = _canonical.MajorLoginRes
    GetLoginDataRes          = _canonical.GetLoginDataRes
    StartMatch               = _canonical.StartMatch


_MISSING: list[str] = []
for _name in ("MajorLoginReq", "MajorLoginGameSecurity", "MajorLoginRes",
              "GetLoginDataRes", "StartMatch", "DESCRIPTOR"):
    if _name not in globals():
        _MISSING.append(_name)
if _MISSING:
    raise ImportError(
        f"RbcTeam_pb2: required symbol(s) {', '.join(_MISSING)} could not "
        f"be resolved (canonical source: {_canonical_source or 'embedded'})"
    )


_self = sys.modules.get(__name__)
_ALIAS_NAMES = (
    "RbcTeam_pb2", "RbcFF_pb2", "CguFF_pb2", "StartMatch_pb2",
)
if _self is not None:
    for _alias in _ALIAS_NAMES:
        sys.modules.setdefault(_alias, _self)


def canonical_source() -> str:
    return _canonical_source or "embedded"


def is_aliased() -> bool:
    return _canonical is not None


__all__ = [
    "MajorLoginReq",
    "MajorLoginGameSecurity",
    "MajorLoginRes",
    "GetLoginDataRes",
    "StartMatch",
    "DESCRIPTOR",
    "canonical_source",
    "is_aliased",
]


if __name__ == "__main__":
    print("📦 EXONIDE PRO — RbcTeam_pb2.py (final-tier fallback bundle)")
    print()
    print(f"   DESCRIPTOR name   : {DESCRIPTOR.name}")
    print(f"   Class source      : {canonical_source()}")
    print(f"   Aliased           : {is_aliased()}")
    print(f"   Messages exported : "
          f"{len([n for n in __all__ if hasattr(globals().get(n, None), 'DESCRIPTOR')])}")
    print()

    req = MajorLoginReq()
    req.event_time = "2026-01-01 12:00:00"
    req.game_name = "free fire"
    req.open_id = "test_open_id"
    req.access_token = "test_token"
    req.client_version = "1.132.10"
    req.login_open_id_type = 4
    raw = req.SerializeToString()
    assert len(raw) > 0
    req2 = MajorLoginReq()
    req2.ParseFromString(raw)
    assert req2.open_id == req.open_id
    assert req2.client_version == "1.132.10"
    assert req2.login_open_id_type == 4
    print(f"   ✅ MajorLoginReq   OK ({len(raw)} bytes)")

    req3 = MajorLoginReq()
    req3.memory_available.version = 1
    req3.memory_available.hidden_value = 999
    raw = req3.SerializeToString()
    req4 = MajorLoginReq()
    req4.ParseFromString(raw)
    assert req4.memory_available.hidden_value == 999
    print(f"   ✅ nested security OK ({len(raw)} bytes)")

    res = MajorLoginRes()
    res.account_id = 16684478389
    res.region = "ID"
    res.token = "eyJ..."
    res.url = "https://clientbp.ggpolarbear.com"
    res.server_time = 1792045541
    res.aes_ak = b"\xcc\x4f\xcf\x82"
    res.iv_i = b"\xfd\x77\xbc\x8c"
    raw = res.SerializeToString()
    res2 = MajorLoginRes()
    res2.ParseFromString(raw)
    assert res2.account_id == 16684478389
    assert res2.region == "ID"
    assert res2.url == res.url
    assert res2.aes_ak == res.aes_ak
    print(f"   ✅ MajorLoginRes   OK ({len(raw)} bytes)")

    gld = GetLoginDataRes()
    gld.nickname = "Test Player"
    gld.functional_addrs = "202.81.106.11:39699"
    gld.informational_addrs = "202.81.106.96:39801"
    raw = gld.SerializeToString()
    gld2 = GetLoginDataRes()
    gld2.ParseFromString(raw)
    assert gld2.nickname == "Test Player"
    assert gld2.functional_addrs == gld.functional_addrs
    print(f"   ✅ GetLoginDataRes OK ({len(raw)} bytes)")

    sm = StartMatch()
    r1 = sm.main.region_list.add()
    r1.region = "ID"
    r2 = sm.main.region_list.add()
    r2.region = "SG"
    sm.main.client_version.remote_version = "1.132.10"
    raw = sm.SerializeToString()
    sm2 = StartMatch()
    sm2.ParseFromString(raw)
    assert len(sm2.main.region_list) == 2
    assert sm2.main.region_list[0].region == "ID"
    assert sm2.main.region_list[1].region == "SG"
    assert sm2.main.client_version.remote_version == "1.132.10"
    print(f"   ✅ StartMatch      OK ({len(raw)} bytes)")

    for _alias in ("RbcFF_pb2", "CguFF_pb2", "StartMatch_pb2"):
        try:
            _a = __import__(_alias)
            if getattr(_a, "MajorLoginRes", None) is MajorLoginRes:
                print(f"   ✅ Shares identity with {_alias}")
            else:
                print(f"   ⚠  {_alias} loaded but holds a different class")
        except ImportError:
            print(f"   ℹ {_alias} not importable — skipped")

    print()
    print("   ✅ All self-tests passed.")