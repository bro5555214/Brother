from __future__ import annotations

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

try:
    from google.protobuf import runtime_version as _runtime_version
except ImportError:
    _runtime_version = None


try:
    if _runtime_version is not None:
        _runtime_version.ValidateProtobufRuntimeVersion(
            _runtime_version.Domain.PUBLIC,
            6,
            33,
            1,
            "",
            "data.proto",
        )
except Exception:
    pass


def _pick_pool():
    pool = getattr(_descriptor_pool, "DescriptorPool", None)
    if pool is not None:
        try:
            return _descriptor_pool.DescriptorPool()
        except Exception:
            pass
    return _descriptor_pool.Default()


_pool = _pick_pool()


_SERIALIZED_PROTO = (
    b'\n\ndata.proto\x12\x05proto\"\x9f\x07\n\x08response\x12\n\n\x02id\x18\x01 \x01(\r'
    b'\x12\x14\n\x0cspecial_code\x18\x02 \x01(\t\x12\x12\n\ntimestamp1\x18\x03 \x01'
    b'(\r\x12\x0f\n\x07value_a\x18\x04 \x01(\r\x12\x13\n\x0bstatus_code\x18\x05 \x01'
    b'(\r\x12\x10\n\x08sub_type\x18\x06 \x01(\r\x12\x0f\n\x07version\x18\x07 \x01'
    b'(\r\x12\r\n\x05level\x18\x08 \x01(\r\x12\r\n\x05\x66lags\x18\t \x01(\r\x12'
    b'\x17\n\x0fwelcome_message\x18\x0c \x01(\t\x12\x0e\n\x06region\x18\r \x01'
    b'(\t\x12\x15\n\rjson_metadata\x18\x0e \x01(\t\x12\x13\n\x0b\x62ig_numbers'
    b'\x18\x0f \x01(\t\x12\x0f\n\x07\x62\x61lance\x18\x14 \x01(\r\x12\r\n\x05'
    b'score\x18\x16 \x01(\r\x12\x10\n\x08upgrades\x18! \x01(\r\x12\x14\n\x0c'
    b'\x61\x63hievements\x18# \x01(\r\x12\x16\n\x0etotal_playtime\x18$ \x01(\r'
    b'\x12\x0e\n\x06\x65nergy\x18% \x01(\r\x12\x0c\n\x04rank\x18& \x01(\r\x12\n'
    b'\n\x02xp\x18\' \x01(\r\x12\x12\n\ntimestamp2\x18( \x01(\r\x12\x12\n\n'
    b'error_code\x18) \x01(\r\x12\x13\n\x0blast_active\x18, \x01(\r\x12\x30\n\r'
    b'guild_details\x18/ \x01(\x0b\x32\x19.proto.response.GuildInfo\x12\x13\n\x0b'
    b'\x65mpty_field\x18\x31 \x01(\t\x1a\xfc\x01\n\tGuildInfo\x12\x0f\n\x07'
    b'\x63lan_id\x18\x01 \x01(\r\x12\x0c\n\x04name\x18\x02 \x01(\t\x12\r\n\x05'
    b'level\x18\x03 \x01(\r\x12\x16\n\x0emembers_online\x18\x04 \x01(\r\x12'
    b'\x15\n\rtotal_members\x18\x05 \x01(\r\x12\x0e\n\x06region\x18\x06 \x01'
    b'(\t\x12\x12\n\nleader_uid\x18\x07 \x01(\r\x12\x0e\n\x06notice\x18\x08 \x01'
    b'(\t\x12\x30\n\x0bmember_list\x18\n \x03(\x0b\x32\x1b.proto.response.'
    b'GuildMember\x12,\n\x07members\x18\x0b \x03(\x0b\x32\x1b.proto.response.'
    b'GuildMember\x1a\x93\x01\n\x0bGuildMember\x12\x0b\n\x03uid\x18\x01 \x01'
    b'(\x04\x12\x10\n\x08nickname\x18\x02 \x01(\t\x12\r\n\x05level\x18\x03 \x01'
    b'(\r\x12\x0c\n\x04role\x18\x04 \x01(\r\x12\r\n\x05score\x18\x05 \x01(\r'
    b'\x12\x13\n\x0blast_active\x18\x06 \x01(\r\x12\x11\n\tavatar_id\x18\x07 '
    b'\x01(\r\x12\x11\n\tbanner_id\x18\x08 \x01(\rb\x06proto3'
)


try:
    DESCRIPTOR = _pool.AddSerializedFile(_SERIALIZED_PROTO)
except Exception:
    
    try:
        DESCRIPTOR = _pool.FindFileByName("data.proto")
    except Exception as exc:
        raise ImportError(
            "data_pb2: 'data.proto' already registered in this pool, "
            "but our message 'proto.response' is not present. Another "
            "module owns this filename. Import data_pb2 in a fresh "
            "descriptor pool or rename its file."
        ) from exc


_sym_db = _symbol_database.Default()
_globals = globals()
try:
    _builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
except Exception:
    pass
try:
    _builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "data_pb2", _globals)
except Exception:
    pass


if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    try:
        _globals["_RESPONSE"]._serialized_start = 22
        _globals["_RESPONSE"]._serialized_end = 949
        _globals["_RESPONSE_GUILDINFO"]._serialized_start = 547
        _globals["_RESPONSE_GUILDINFO"]._serialized_end = 799
        _globals["_RESPONSE_GUILDMEMBER"]._serialized_start = 802
        _globals["_RESPONSE_GUILDMEMBER"]._serialized_end = 949
    except KeyError:
        pass


try:
    _sym_db.RegisterMessage(_globals["response"])
except Exception:
    pass


__all__ = ["response"]


if __name__ == "__main__":
    print("📦 EXONIDE PRO — data_pb2.py")
    print(f"   Protobuf runtime : {_descriptor.__name__}")
    print(f"   Pool             : {type(_pool).__name__}")
    print()

    r = response()
    r.id = 42
    r.level = 15
    r.region = "ID"
    r.xp = 1200
    r.guild_details.clan_id = 777
    r.guild_details.name = "TestGuild"
    r.guild_details.level = 5
    r.guild_details.members_online = 12
    r.guild_details.total_members = 40
    r.guild_details.region = "ID"
    r.guild_details.leader_uid = 16684478389
    member = r.guild_details.member_list.add()
    member.uid = 5895165687
    member.nickname = "TestMember"
    member.level = 24
    member.role = 1
    member.score = 500
    raw = r.SerializeToString()
    assert len(raw) > 0

    r2 = response()
    r2.ParseFromString(raw)
    assert r2.id == 42
    assert r2.region == "ID"
    assert r2.guild_details.name == "TestGuild"
    assert r2.guild_details.leader_uid == 16684478389
    assert len(r2.guild_details.member_list) == 1
    assert r2.guild_details.member_list[0].nickname == "TestMember"
    assert r2.guild_details.member_list[0].level == 24
    print(f"   ✅ response round-trip OK ({len(raw)} bytes)")

    try:
        from guild_info import AccountPersonalShowInfo
        print("   ✅ guild_info.AccountPersonalShowInfo importable — "
              "no descriptor collision")
    except ImportError:
        print("   ℹ guild_info not present in this environment (skipped)")

    print()
    print("   ✅ All self-tests passed.")