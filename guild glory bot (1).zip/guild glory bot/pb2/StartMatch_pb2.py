from __future__ import annotations

import os
import sys

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_THIS_DIR)
for _p in (_THIS_DIR, _PARENT_DIR):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)


from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

try:
    from google.protobuf import runtime_version as _runtime_version
except ImportError:
    _runtime_version = None


try:
    if _runtime_version is not None:
        _runtime_version.ValidateProtobufRuntimeVersion(
            _runtime_version.Domain.PUBLIC,
            6, 33, 1, "",
            "StartMatch.proto",
        )
except Exception:
    pass


_sym_db = _symbol_database.Default()


_SERIALIZED_PROTO = (
    b'\n\x10StartMatch.proto\"\xec\x01\n\rStartUDPMatch\x12$\n\x04main\x18\x02 \x01'
    b'(\x0b\x32\x16.StartUDPMatch.nested1\x1a\xb4\x01\n\x07nested1\x12\x33\n\x0b'
    b'region_list\x18\x07 \x03(\x0b\x32\x1e.StartUDPMatch.nested1.nested2\x12'
    b'\x36\n\x0e\x63lient_version\x18\x0c \x01(\x0b\x32\x1e.StartUDPMatch.'
    b'nested1.nested3\x1a\x19\n\x07nested2\x12\x0e\n\x06region\x18\x03 \x01'
    b'(\t\x1a!\n\x07nested3\x12\x16\n\x0eremote_version\x18\x08 \x01(\tb\x06'
    b'proto3'
)


try:
    DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(_SERIALIZED_PROTO)
except Exception:
    try:
        DESCRIPTOR = _descriptor_pool.Default().FindFileByName("StartMatch.proto")
    except Exception as exc:
        raise ImportError(
            "StartMatch_pb2: cannot register 'StartMatch.proto' into the "
            "default descriptor pool and it is not already present. "
            "Another module may have claimed the same filename."
        ) from exc


_globals = globals()
try:
    _builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
except Exception:
    pass
try:
    _builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "StartMatch_pb2", _globals)
except Exception:
    pass


if not _descriptor._USE_C_DESCRIPTORS:
    try:
        DESCRIPTOR._loaded_options = None
    except Exception:
        pass
    _off = {
        "_STARTUDPMATCH":                (21,  257),
        "_STARTUDPMATCH_NESTED1":        (77,  257),
        "_STARTUDPMATCH_NESTED1_NESTED2": (197, 222),
        "_STARTUDPMATCH_NESTED1_NESTED3": (224, 257),
    }
    for _sym, (_a, _b) in _off.items():
        try:
            _globals[_sym]._serialized_start = _a
            _globals[_sym]._serialized_end = _b
        except (KeyError, AttributeError):
            pass


_cls = _globals.get("StartUDPMatch")
if _cls is not None:
    try:
        _sym_db.RegisterMessage(_cls)
    except Exception:
        pass


if _cls is not None:
    StartMatch = _cls
else:
    StartMatch = None


_self = sys.modules.get(__name__)
if _self is not None:
    sys.modules.setdefault("StartMatch_pb2", _self)
    sys.modules.setdefault("startMatch_pb2", _self)


__all__ = ["StartUDPMatch", "StartMatch", "DESCRIPTOR"]


if __name__ == "__main__":
    print("📦 EXONIDE PRO — StartMatch_pb2.py")
    print(f"   Protobuf runtime : {_descriptor.__name__}")
    print(f"   DESCRIPTOR       : {DESCRIPTOR.name}")
    print(f"   Message          : StartUDPMatch (aliased as StartMatch)")
    print()

    m = StartUDPMatch()
    r1 = m.main.region_list.add()
    r1.region = "ID"
    r2 = m.main.region_list.add()
    r2.region = "SG"
    m.main.client_version.remote_version = "1.132.10"
    raw = m.SerializeToString()
    assert len(raw) > 0

    m2 = StartUDPMatch()
    m2.ParseFromString(raw)
    assert len(m2.main.region_list) == 2
    assert m2.main.region_list[0].region == "ID"
    assert m2.main.region_list[1].region == "SG"
    assert m2.main.client_version.remote_version == "1.132.10"
    print(f"   ✅ StartUDPMatch     OK ({len(raw)} bytes)")

    assert StartMatch is StartUDPMatch, "StartMatch alias is not identical"
    m_alias = StartMatch()
    m_alias.ParseFromString(raw)
    assert m_alias.main.region_list[0].region == "ID"
    print(f"   ✅ StartMatch alias  OK (identical class)")

    proto = StartMatch()
    proto.ParseFromString(raw)
    if hasattr(proto.main, "region_list") and len(proto.main.region_list) > 0:
        proto.main.region_list[0].region = "BD"
        if len(proto.main.region_list) > 1:
            proto.main.region_list[1].region = "BD"
    if hasattr(proto.main, "client_version"):
        proto.main.client_version.remote_version = "1.132.10"
    mutated = proto.SerializeToString()
    assert mutated != raw, "mutation did not change bytes"
    print(f"   ✅ app.py pattern    OK (mutate + reserialize)")

    m3 = StartUDPMatch()
    r3 = m3.main.region_list.add()
    r3.region = "BD"
    m3.main.client_version.remote_version = "1.132.9"
    raw = m3.SerializeToString()
    m4 = StartUDPMatch()
    m4.ParseFromString(raw)
    assert m4.main.region_list[0].region == "BD"
    print(f"   ✅ single region     OK")

    m5 = StartUDPMatch()
    raw = m5.SerializeToString()
    assert len(raw) == 0
    print(f"   ✅ empty message     OK (0 bytes)")

    assert DESCRIPTOR.name == "StartMatch.proto"
    assert StartUDPMatch.DESCRIPTOR.full_name == "StartUDPMatch"
    assert StartMatch.DESCRIPTOR.full_name == "StartUDPMatch"
    print("   ✅ descriptor        OK (StartMatch.proto → StartUDPMatch)")

    print()
    print("   ✅ All self-tests passed.")